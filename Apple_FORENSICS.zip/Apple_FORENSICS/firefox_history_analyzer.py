#!/usr/bin/env python3
"""
Firefox History Analyzer
========================
Extract and analyze Firefox browser history for forensic investigation.

Features:
- URL history extraction with timestamps
- Download history analysis
- Form history extraction (autofill data)
- Suspicious URL detection with whitelist support
- Timeline reconstruction (standardized JSON format)
- Multi-format output (JSON/CSV/Markdown)

Part of: Backwater Forensics • Apple FORENSICS • Victim Investigator Approach
Phase: 3 Module 2
Version: 1.0
"""

import sys
import os
import json
import csv
import sqlite3
import shutil
import argparse
import re
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Tuple
from urllib.parse import urlparse
import hashlib


# Terminal colors
class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    ORANGE = '\033[38;5;208m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class FirefoxHistoryAnalyzer:
    """Analyze Firefox browser history for forensic investigation"""
    
    def __init__(self, profile_path: Optional[str] = None, case_id: str = "UNKNOWN", suspicious_only: bool = False):
        """
        Initialize Firefox history analyzer
        
        Args:
            profile_path: Path to Firefox profile (default: auto-detect)
            case_id: Case ID for forensic tracking
            suspicious_only: If True, only output suspicious URLs in reports
        """
        self.case_id = case_id
        self.profile_path = self._resolve_profile_path(profile_path)
        self.suspicious_only = suspicious_only
        self.analysis_timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # Whitelist storage
        self.whitelist = {
            'domains': set(),
            'extensions': set()
        }
        
        # Results storage
        self.urls = []
        self.downloads = []
        self.form_history = []
        self.findings = []
        self.timeline_events = []
        
        # Statistics
        self.stats = {
            'total_urls': 0,
            'unique_urls': 0,
            'total_visits': 0,
            'downloads': 0,
            'form_entries': 0,
            'suspicious_urls': 0,
            'whitelisted_filtered': 0
        }
    
    def _resolve_profile_path(self, profile_path: Optional[str]) -> Path:
        """Resolve Firefox profile path"""
        if profile_path:
            return Path(profile_path).expanduser()
        
        # Default Firefox profiles location on macOS
        firefox_base = Path.home() / 'Library/Application Support/Firefox/Profiles'
        
        if not firefox_base.exists():
            raise FileNotFoundError(
                f"Firefox profiles directory not found: {firefox_base}\n"
                "Use -p to specify profile path"
            )
        
        # Find default profile (usually ends with .default or .default-release)
        profiles = list(firefox_base.glob('*.default*'))
        
        if not profiles:
            raise FileNotFoundError(
                f"No Firefox profiles found in {firefox_base}\n"
                "Use -p to specify profile path"
            )
        
        # Use first default profile found
        default_profile = profiles[0]
        print(f"{Colors.CYAN}Auto-detected profile: {default_profile.name}{Colors.ENDC}")
        
        return default_profile
    
    @staticmethod
    def firefox_time_to_datetime(firefox_time: int) -> Optional[str]:
        """
        Convert Firefox timestamp to UTC datetime string
        
        Firefox timestamps are microseconds since Unix epoch (1970-01-01)
        
        Args:
            firefox_time: Firefox timestamp in microseconds
            
        Returns:
            ISO format UTC timestamp with 'Z' suffix, or None if invalid
        """
        if firefox_time == 0:
            return None
        
        try:
            # Convert microseconds to seconds
            unix_timestamp = firefox_time / 1000000
            
            # Create UTC datetime with 'Z' suffix
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.isoformat().replace('+00:00', 'Z')
        except (ValueError, OSError):
            return None
    
    def load_whitelist(self, whitelist_file: str):
        """
        Load domain and extension whitelist from file
        
        Args:
            whitelist_file: Path to whitelist file
        """
        whitelist_path = Path(whitelist_file)
        
        if not whitelist_path.exists():
            print(f"{Colors.YELLOW}Warning: Whitelist file not found: {whitelist_file}{Colors.ENDC}")
            return
        
        with open(whitelist_path, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Parse DOMAIN: entries
                if line.startswith('DOMAIN:'):
                    domain = line.split('|')[0].replace('DOMAIN:', '').strip()
                    self.whitelist['domains'].add(domain)
                
                # Parse EXTENSION: entries
                elif line.startswith('EXTENSION:'):
                    ext = line.split('|')[0].replace('EXTENSION:', '').strip()
                    self.whitelist['extensions'].add(ext)
        
        print(f"{Colors.GREEN}✓ Loaded {len(self.whitelist['domains'])} domains, {len(self.whitelist['extensions'])} extensions{Colors.ENDC}")
    
    def is_whitelisted(self, url: str) -> Tuple[bool, Optional[str]]:
        """
        Check if URL is whitelisted
        
        Args:
            url: URL to check
            
        Returns:
            (is_whitelisted, reason)
        """
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            extension = Path(parsed.path).suffix.lower()
            
            # Check domain whitelist
            for whitelisted_domain in self.whitelist['domains']:
                if domain.endswith(whitelisted_domain):
                    return True, f"Whitelisted domain: {whitelisted_domain}"
            
            # Check extension whitelist
            if extension and extension in self.whitelist['extensions']:
                return True, f"Whitelisted extension: {extension}"
            
            return False, None
        
        except Exception:
            return False, None
    
    def analyze_url_for_threats(self, url: str) -> Optional[Dict]:
        """
        Analyze URL for suspicious patterns
        
        Args:
            url: URL to analyze
            
        Returns:
            Finding dictionary if suspicious, None if benign
        """
        # Check whitelist first
        is_whitelisted_flag, whitelist_reason = self.is_whitelisted(url)
        if is_whitelisted_flag:
            self.stats['whitelisted_filtered'] += 1
            return None
        
        indicators = []
        severity = 'LOW'
        category = 'Suspicious URL'
        
        # Executable downloads
        if re.search(r'\.(exe|dll|bat|cmd|vbs|ps1|scr|app)$', url, re.IGNORECASE):
            indicators.append('Executable file extension')
            severity = 'HIGH'
            category = 'Suspicious Download'
        
        # Known malicious TLDs
        if re.search(r'\.(xyz|top|tk|ml|ga|cf|gq)$', url, re.IGNORECASE):
            indicators.append('Suspicious TLD')
            severity = 'MEDIUM'
            category = 'Suspicious Domain'
        
        # IP address URLs
        if re.search(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
            indicators.append('Direct IP access')
            severity = 'MEDIUM'
            category = 'Direct IP Access'
        
        # Typosquatting patterns
        typosquat_patterns = [
            'gooogle', 'faceboook', 'amazoon', 'paypa1', 'microsft',
            'netfliix', 'appleid-secure', 'icloud-verify', 'firefoxx'
        ]
        url_lower = url.lower()
        for pattern in typosquat_patterns:
            if pattern in url_lower:
                indicators.append('Possible typosquatting')
                severity = 'HIGH'
                category = 'Typosquatting'
                break
        
        # Suspicious keywords
        suspicious_keywords = ['malware', 'keylog', 'crack', 'keygen', 'hack']
        for keyword in suspicious_keywords:
            if keyword in url_lower:
                indicators.append(f'Suspicious keyword: {keyword}')
                severity = 'HIGH'
                category = 'Suspicious Content'
                break
        
        if indicators:
            self.stats['suspicious_urls'] += 1
            return {
                'severity': severity,
                'category': category,
                'reason': ', '.join(indicators)
            }
        
        return None
    
    def extract_history(self):
        """Extract URL history from Firefox places.sqlite database"""
        places_db = self.profile_path / 'places.sqlite'
        
        if not places_db.exists():
            raise FileNotFoundError(f"Firefox places.sqlite not found: {places_db}")
        
        # Create temporary copy to avoid locking
        temp_db = f'/tmp/firefox_places_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(places_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract URLs with visit information
            # Firefox schema: moz_places and moz_historyvisits tables
            cursor.execute("""
                SELECT 
                    moz_places.id,
                    moz_places.url,
                    moz_places.title,
                    moz_places.visit_count,
                    moz_historyvisits.visit_date,
                    moz_historyvisits.visit_type
                FROM moz_places
                LEFT JOIN moz_historyvisits ON moz_places.id = moz_historyvisits.place_id
                ORDER BY moz_historyvisits.visit_date DESC
            """)
            
            url_rows = cursor.fetchall()
            
            # Process URLs
            url_dict = {}  # Track unique URLs
            
            for row in url_rows:
                place_id, url, title, visit_count, visit_date, visit_type = row
                
                if not url:
                    continue
                
                # Convert timestamp
                timestamp_utc = self.firefox_time_to_datetime(visit_date) if visit_date else None
                
                # Track unique URLs
                if url not in url_dict:
                    url_dict[url] = {
                        'place_id': place_id,
                        'url': url,
                        'title': title or '',
                        'visit_count': visit_count or 0,
                        'last_visit_time': timestamp_utc,
                        'visit_type': visit_type or 0,
                        'first_seen': timestamp_utc
                    }
                else:
                    # Update last visit if this is more recent
                    if timestamp_utc and (not url_dict[url]['last_visit_time'] or 
                                         timestamp_utc > url_dict[url]['last_visit_time']):
                        url_dict[url]['last_visit_time'] = timestamp_utc
                
                self.stats['total_visits'] += 1
            
            # Convert to list
            self.urls = list(url_dict.values())
            self.stats['total_urls'] = len(self.urls)
            self.stats['unique_urls'] = len(url_dict)
            
            # Check for suspicious URLs
            for url_data in self.urls:
                threat_analysis = self.analyze_url_for_threats(url_data['url'])
                if threat_analysis:
                    finding = {
                        **url_data,
                        **threat_analysis
                    }
                    self.findings.append(finding)
                    
                    # Add to timeline
                    if url_data['last_visit_time']:
                        self.timeline_events.append({
                            'timestamp_utc': url_data['last_visit_time'],
                            'event_type': 'browser_visit',
                            'source_artifact': 'firefox_places',
                            'artifact_path': str(places_db),
                            'browser': 'firefox',
                            'profile': self.profile_path.name,
                            'details': {
                                'url': url_data['url'],
                                'title': url_data['title'],
                                'visit_count': url_data['visit_count'],
                                'severity': threat_analysis['severity'],
                                'category': threat_analysis['category'],
                                'reason': threat_analysis['reason']
                            }
                        })
            
            conn.close()
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_downloads(self):
        """Extract download history from Firefox places.sqlite"""
        places_db = self.profile_path / 'places.sqlite'
        temp_db = f'/tmp/firefox_places_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(places_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Try to extract downloads from moz_annos (annotations)
            # Firefox stores downloads differently across versions
            cursor.execute("""
                SELECT 
                    moz_places.url,
                    moz_places.title,
                    moz_annos.content,
                    moz_historyvisits.visit_date
                FROM moz_annos
                JOIN moz_places ON moz_annos.place_id = moz_places.id
                LEFT JOIN moz_historyvisits ON moz_places.id = moz_historyvisits.place_id
                WHERE moz_annos.anno_attribute_id IN (
                    SELECT id FROM moz_anno_attributes 
                    WHERE name LIKE '%download%'
                )
                ORDER BY moz_historyvisits.visit_date DESC
            """)
            
            for row in cursor.fetchall():
                url, title, content, visit_date = row
                
                # Convert timestamp
                timestamp_utc = self.firefox_time_to_datetime(visit_date) if visit_date else None
                
                download_data = {
                    'url': url or '',
                    'title': title or '',
                    'content': content or '',
                    'download_time': timestamp_utc
                }
                
                self.downloads.append(download_data)
                self.stats['downloads'] += 1
                
                # Add to timeline
                if timestamp_utc and url:
                    self.timeline_events.append({
                        'timestamp_utc': timestamp_utc,
                        'event_type': 'browser_download',
                        'source_artifact': 'firefox_places',
                        'artifact_path': str(places_db),
                        'browser': 'firefox',
                        'profile': self.profile_path.name,
                        'details': {
                            'url': url,
                            'title': title or ''
                        }
                    })
            
            conn.close()
        
        except Exception as e:
            print(f"{Colors.YELLOW}Note: Could not extract downloads: {e}{Colors.ENDC}")
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_form_history(self):
        """Extract form autofill history from formhistory.sqlite"""
        formhistory_db = self.profile_path / 'formhistory.sqlite'
        
        if not formhistory_db.exists():
            print(f"{Colors.YELLOW}Note: formhistory.sqlite not found (no form data or Firefox cleared){Colors.ENDC}")
            return
        
        temp_db = f'/tmp/firefox_formhistory_{self.case_id}_{os.getpid()}.db'
        
        try:
            shutil.copy2(formhistory_db, temp_db)
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract form entries
            cursor.execute("""
                SELECT 
                    fieldname,
                    value,
                    timesUsed,
                    firstUsed,
                    lastUsed
                FROM moz_formhistory
                ORDER BY lastUsed DESC
            """)
            
            for row in cursor.fetchall():
                fieldname, value, times_used, first_used, last_used = row
                
                # Convert timestamps
                first_used_utc = self.firefox_time_to_datetime(first_used) if first_used else None
                last_used_utc = self.firefox_time_to_datetime(last_used) if last_used else None
                
                form_data = {
                    'fieldname': fieldname or '',
                    'value': value or '',
                    'times_used': times_used or 0,
                    'first_used': first_used_utc,
                    'last_used': last_used_utc
                }
                
                self.form_history.append(form_data)
                self.stats['form_entries'] += 1
            
            conn.close()
        
        except Exception as e:
            print(f"{Colors.YELLOW}Note: Could not extract form history: {e}{Colors.ENDC}")
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def generate_summary(self) -> Dict:
        """Generate analysis summary"""
        # Calculate date range
        earliest_date = None
        latest_date = None
        
        if self.urls:
            valid_timestamps = [u['last_visit_time'] for u in self.urls if u['last_visit_time']]
            if valid_timestamps:
                earliest_date = min(valid_timestamps)
                latest_date = max(valid_timestamps)
        
        # Top domains
        domain_counts = {}
        for url_data in self.urls:
            try:
                domain = urlparse(url_data['url']).netloc
                domain_counts[domain] = domain_counts.get(domain, 0) + url_data['visit_count']
            except Exception:
                continue
        
        top_domains = [
            {'domain': domain, 'visit_count': count}
            for domain, count in sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        ]
        
        return {
            'total_urls': self.stats['total_urls'],
            'unique_urls': self.stats['unique_urls'],
            'total_visits': self.stats['total_visits'],
            'date_range': {
                'earliest': earliest_date,
                'latest': latest_date
            },
            'downloads': self.stats['downloads'],
            'form_entries': self.stats['form_entries'],
            'suspicious_urls': self.stats['suspicious_urls'],
            'whitelisted_filtered': self.stats['whitelisted_filtered'],
            'top_domains': top_domains
        }
    
    def save_json(self, output_dir: Path, case_id: str):
        """Save results as JSON"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'firefox_history_{case_id}_{timestamp}.json'
        output_file = output_dir / filename
        
        # Build complete JSON output
        output_data = {
            'analysis_metadata': {
                'tool': 'firefox_history_analyzer',
                'version': '1.0',
                'analysis_timestamp_utc': self.analysis_timestamp,
                'case_id': case_id,
                'profile_path': str(self.profile_path),
                'profile_name': self.profile_path.name,
                'places_file': str(self.profile_path / 'places.sqlite'),
                'suspicious_only_mode': self.suspicious_only,
                'whitelist_applied': len(self.whitelist['domains']) > 0 or len(self.whitelist['extensions']) > 0,
                'whitelist_domains': len(self.whitelist['domains']),
                'whitelist_extensions': len(self.whitelist['extensions'])
            },
            'summary': self.generate_summary(),
            'findings': self.findings,
            'downloads': self.downloads,
            'form_history': self.form_history,
            'timeline': {
                'timeline_format_version': '1.0',
                'events': sorted(self.timeline_events, key=lambda x: x['timestamp_utc'] or '')
            }
        }
        
        # Include all URLs if not in suspicious-only mode
        if not self.suspicious_only:
            output_data['all_urls'] = self.urls
        
        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2)
        
        # Calculate SHA-256 hash for evidence integrity
        sha256_hash = hashlib.sha256()
        with open(output_file, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        
        hash_file = output_dir / f'{filename}.sha256'
        with open(hash_file, 'w') as f:
            f.write(f"{sha256_hash.hexdigest()}  {filename}\n")
        
        print(f"{Colors.GREEN}✓ JSON saved: {output_file}{Colors.ENDC}")
        print(f"{Colors.GREEN}✓ SHA-256: {hash_file}{Colors.ENDC}")
    
    def save_csv(self, output_dir: Path, case_id: str):
        """Save findings as CSV"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'firefox_history_{case_id}_{timestamp}.csv'
        output_file = output_dir / filename
        
        with open(output_file, 'w', newline='') as f:
            if self.suspicious_only:
                # Only suspicious URLs
                if self.findings:
                    fieldnames = ['url', 'title', 'visit_count', 'last_visit_time', 'severity', 'category', 'reason']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    for finding in self.findings:
                        writer.writerow({
                            'url': finding['url'],
                            'title': finding['title'],
                            'visit_count': finding['visit_count'],
                            'last_visit_time': finding['last_visit_time'],
                            'severity': finding['severity'],
                            'category': finding['category'],
                            'reason': finding['reason']
                        })
            else:
                # All URLs
                if self.urls:
                    fieldnames = ['url', 'title', 'visit_count', 'last_visit_time', 'suspicious', 'severity', 'category', 'reason']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    # Create lookup for findings
                    findings_dict = {f['url']: f for f in self.findings}
                    
                    for url_data in self.urls:
                        url = url_data['url']
                        row = {
                            'url': url,
                            'title': url_data['title'],
                            'visit_count': url_data['visit_count'],
                            'last_visit_time': url_data['last_visit_time'],
                            'suspicious': 'Yes' if url in findings_dict else 'No',
                            'severity': findings_dict[url]['severity'] if url in findings_dict else '',
                            'category': findings_dict[url]['category'] if url in findings_dict else '',
                            'reason': findings_dict[url]['reason'] if url in findings_dict else ''
                        }
                        writer.writerow(row)
        
        print(f"{Colors.GREEN}✓ CSV saved: {output_file}{Colors.ENDC}")
    
    def save_markdown(self, output_dir: Path, case_id: str):
        """Save results as Markdown report"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'firefox_history_{case_id}_{timestamp}.md'
        output_file = output_dir / filename
        
        summary = self.generate_summary()
        
        with open(output_file, 'w') as f:
            # Header
            f.write(f"# Firefox History Analysis Report\n\n")
            f.write(f"**Case ID:** {case_id}  \n")
            f.write(f"**Analysis Timestamp:** {self.analysis_timestamp}  \n")
            f.write(f"**Profile:** {self.profile_path}  \n")
            f.write(f"**Profile Name:** {self.profile_path.name}  \n")
            f.write(f"**Tool:** firefox_history_analyzer v1.0  \n\n")
            
            f.write("---\n\n")
            
            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total URLs:** {summary['total_urls']:,}\n")
            f.write(f"- **Unique URLs:** {summary['unique_urls']:,}\n")
            f.write(f"- **Total Visits:** {summary['total_visits']:,}\n")
            f.write(f"- **Downloads:** {summary['downloads']:,}\n")
            f.write(f"- **Form Entries:** {summary['form_entries']:,}\n")
            f.write(f"- **Suspicious URLs:** {summary['suspicious_urls']:,}\n")
            f.write(f"- **Whitelisted (Filtered):** {summary['whitelisted_filtered']:,}\n\n")
            
            if summary['date_range']['earliest'] and summary['date_range']['latest']:
                f.write(f"**Date Range:** {summary['date_range']['earliest']} to {summary['date_range']['latest']}\n\n")
            
            # Findings
            if self.findings:
                f.write("---\n\n")
                f.write("## 🔍 Suspicious Findings\n\n")
                
                # Group by severity
                high_findings = [f for f in self.findings if f['severity'] == 'HIGH']
                medium_findings = [f for f in self.findings if f['severity'] == 'MEDIUM']
                low_findings = [f for f in self.findings if f['severity'] == 'LOW']
                
                if high_findings:
                    f.write(f"### HIGH Severity ({len(high_findings)})\n\n")
                    for finding in high_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n")
                        f.write(f"- **Visit Count:** {finding['visit_count']}  \n\n")
                
                if medium_findings:
                    f.write(f"### MEDIUM Severity ({len(medium_findings)})\n\n")
                    for finding in medium_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n\n")
                
                if low_findings:
                    f.write(f"### LOW Severity ({len(low_findings)})\n\n")
                    for finding in low_findings[:10]:
                        f.write(f"- {finding['url']} ({finding['category']})\n")
                    if len(low_findings) > 10:
                        f.write(f"\n*...and {len(low_findings) - 10} more*\n")
            
            # All URLs section (if not in suspicious-only mode)
            if not self.suspicious_only and self.urls:
                f.write("\n---\n\n")
                f.write(f"## 🌐 All URLs Visited ({len(self.urls)})\n\n")
                f.write("*Complete browsing history (most recent first)*\n\n")
                
                # Show first 50 URLs
                for url_data in self.urls[:50]:
                    f.write(f"**{url_data['title'] or 'No Title'}**  \n")
                    f.write(f"- **URL:** {url_data['url']}  \n")
                    f.write(f"- **Visits:** {url_data['visit_count']}  \n")
                    f.write(f"- **Last Visit:** {url_data['last_visit_time']}  \n\n")
                
                if len(self.urls) > 50:
                    f.write(f"*...and {len(self.urls) - 50} more URLs (see JSON/CSV for complete list)*\n\n")
            
            # Top Domains
            if summary['top_domains']:
                f.write("\n---\n\n")
                f.write("## 📊 Top Domains\n\n")
                for domain_info in summary['top_domains'][:10]:
                    f.write(f"- **{domain_info['domain']}** - {domain_info['visit_count']:,} visits\n")
            
            # Downloads
            if self.downloads:
                f.write("\n---\n\n")
                f.write(f"## 📥 Downloads ({len(self.downloads)})\n\n")
                for download in self.downloads[:20]:
                    f.write(f"**{download['title'] or 'Unknown'}**  \n")
                    f.write(f"- **URL:** {download['url']}  \n")
                    f.write(f"- **Time:** {download['download_time']}  \n\n")
            
            # Form History
            if self.form_history:
                f.write("\n---\n\n")
                f.write(f"## 📝 Form History ({len(self.form_history)})\n\n")
                f.write("*Autofill data from web forms*\n\n")
                for form in self.form_history[:20]:
                    f.write(f"- **{form['fieldname']}:** {form['value']} (used {form['times_used']} times)\n")
            
            f.write("\n---\n\n")
            f.write("*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*\n")
        
        print(f"{Colors.GREEN}✓ Markdown saved: {output_file}{Colors.ENDC}")
    
    def run(self, output_dir: Path, verbose: bool = False):
        """Run complete analysis"""
        print(f"\n{Colors.CYAN}{'=' * 70}{Colors.ENDC}")
        print(f"{Colors.CYAN}{Colors.BOLD}{'Firefox History Analyzer'.center(70)}{Colors.ENDC}")
        print(f"{Colors.CYAN}{'=' * 70}{Colors.ENDC}\n")
        
        print(f"{Colors.BOLD}Case ID:{Colors.ENDC} {self.case_id}")
        print(f"{Colors.BOLD}Profile:{Colors.ENDC} {self.profile_path}")
        print(f"{Colors.BOLD}Profile Name:{Colors.ENDC} {self.profile_path.name}")
        print(f"{Colors.BOLD}Analysis Time:{Colors.ENDC} {self.analysis_timestamp}\n")
        
        # Extract data
        steps = [
            ("Extracting URL history", self.extract_history),
            ("Extracting downloads", self.extract_downloads),
            ("Extracting form history", self.extract_form_history)
        ]
        
        for step_name, step_func in steps:
            if verbose:
                print(f"{Colors.CYAN}→ {step_name}...{Colors.ENDC}")
            try:
                step_func()
                if verbose:
                    print(f"{Colors.GREEN}  ✓ Complete{Colors.ENDC}")
            except Exception as e:
                print(f"{Colors.RED}  ✗ Error: {e}{Colors.ENDC}")
        
        # Save outputs
        print(f"\n{Colors.BOLD}Saving results...{Colors.ENDC}\n")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        self.save_json(output_dir, self.case_id)
        self.save_csv(output_dir, self.case_id)
        self.save_markdown(output_dir, self.case_id)
        
        # Print summary
        print(f"\n{Colors.BOLD}Analysis Summary:{Colors.ENDC}")
        print(f"  URLs: {self.stats['total_urls']:,}")
        print(f"  Downloads: {self.stats['downloads']:,}")
        print(f"  Form Entries: {self.stats['form_entries']:,}")
        print(f"  Suspicious: {self.stats['suspicious_urls']:,}")
        print(f"  Whitelisted: {self.stats['whitelisted_filtered']:,}")
        
        print(f"\n{Colors.GREEN}✓ Analysis complete!{Colors.ENDC}\n")


def main():
    parser = argparse.ArgumentParser(
        description='Firefox History Analyzer - Forensic browser history extraction',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=r"""
Examples:
  # Analyze auto-detected Firefox profile
  %(prog)s
  
  # Analyze specific profile
  %(prog)s -p ~/Library/Application\ Support/Firefox/Profiles/abc123.default/
  
  # Use whitelist and specify case ID
  %(prog)s -w firefox_whitelist.txt --case-id CASE-001
  
  # Output only suspicious URLs
  %(prog)s --suspicious-only -w firefox_whitelist.txt --case-id CASE-001
  
  # Output to specific directory
  %(prog)s -o /evidence/firefox_analysis/ --case-id CASE-001 -v

Part of: Apple FORENSICS • Backwater Forensics
        """
    )
    
    parser.add_argument('-p', '--profile', help='Firefox profile path (default: auto-detect)')
    parser.add_argument('-o', '--output', default='.', help='Output directory (default: current)')
    parser.add_argument('--case-id', default='UNKNOWN', help='Case ID for tracking')
    parser.add_argument('-w', '--whitelist', action='append', help='Whitelist file (can specify multiple)')
    parser.add_argument('--suspicious-only', action='store_true', help='Output only suspicious URLs (excludes benign URLs from reports)')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    try:
        # Initialize analyzer
        analyzer = FirefoxHistoryAnalyzer(
            profile_path=args.profile,
            case_id=args.case_id,
            suspicious_only=args.suspicious_only
        )
        
        # Load whitelists
        if args.whitelist:
            for whitelist_file in args.whitelist:
                analyzer.load_whitelist(whitelist_file)
        
        # Run analysis
        output_dir = Path(args.output).expanduser()
        analyzer.run(output_dir, verbose=args.verbose)
        
        return 0
    
    except FileNotFoundError as e:
        print(f"{Colors.RED}Error: {e}{Colors.ENDC}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"{Colors.RED}Unexpected error: {e}{Colors.ENDC}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
