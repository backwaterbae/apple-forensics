#!/usr/bin/env python3
"""
Chrome History Analyzer
=======================
Extract and analyze Chrome browser history for forensic investigation.

Features:
- URL history extraction with timestamps
- Download history analysis
- Search query extraction
- Browser extension detection
- Incognito mode detection
- Suspicious URL detection with whitelist support
- Timeline reconstruction (standardized JSON format)
- Multi-format output (JSON/CSV/Markdown)

Part of: Backwater Forensics • Apple FORENSICS • Victim Investigator Approach
Phase: 3 Module 2
Version: 1.0
"""

import sys
import os
import json
import csv
import sqlite3
import shutil
import argparse
import re
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Tuple
from urllib.parse import urlparse
import hashlib


# Terminal colors
class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    ORANGE = '\033[38;5;208m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class ChromeHistoryAnalyzer:
    """Analyze Chrome browser history for forensic investigation"""
    
    def __init__(self, profile_path: Optional[str] = None, case_id: str = "UNKNOWN"):
        """
        Initialize Chrome history analyzer
        
        Args:
            profile_path: Path to Chrome profile (default: current user's default)
            case_id: Case ID for forensic tracking
        """
        self.case_id = case_id
        self.profile_path = self._resolve_profile_path(profile_path)
        self.analysis_timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # Whitelist storage
        self.whitelist = {
            'domains': set(),
            'extensions': set()
        }
        
        # Results storage
        self.urls = []
        self.downloads = []
        self.searches = []
        self.extensions = []
        self.findings = []
        self.timeline_events = []
        
        # Statistics
        self.stats = {
            'total_urls': 0,
            'unique_urls': 0,
            'total_visits': 0,
            'downloads': 0,
            'search_queries': 0,
            'suspicious_urls': 0,
            'whitelisted_filtered': 0,
            'installed_extensions': 0,
            'incognito_detected': False
        }
    
    def _resolve_profile_path(self, profile_path: Optional[str]) -> Path:
        """Resolve Chrome profile path"""
        if profile_path:
            return Path(profile_path).expanduser()
        
        # Default Chrome profile location on macOS
        default_path = Path.home() / 'Library/Application Support/Google/Chrome/Default'
        
        if not default_path.exists():
            raise FileNotFoundError(
                f"Chrome default profile not found: {default_path}\n"
                "Use -p to specify profile path"
            )
        
        return default_path
    
    @staticmethod
    def chrome_time_to_datetime(chrome_time: int) -> Optional[str]:
        """
        Convert Chrome timestamp to UTC datetime string
        
        Chrome time is microseconds since 1601-01-01 (WebKit epoch)
        Python epoch is 1970-01-01
        
        Args:
            chrome_time: Chrome timestamp in microseconds
            
        Returns:
            ISO format UTC timestamp with 'Z' suffix, or None if invalid
        """
        if chrome_time == 0:
            return None
        
        try:
            # Seconds between 1601 and 1970
            epoch_diff = 11644473600
            
            # Convert microseconds to seconds and adjust for epoch
            unix_timestamp = (chrome_time / 1000000) - epoch_diff
            
            # Create UTC datetime with 'Z' suffix
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.isoformat().replace('+00:00', 'Z')
        except (ValueError, OSError):
            return None
    
    def load_whitelist(self, whitelist_file: str):
        """
        Load domain and extension whitelist from file
        
        Args:
            whitelist_file: Path to whitelist file
        """
        whitelist_path = Path(whitelist_file)
        
        if not whitelist_path.exists():
            print(f"{Colors.YELLOW}Warning: Whitelist file not found: {whitelist_file}{Colors.ENDC}")
            return
        
        with open(whitelist_path, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Parse DOMAIN: entries
                if line.startswith('DOMAIN:'):
                    domain = line.split('|')[0].replace('DOMAIN:', '').strip()
                    self.whitelist['domains'].add(domain)
                
                # Parse EXTENSION: entries
                elif line.startswith('EXTENSION:'):
                    ext = line.split('|')[0].replace('EXTENSION:', '').strip()
                    self.whitelist['extensions'].add(ext)
        
        print(f"{Colors.GREEN}✓ Loaded {len(self.whitelist['domains'])} domains, {len(self.whitelist['extensions'])} extensions{Colors.ENDC}")
    
    def is_whitelisted(self, url: str) -> Tuple[bool, Optional[str]]:
        """
        Check if URL is whitelisted
        
        Args:
            url: URL to check
            
        Returns:
            (is_whitelisted, reason)
        """
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            extension = Path(parsed.path).suffix.lower()
            
            # Check domain whitelist
            for whitelisted_domain in self.whitelist['domains']:
                if domain.endswith(whitelisted_domain):
                    return True, f"Whitelisted domain: {whitelisted_domain}"
            
            # Check extension whitelist
            if extension and extension in self.whitelist['extensions']:
                return True, f"Whitelisted extension: {extension}"
            
            return False, None
        
        except Exception:
            return False, None
    
    def analyze_url_for_threats(self, url: str) -> Optional[Dict]:
        """
        Analyze URL for suspicious patterns
        
        Args:
            url: URL to analyze
            
        Returns:
            Finding dictionary if suspicious, None if benign
        """
        # Check whitelist first
        is_whitelisted_flag, whitelist_reason = self.is_whitelisted(url)
        if is_whitelisted_flag:
            self.stats['whitelisted_filtered'] += 1
            return None
        
        indicators = []
        severity = 'LOW'
        category = 'Suspicious URL'
        
        # Executable downloads
        if re.search(r'\.(exe|dll|bat|cmd|vbs|ps1|scr|app)$', url, re.IGNORECASE):
            indicators.append('Executable file extension')
            severity = 'HIGH'
            category = 'Suspicious Download'
        
        # Known malicious TLDs
        if re.search(r'\.(xyz|top|tk|ml|ga|cf|gq)$', url, re.IGNORECASE):
            indicators.append('Suspicious TLD')
            severity = 'MEDIUM'
            category = 'Suspicious Domain'
        
        # IP address URLs
        if re.search(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
            indicators.append('Direct IP access')
            severity = 'MEDIUM'
            category = 'Direct IP Access'
        
        # Typosquatting patterns
        typosquat_patterns = [
            'gooogle', 'faceboook', 'amazoon', 'paypa1', 'microsft',
            'netfliix', 'appleid-secure', 'icloud-verify'
        ]
        url_lower = url.lower()
        for pattern in typosquat_patterns:
            if pattern in url_lower:
                indicators.append('Possible typosquatting')
                severity = 'HIGH'
                category = 'Typosquatting'
                break
        
        # Suspicious keywords
        suspicious_keywords = ['malware', 'keylog', 'crack', 'keygen', 'hack']
        for keyword in suspicious_keywords:
            if keyword in url_lower:
                indicators.append(f'Suspicious keyword: {keyword}')
                severity = 'HIGH'
                category = 'Suspicious Content'
                break
        
        if indicators:
            self.stats['suspicious_urls'] += 1
            return {
                'severity': severity,
                'category': category,
                'reason': ', '.join(indicators)
            }
        
        return None
    
    def extract_history(self):
        """Extract URL history from Chrome History database"""
        history_db = self.profile_path / 'History'
        
        if not history_db.exists():
            raise FileNotFoundError(f"Chrome History database not found: {history_db}")
        
        # Create temporary copy to avoid locking
        temp_db = f'/tmp/chrome_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract URLs with visit information
            cursor.execute("""
                SELECT 
                    urls.id,
                    urls.url,
                    urls.title,
                    urls.visit_count,
                    urls.typed_count,
                    urls.last_visit_time,
                    urls.hidden
                FROM urls
                ORDER BY last_visit_time DESC
            """)
            
            url_rows = cursor.fetchall()
            self.stats['total_urls'] = len(url_rows)
            
            for row in url_rows:
                url_id, url, title, visit_count, typed_count, last_visit, hidden = row
                
                # Convert timestamp
                timestamp_utc = self.chrome_time_to_datetime(last_visit)
                
                url_data = {
                    'url_id': url_id,
                    'url': url,
                    'title': title or '',
                    'visit_count': visit_count,
                    'typed_count': typed_count,
                    'last_visit_time': timestamp_utc,
                    'hidden': bool(hidden)
                }
                
                self.urls.append(url_data)
                self.stats['total_visits'] += visit_count
                
                # Check for suspicious URLs
                threat_analysis = self.analyze_url_for_threats(url)
                if threat_analysis:
                    finding = {
                        **url_data,
                        **threat_analysis
                    }
                    self.findings.append(finding)
                    
                    # Add to timeline
                    if timestamp_utc:
                        self.timeline_events.append({
                            'timestamp_utc': timestamp_utc,
                            'event_type': 'browser_visit',
                            'source_artifact': 'chrome_history',
                            'artifact_path': str(history_db),
                            'browser': 'chrome',
                            'profile': self.profile_path.name,
                            'details': {
                                'url': url,
                                'title': title or '',
                                'visit_count': visit_count,
                                'severity': threat_analysis['severity'],
                                'category': threat_analysis['category'],
                                'reason': threat_analysis['reason']
                            }
                        })
            
            # Count unique URLs
            unique_urls = set(row[1] for row in url_rows)
            self.stats['unique_urls'] = len(unique_urls)
            
            conn.close()
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_downloads(self):
        """Extract download history from Chrome History database"""
        history_db = self.profile_path / 'History'
        temp_db = f'/tmp/chrome_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract downloads
            cursor.execute("""
                SELECT 
                    downloads.id,
                    downloads.current_path,
                    downloads.target_path,
                    downloads.start_time,
                    downloads.end_time,
                    downloads.received_bytes,
                    downloads.total_bytes,
                    downloads.state,
                    downloads.danger_type,
                    downloads_url_chains.url
                FROM downloads
                LEFT JOIN downloads_url_chains ON downloads.id = downloads_url_chains.id
                ORDER BY start_time DESC
            """)
            
            for row in cursor.fetchall():
                (download_id, current_path, target_path, start_time, end_time,
                 received_bytes, total_bytes, state, danger_type, url) = row
                
                # Convert timestamps
                start_time_utc = self.chrome_time_to_datetime(start_time)
                end_time_utc = self.chrome_time_to_datetime(end_time)
                
                download_data = {
                    'download_id': download_id,
                    'url': url or '',
                    'current_path': current_path or '',
                    'target_path': target_path or '',
                    'start_time': start_time_utc,
                    'end_time': end_time_utc,
                    'received_bytes': received_bytes,
                    'total_bytes': total_bytes,
                    'state': state,
                    'danger_type': danger_type
                }
                
                self.downloads.append(download_data)
                self.stats['downloads'] += 1
                
                # Add to timeline
                if start_time_utc and url:
                    self.timeline_events.append({
                        'timestamp_utc': start_time_utc,
                        'event_type': 'browser_download',
                        'source_artifact': 'chrome_history',
                        'artifact_path': str(history_db),
                        'browser': 'chrome',
                        'profile': self.profile_path.name,
                        'details': {
                            'url': url,
                            'target_path': target_path or '',
                            'state': state,
                            'danger_type': danger_type,
                            'bytes_received': received_bytes
                        }
                    })
            
            conn.close()
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_searches(self):
        """Extract search queries from Chrome History database"""
        history_db = self.profile_path / 'History'
        temp_db = f'/tmp/chrome_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract search queries
            cursor.execute("""
                SELECT 
                    keyword_search_terms.term,
                    keyword_search_terms.url_id,
                    urls.url,
                    urls.last_visit_time
                FROM keyword_search_terms
                JOIN urls ON keyword_search_terms.url_id = urls.id
                ORDER BY urls.last_visit_time DESC
            """)
            
            for row in cursor.fetchall():
                term, url_id, url, last_visit = row
                
                # Convert timestamp
                timestamp_utc = self.chrome_time_to_datetime(last_visit)
                
                # Extract search engine
                search_engine = urlparse(url).netloc if url else 'unknown'
                
                search_data = {
                    'query': term,
                    'timestamp': timestamp_utc,
                    'search_engine': search_engine,
                    'url': url
                }
                
                self.searches.append(search_data)
                self.stats['search_queries'] += 1
            
            conn.close()
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_extensions(self):
        """Extract installed browser extensions"""
        extensions_dir = self.profile_path / 'Extensions'
        
        if not extensions_dir.exists():
            return
        
        # Check Preferences for extension metadata
        prefs_file = self.profile_path / 'Preferences'
        
        if prefs_file.exists():
            try:
                with open(prefs_file, 'r') as f:
                    prefs = json.load(f)
                
                extensions_data = prefs.get('extensions', {}).get('settings', {})
                
                for ext_id, ext_info in extensions_data.items():
                    extension = {
                        'id': ext_id,
                        'name': ext_info.get('manifest', {}).get('name', 'Unknown'),
                        'version': ext_info.get('manifest', {}).get('version', 'Unknown'),
                        'enabled': ext_info.get('state', 0) == 1,
                        'path': ext_info.get('path', '')
                    }
                    
                    self.extensions.append(extension)
                    self.stats['installed_extensions'] += 1
            
            except Exception as e:
                print(f"{Colors.YELLOW}Warning: Could not parse extensions: {e}{Colors.ENDC}")
    
    def detect_incognito_usage(self):
        """Detect if incognito mode has been used"""
        prefs_file = self.profile_path / 'Preferences'
        
        if prefs_file.exists():
            try:
                with open(prefs_file, 'r') as f:
                    prefs = json.load(f)
                
                # Check for incognito mode indicators
                # Chrome tracks if incognito was used in session info
                session_data = prefs.get('profile', {}).get('exit_type', '')
                
                # This is a basic check - more sophisticated detection possible
                if 'incognito' in str(prefs).lower():
                    self.stats['incognito_detected'] = True
            
            except Exception:
                pass
    
    def generate_summary(self) -> Dict:
        """Generate analysis summary"""
        # Calculate date range
        earliest_date = None
        latest_date = None
        
        if self.urls:
            valid_timestamps = [u['last_visit_time'] for u in self.urls if u['last_visit_time']]
            if valid_timestamps:
                earliest_date = min(valid_timestamps)
                latest_date = max(valid_timestamps)
        
        # Top domains
        domain_counts = {}
        for url_data in self.urls:
            try:
                domain = urlparse(url_data['url']).netloc
                domain_counts[domain] = domain_counts.get(domain, 0) + url_data['visit_count']
            except Exception:
                continue
        
        top_domains = [
            {'domain': domain, 'visit_count': count}
            for domain, count in sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        ]
        
        return {
            'total_urls': self.stats['total_urls'],
            'unique_urls': self.stats['unique_urls'],
            'total_visits': self.stats['total_visits'],
            'date_range': {
                'earliest': earliest_date,
                'latest': latest_date
            },
            'downloads': self.stats['downloads'],
            'search_queries': self.stats['search_queries'],
            'suspicious_urls': self.stats['suspicious_urls'],
            'whitelisted_filtered': self.stats['whitelisted_filtered'],
            'installed_extensions': self.stats['installed_extensions'],
            'incognito_detected': self.stats['incognito_detected'],
            'top_domains': top_domains
        }
    
    def save_json(self, output_dir: Path, case_id: str):
        """Save results as JSON"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'chrome_history_{case_id}_{timestamp}.json'
        output_file = output_dir / filename
        
        # Build complete JSON output
        output_data = {
            'analysis_metadata': {
                'tool': 'chrome_history_analyzer',
                'version': '1.0',
                'analysis_timestamp_utc': self.analysis_timestamp,
                'case_id': case_id,
                'profile_path': str(self.profile_path),
                'history_file': str(self.profile_path / 'History'),
                'whitelist_applied': len(self.whitelist['domains']) > 0 or len(self.whitelist['extensions']) > 0,
                'whitelist_domains': len(self.whitelist['domains']),
                'whitelist_extensions': len(self.whitelist['extensions'])
            },
            'summary': self.generate_summary(),
            'findings': self.findings,
            'downloads': self.downloads,
            'search_queries': self.searches,
            'extensions': self.extensions,
            'timeline': {
                'timeline_format_version': '1.0',
                'events': sorted(self.timeline_events, key=lambda x: x['timestamp_utc'] or '')
            }
        }
        
        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2)
        
        # Calculate SHA-256 hash for evidence integrity
        sha256_hash = hashlib.sha256()
        with open(output_file, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        
        hash_file = output_dir / f'{filename}.sha256'
        with open(hash_file, 'w') as f:
            f.write(f"{sha256_hash.hexdigest()}  {filename}\n")
        
        print(f"{Colors.GREEN}✓ JSON saved: {output_file}{Colors.ENDC}")
        print(f"{Colors.GREEN}✓ SHA-256: {hash_file}{Colors.ENDC}")
    
    def save_csv(self, output_dir: Path, case_id: str):
        """Save findings as CSV"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'chrome_history_{case_id}_{timestamp}.csv'
        output_file = output_dir / filename
        
        with open(output_file, 'w', newline='') as f:
            if self.findings:
                fieldnames = ['url', 'title', 'visit_count', 'last_visit_time', 'severity', 'category', 'reason']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                
                for finding in self.findings:
                    writer.writerow({
                        'url': finding['url'],
                        'title': finding['title'],
                        'visit_count': finding['visit_count'],
                        'last_visit_time': finding['last_visit_time'],
                        'severity': finding['severity'],
                        'category': finding['category'],
                        'reason': finding['reason']
                    })
        
        print(f"{Colors.GREEN}✓ CSV saved: {output_file}{Colors.ENDC}")
    
    def save_markdown(self, output_dir: Path, case_id: str):
        """Save results as Markdown report"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'chrome_history_{case_id}_{timestamp}.md'
        output_file = output_dir / filename
        
        summary = self.generate_summary()
        
        with open(output_file, 'w') as f:
            # Header
            f.write(f"# Chrome History Analysis Report\n\n")
            f.write(f"**Case ID:** {case_id}  \n")
            f.write(f"**Analysis Timestamp:** {self.analysis_timestamp}  \n")
            f.write(f"**Profile:** {self.profile_path}  \n")
            f.write(f"**Tool:** chrome_history_analyzer v1.0  \n\n")
            
            f.write("---\n\n")
            
            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total URLs:** {summary['total_urls']:,}\n")
            f.write(f"- **Unique URLs:** {summary['unique_urls']:,}\n")
            f.write(f"- **Total Visits:** {summary['total_visits']:,}\n")
            f.write(f"- **Downloads:** {summary['downloads']:,}\n")
            f.write(f"- **Search Queries:** {summary['search_queries']:,}\n")
            f.write(f"- **Suspicious URLs:** {summary['suspicious_urls']:,}\n")
            f.write(f"- **Whitelisted (Filtered):** {summary['whitelisted_filtered']:,}\n")
            f.write(f"- **Installed Extensions:** {summary['installed_extensions']:,}\n")
            f.write(f"- **Incognito Mode Detected:** {'Yes' if summary['incognito_detected'] else 'No'}\n\n")
            
            if summary['date_range']['earliest'] and summary['date_range']['latest']:
                f.write(f"**Date Range:** {summary['date_range']['earliest']} to {summary['date_range']['latest']}\n\n")
            
            # Findings
            if self.findings:
                f.write("---\n\n")
                f.write("## 🔍 Suspicious Findings\n\n")
                
                # Group by severity
                high_findings = [f for f in self.findings if f['severity'] == 'HIGH']
                medium_findings = [f for f in self.findings if f['severity'] == 'MEDIUM']
                low_findings = [f for f in self.findings if f['severity'] == 'LOW']
                
                if high_findings:
                    f.write(f"### HIGH Severity ({len(high_findings)})\n\n")
                    for finding in high_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n")
                        f.write(f"- **Visit Count:** {finding['visit_count']}  \n\n")
                
                if medium_findings:
                    f.write(f"### MEDIUM Severity ({len(medium_findings)})\n\n")
                    for finding in medium_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n\n")
                
                if low_findings:
                    f.write(f"### LOW Severity ({len(low_findings)})\n\n")
                    for finding in low_findings[:10]:  # Limit to 10 for readability
                        f.write(f"- {finding['url']} ({finding['category']})\n")
                    if len(low_findings) > 10:
                        f.write(f"\n*...and {len(low_findings) - 10} more*\n")
            
            # Top Domains
            if summary['top_domains']:
                f.write("\n---\n\n")
                f.write("## 📊 Top Domains\n\n")
                for domain_info in summary['top_domains'][:10]:
                    f.write(f"- **{domain_info['domain']}** - {domain_info['visit_count']:,} visits\n")
            
            # Downloads
            if self.downloads:
                f.write("\n---\n\n")
                f.write(f"## 📥 Downloads ({len(self.downloads)})\n\n")
                for download in self.downloads[:20]:  # Limit to 20
                    f.write(f"**{Path(download['target_path']).name if download['target_path'] else 'Unknown'}**  \n")
                    f.write(f"- **URL:** {download['url']}  \n")
                    f.write(f"- **Path:** {download['target_path']}  \n")
                    f.write(f"- **Start:** {download['start_time']}  \n")
                    f.write(f"- **State:** {download['state']}  \n\n")
            
            # Search Queries
            if self.searches:
                f.write("\n---\n\n")
                f.write(f"## 🔍 Search Queries ({len(self.searches)})\n\n")
                for search in self.searches[:20]:  # Limit to 20
                    f.write(f"- **\"{search['query']}\"** ({search['search_engine']}) - {search['timestamp']}\n")
            
            # Extensions
            if self.extensions:
                f.write("\n---\n\n")
                f.write(f"## 🧩 Browser Extensions ({len(self.extensions)})\n\n")
                for ext in self.extensions:
                    status = "✓ Enabled" if ext['enabled'] else "✗ Disabled"
                    f.write(f"- **{ext['name']}** v{ext['version']} ({status})\n")
            
            f.write("\n---\n\n")
            f.write("*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*\n")
        
        print(f"{Colors.GREEN}✓ Markdown saved: {output_file}{Colors.ENDC}")
    
    def run(self, output_dir: Path, verbose: bool = False):
        """Run complete analysis"""
        print(f"\n{Colors.CYAN}{'=' * 70}{Colors.ENDC}")
        print(f"{Colors.CYAN}{Colors.BOLD}{'Chrome History Analyzer'.center(70)}{Colors.ENDC}")
        print(f"{Colors.CYAN}{'=' * 70}{Colors.ENDC}\n")
        
        print(f"{Colors.BOLD}Case ID:{Colors.ENDC} {self.case_id}")
        print(f"{Colors.BOLD}Profile:{Colors.ENDC} {self.profile_path}")
        print(f"{Colors.BOLD}Analysis Time:{Colors.ENDC} {self.analysis_timestamp}\n")
        
        # Extract data
        steps = [
            ("Extracting URL history", self.extract_history),
            ("Extracting downloads", self.extract_downloads),
            ("Extracting search queries", self.extract_searches),
            ("Extracting extensions", self.extract_extensions),
            ("Detecting incognito usage", self.detect_incognito_usage)
        ]
        
        for step_name, step_func in steps:
            if verbose:
                print(f"{Colors.CYAN}→ {step_name}...{Colors.ENDC}")
            try:
                step_func()
                if verbose:
                    print(f"{Colors.GREEN}  ✓ Complete{Colors.ENDC}")
            except Exception as e:
                print(f"{Colors.RED}  ✗ Error: {e}{Colors.ENDC}")
        
        # Save outputs
        print(f"\n{Colors.BOLD}Saving results...{Colors.ENDC}\n")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        self.save_json(output_dir, self.case_id)
        self.save_csv(output_dir, self.case_id)
        self.save_markdown(output_dir, self.case_id)
        
        # Print summary
        print(f"\n{Colors.BOLD}Analysis Summary:{Colors.ENDC}")
        print(f"  URLs: {self.stats['total_urls']:,}")
        print(f"  Downloads: {self.stats['downloads']:,}")
        print(f"  Searches: {self.stats['search_queries']:,}")
        print(f"  Suspicious: {self.stats['suspicious_urls']:,}")
        print(f"  Whitelisted: {self.stats['whitelisted_filtered']:,}")
        print(f"  Extensions: {self.stats['installed_extensions']:,}")
        
        print(f"\n{Colors.GREEN}✓ Analysis complete!{Colors.ENDC}\n")


def main():
    parser = argparse.ArgumentParser(
        description='Chrome History Analyzer - Forensic browser history extraction',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze current user's Chrome history
  %(prog)s
  
  # Analyze specific profile
  %(prog)s -p ~/Library/Application\ Support/Google/Chrome/Profile\ 1/
  
  # Use whitelist and specify case ID
  %(prog)s -w chrome_whitelist.txt --case-id CASE-001
  
  # Filter by date range
  %(prog)s --after 2025-12-01 --before 2025-12-31
  
  # Output to specific directory
  %(prog)s -o /evidence/chrome_analysis/ --case-id CASE-001 -v

Part of: Apple FORENSICS • Backwater Forensics
        """
    )
    
    parser.add_argument('-p', '--profile', help='Chrome profile path')
    parser.add_argument('-o', '--output', default='.', help='Output directory (default: current)')
    parser.add_argument('--case-id', default='UNKNOWN', help='Case ID for tracking')
    parser.add_argument('-w', '--whitelist', action='append', help='Whitelist file (can specify multiple)')
    parser.add_argument('--after', help='Filter URLs after this date (YYYY-MM-DD)')
    parser.add_argument('--before', help='Filter URLs before this date (YYYY-MM-DD)')
    parser.add_argument('--last-days', type=int, help='Filter to last N days')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    try:
        # Initialize analyzer
        analyzer = ChromeHistoryAnalyzer(
            profile_path=args.profile,
            case_id=args.case_id
        )
        
        # Load whitelists
        if args.whitelist:
            for whitelist_file in args.whitelist:
                analyzer.load_whitelist(whitelist_file)
        
        # Run analysis
        output_dir = Path(args.output).expanduser()
        analyzer.run(output_dir, verbose=args.verbose)
        
        return 0
    
    except FileNotFoundError as e:
        print(f"{Colors.RED}Error: {e}{Colors.ENDC}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"{Colors.RED}Unexpected error: {e}{Colors.ENDC}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
