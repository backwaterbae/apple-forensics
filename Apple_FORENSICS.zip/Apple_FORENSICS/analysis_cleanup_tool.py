#!/usr/bin/env python3
"""
Analysis Cleanup Tool
Retroactively applies whitelist filtering to existing analysis results

Part of: Backwater Forensics • Apple FORENSICS
Purpose: Filter false positives from completed analyses using updated whitelists
Author: Apple FORENSICS Project
Version: 1.0
"""

import json
import csv
import sys
import os
from pathlib import Path
from datetime import datetime
import argparse
import hashlib


class SignatureManager:
    """Manages pattern signatures for matching (reused from log_directory_analyzer)"""
    
    def __init__(self):
        self.patterns = []
    
    def load_from_file(self, filepath):
        """Load patterns from file"""
        loaded = 0
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    # Parse pattern format: TYPE:pattern|CATEGORY:cat|SEVERITY:sev
                    self.patterns.append(line.lower())
                    loaded += 1
        except Exception as e:
            print(f"Error loading {filepath}: {e}", file=sys.stderr)
        
        return loaded
    
    def matches_line(self, line):
        """Check if line matches any whitelist pattern"""
        line_lower = line.lower()
        for pattern in self.patterns:
            # Extract just the pattern part (before |)
            if '|' in pattern:
                pattern_text = pattern.split('|')[0]
                if ':' in pattern_text:
                    pattern_text = pattern_text.split(':', 1)[1]
            else:
                pattern_text = pattern
            
            # Simple substring match for whitelist
            if pattern_text in line_lower:
                return True
        
        return False


class AnalysisCleanupTool:
    """Retroactively filter false positives from analysis results"""
    
    def __init__(self, input_path, whitelist_files, output_dir, verbose=False):
        self.input_path = Path(input_path)
        self.whitelist_files = whitelist_files
        self.output_dir = Path(output_dir)
        self.verbose = verbose
        self.whitelist = SignatureManager()
        self.stats = {
            'files_processed': 0,
            'total_original_findings': 0,
            'total_filtered_findings': 0,
            'total_remaining_findings': 0,
            'filtered_by_category': {},
            'filtered_by_severity': {}
        }
    
    def log(self, message):
        """Print verbose messages"""
        if self.verbose:
            print(f"[*] {message}")
    
    def load_whitelists(self):
        """Load all whitelist files"""
        total_entries = 0
        
        print("\nLoading whitelists...")
        for whitelist_file in self.whitelist_files:
            whitelist_path = Path(whitelist_file)
            if not whitelist_path.exists():
                print(f"  ⚠️  Whitelist not found: {whitelist_file}")
                continue
            
            loaded = self.whitelist.load_from_file(whitelist_path)
            total_entries += loaded
            print(f"  ✓ Loaded {loaded} entries from {whitelist_file}")
        
        if total_entries == 0:
            print("  ⚠️  No whitelist entries loaded")
            return False
        
        print(f"\n✓ Total whitelist entries: {total_entries}")
        return True
    
    def find_analysis_files(self):
        """Find JSON analysis files to process"""
        analysis_files = []
        
        if self.input_path.is_file():
            # Single file
            if self.input_path.suffix == '.json':
                analysis_files.append(self.input_path)
        else:
            # Directory - find all analysis JSON files
            for json_file in self.input_path.rglob('*.json'):
                # Skip investigation metadata and reports
                if ('investigation.json' in json_file.name or
                    'reports' in json_file.parts or
                    'status_report' in json_file.name):
                    continue
                
                # Look for analysis files with findings
                try:
                    with open(json_file) as f:
                        data = json.load(f)
                        if 'findings' in data:
                            analysis_files.append(json_file)
                except:
                    pass
        
        return analysis_files
    
    def apply_whitelist_filter(self, findings):
        """Filter findings against whitelist"""
        filtered = []
        removed = []
        
        for finding in findings:
            # Check if finding matches whitelist
            should_filter = False
            
            # Check context field
            context = finding.get('context', '')
            if context and self.whitelist.matches_line(context):
                should_filter = True
            
            # Check pattern field
            pattern = finding.get('pattern', '')
            if pattern and self.whitelist.matches_line(pattern):
                should_filter = True
            
            # Check command field (for home directory analysis)
            command = finding.get('command', '')
            if command and self.whitelist.matches_line(command):
                should_filter = True
            
            if should_filter:
                removed.append(finding)
                # Track what was filtered
                category = finding.get('category', 'Unknown')
                severity = finding.get('severity', 'Unknown')
                self.stats['filtered_by_category'][category] = \
                    self.stats['filtered_by_category'].get(category, 0) + 1
                self.stats['filtered_by_severity'][severity] = \
                    self.stats['filtered_by_severity'].get(severity, 0) + 1
            else:
                filtered.append(finding)
        
        return filtered, removed
    
    def generate_reports(self, cleaned_data, original_file):
        """Generate cleaned JSON/CSV/Markdown reports"""
        # Determine base name
        base_name = original_file.stem
        if base_name.endswith('_cleaned'):
            base_name = base_name[:-8]  # Remove existing _cleaned suffix
        
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        
        # Generate JSON
        json_file = self.output_dir / f"{base_name}_cleaned.json"
        with open(json_file, 'w') as f:
            json.dump(cleaned_data, f, indent=2, default=str)
        self.log(f"Generated: {json_file.name}")
        
        # Generate CSV (if findings exist)
        if cleaned_data.get('findings'):
            csv_file = self.output_dir / f"{base_name}_cleaned.csv"
            with open(csv_file, 'w', newline='') as f:
                writer = csv.writer(f)
                
                # Write header
                writer.writerow([
                    'Timestamp', 'Severity', 'Category', 'Pattern',
                    'Log File', 'Line Number', 'Context'
                ])
                
                # Write findings
                for finding in cleaned_data['findings']:
                    writer.writerow([
                        finding.get('artifact_timestamp', ''),
                        finding.get('severity', ''),
                        finding.get('category', ''),
                        finding.get('pattern', ''),
                        finding.get('log_file', finding.get('file', '')),
                        finding.get('line_number', ''),
                        finding.get('context', finding.get('command', ''))[:200]
                    ])
            
            self.log(f"Generated: {csv_file.name}")
        
        # Generate Markdown
        md_file = self.output_dir / f"{base_name}_cleaned.md"
        self._generate_markdown(cleaned_data, md_file, original_file)
        self.log(f"Generated: {md_file.name}")
        
        return json_file
    
    def _generate_markdown(self, data, filepath, original_file):
        """Generate human-readable Markdown report"""
        with open(filepath, 'w') as f:
            # Header
            f.write(f"# Analysis Report (Cleaned)\n\n")
            f.write(f"**Original File:** {original_file.name}\n")
            f.write(f"**Cleaned:** {datetime.utcnow().isoformat()}Z\n")
            f.write(f"**Tool:** Apple FORENSICS Analysis Cleanup Tool v1.0\n\n")
            
            # Metadata
            metadata = data.get('analysis_metadata', {})
            if metadata:
                f.write("## Analysis Metadata\n\n")
                f.write(f"- **Tool Version:** {metadata.get('tool_version', 'unknown')}\n")
                f.write(f"- **Analysis Time:** {metadata.get('analysis_timestamp_utc', 'unknown')}\n")
                f.write(f"- **Target:** {metadata.get('home_directory', metadata.get('log_directories', 'unknown'))}\n\n")
            
            # Summary
            findings = data.get('findings', [])
            if not findings:
                f.write("## Summary\n\n")
                f.write("✅ **No findings after whitelist filtering**\n\n")
                return
            
            # Count by severity
            severity_counts = {}
            category_counts = {}
            for finding in findings:
                sev = finding.get('severity', 'UNKNOWN')
                cat = finding.get('category', 'Unknown')
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
                category_counts[cat] = category_counts.get(cat, 0) + 1
            
            f.write("## Summary\n\n")
            f.write(f"**Total Findings:** {len(findings)}\n\n")
            f.write("**By Severity:**\n")
            for sev in ['HIGH', 'MEDIUM', 'LOW']:
                if sev in severity_counts:
                    f.write(f"- **{sev}:** {severity_counts[sev]}\n")
            f.write("\n")
            
            # Top categories
            f.write("**Top Categories:**\n")
            sorted_cats = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:10]
            for cat, count in sorted_cats:
                f.write(f"- {cat}: {count}\n")
            f.write("\n")
            
            # Findings by severity
            for severity in ['HIGH', 'MEDIUM', 'LOW']:
                sev_findings = [f for f in findings if f.get('severity') == severity]
                if not sev_findings:
                    continue
                
                f.write(f"## {severity} Severity Findings ({len(sev_findings)})\n\n")
                
                for i, finding in enumerate(sev_findings[:50], 1):  # Limit to 50 per severity
                    f.write(f"### Finding #{i}\n\n")
                    f.write(f"**Category:** {finding.get('category', 'Unknown')}\n")
                    f.write(f"**Pattern:** {finding.get('pattern', 'N/A')}\n")
                    
                    if 'log_file' in finding:
                        f.write(f"**Log File:** {finding.get('log_file')}\n")
                        f.write(f"**Line:** {finding.get('line_number', 'N/A')}\n")
                    
                    if 'file' in finding:
                        f.write(f"**File:** {finding.get('file')}\n")
                    
                    if 'command' in finding:
                        f.write(f"**Command:** `{finding.get('command')}`\n")
                    
                    if 'context' in finding:
                        context = finding.get('context', '')[:300]
                        f.write(f"**Context:** {context}\n")
                    
                    f.write("\n---\n\n")
                
                if len(sev_findings) > 50:
                    f.write(f"*... and {len(sev_findings) - 50} more {severity} findings*\n\n")
    
    def process_file(self, json_file):
        """Process a single analysis file"""
        self.log(f"Processing: {json_file.name}")
        
        try:
            # Load original data
            with open(json_file) as f:
                data = json.load(f)
            
            original_findings = data.get('findings', [])
            if not original_findings:
                self.log(f"  No findings in {json_file.name}")
                return None
            
            original_count = len(original_findings)
            self.stats['total_original_findings'] += original_count
            
            # Apply whitelist filter
            filtered_findings, removed_findings = self.apply_whitelist_filter(original_findings)
            
            filtered_count = len(removed_findings)
            remaining_count = len(filtered_findings)
            
            self.stats['total_filtered_findings'] += filtered_count
            self.stats['total_remaining_findings'] += remaining_count
            
            self.log(f"  Original: {original_count}, Filtered: {filtered_count}, Remaining: {remaining_count}")
            
            # Create cleaned data
            cleaned_data = data.copy()
            cleaned_data['findings'] = filtered_findings
            cleaned_data['cleanup_metadata'] = {
                'cleanup_timestamp': datetime.utcnow().isoformat() + 'Z',
                'cleanup_tool': 'analysis_cleanup_tool.py v1.0',
                'original_findings_count': original_count,
                'filtered_findings_count': filtered_count,
                'remaining_findings_count': remaining_count,
                'whitelist_files': self.whitelist_files
            }
            
            # Generate reports
            output_file = self.generate_reports(cleaned_data, json_file)
            
            self.stats['files_processed'] += 1
            return output_file
            
        except Exception as e:
            print(f"  ✗ Error processing {json_file.name}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def show_summary(self):
        """Display cleanup summary"""
        print("\n" + "="*70)
        print("CLEANUP SUMMARY".center(70))
        print("="*70)
        
        print(f"\nFiles processed:     {self.stats['files_processed']}")
        print(f"Original findings:   {self.stats['total_original_findings']}")
        print(f"Filtered findings:   {self.stats['total_filtered_findings']} ", end='')
        
        if self.stats['total_original_findings'] > 0:
            pct = (self.stats['total_filtered_findings'] / self.stats['total_original_findings']) * 100
            print(f"({pct:.1f}%)")
        else:
            print()
        
        print(f"Remaining findings:  {self.stats['total_remaining_findings']}")
        
        # Show what was filtered by category
        if self.stats['filtered_by_category']:
            print("\nFiltered by category:")
            sorted_cats = sorted(self.stats['filtered_by_category'].items(), 
                               key=lambda x: x[1], reverse=True)
            for cat, count in sorted_cats[:10]:
                print(f"  {cat}: {count}")
        
        # Show what was filtered by severity
        if self.stats['filtered_by_severity']:
            print("\nFiltered by severity:")
            for sev in ['HIGH', 'MEDIUM', 'LOW']:
                if sev in self.stats['filtered_by_severity']:
                    print(f"  {sev}: {self.stats['filtered_by_severity'][sev]}")
        
        print(f"\nCleaned reports saved to: {self.output_dir}")
        print("="*70)
    
    def run(self):
        """Main cleanup process"""
        print("="*70)
        print("ANALYSIS CLEANUP TOOL".center(70))
        print("="*70)
        
        # Load whitelists
        if not self.load_whitelists():
            print("\n✗ No whitelist entries loaded. Cannot proceed.")
            return 1
        
        # Find analysis files
        print("\nScanning for analysis files...")
        analysis_files = self.find_analysis_files()
        
        if not analysis_files:
            print(f"✗ No analysis files found in: {self.input_path}")
            return 1
        
        print(f"✓ Found {len(analysis_files)} analysis file(s)")
        
        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Process each file
        print("\nApplying whitelist filters...")
        for json_file in analysis_files:
            self.process_file(json_file)
        
        # Show summary
        self.show_summary()
        
        return 0


def main():
    parser = argparse.ArgumentParser(
        description='Retroactively filter false positives from analysis results',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Clean single analysis file
  %(prog)s -f log_analysis_20251230.json -w macos_whitelist.txt -o cleaned/
  
  # Clean entire investigation directory
  %(prog)s -i Investigations/CASE-001/ -w macos_whitelist.txt apple_forensics_whitelist.txt -o Investigations/CASE-001/cleaned/
  
  # Clean with verbose output
  %(prog)s -i analysis_dir/ -w whitelist1.txt whitelist2.txt -o cleaned/ -v

The tool will:
  1. Load whitelist files
  2. Find all analysis JSON files
  3. Filter out whitelisted findings
  4. Generate cleaned JSON/CSV/Markdown reports
  5. Show before/after statistics

Output files are named: <original>_cleaned.json/csv/md
        """
    )
    
    # Input options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('-f', '--file',
                            help='Single analysis JSON file to clean')
    input_group.add_argument('-i', '--input-dir',
                            help='Directory containing analysis files to clean')
    
    # Whitelist files
    parser.add_argument('-w', '--whitelist', nargs='+', required=True,
                       help='Whitelist file(s) to use for filtering (e.g., macos_whitelist.txt)')
    
    # Output directory
    parser.add_argument('-o', '--output', required=True,
                       help='Output directory for cleaned reports')
    
    # Verbose flag
    parser.add_argument('-v', '--verbose',
                       action='store_true',
                       help='Enable verbose output')
    
    args = parser.parse_args()
    
    # Determine input path
    input_path = Path(args.file) if args.file else Path(args.input_dir)
    
    if not input_path.exists():
        print(f"Error: Input path does not exist: {input_path}")
        return 1
    
    # Create cleanup tool
    cleanup = AnalysisCleanupTool(
        input_path=input_path,
        whitelist_files=args.whitelist,
        output_dir=args.output,
        verbose=args.verbose
    )
    
    # Run cleanup
    try:
        return cleanup.run()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        return 1
    except Exception as e:
        print(f"\n✗ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
