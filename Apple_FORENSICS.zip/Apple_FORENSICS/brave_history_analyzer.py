#!/usr/bin/env python3
"""
Brave History Analyzer
======================
Extract and analyze Brave browser history for forensic investigation.

Note: Brave is Chromium-based and uses the same database structure as Chrome,
but with different default paths and privacy-focused user demographics.

Features:
- URL history extraction with timestamps
- Download history analysis
- Search query extraction
- Browser extension detection
- Suspicious URL detection with whitelist support
- Timeline reconstruction (standardized JSON format)
- Multi-format output (JSON/CSV/Markdown)

Part of: Backwater Forensics • Apple FORENSICS • Victim Investigator Approach
Phase: 3 Module 2
Version: 1.0
"""

import sys
import os
import json
import csv
import sqlite3
import shutil
import argparse
import re
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Tuple
from urllib.parse import urlparse
import hashlib


# Terminal colors
class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    ORANGE = '\033[38;5;208m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


class BraveHistoryAnalyzer:
    """Analyze Brave browser history for forensic investigation"""
    
    def __init__(self, profile_path: Optional[str] = None, case_id: str = "UNKNOWN", suspicious_only: bool = False):
        """
        Initialize Brave history analyzer
        
        Args:
            profile_path: Path to Brave profile (default: ~/Library/Application Support/BraveSoftware/Brave-Browser/Default)
            case_id: Case ID for forensic tracking
            suspicious_only: If True, only output suspicious URLs in reports
        """
        self.case_id = case_id
        self.profile_path = self._resolve_profile_path(profile_path)
        self.suspicious_only = suspicious_only
        self.analysis_timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # Whitelist storage
        self.whitelist = {
            'domains': set(),
            'extensions': set()
        }
        
        # Results storage
        self.urls = []
        self.downloads = []
        self.search_queries = []
        self.extensions = []
        self.findings = []
        self.timeline_events = []
        
        # Statistics
        self.stats = {
            'total_urls': 0,
            'unique_urls': 0,
            'downloads': 0,
            'search_queries': 0,
            'installed_extensions': 0,
            'suspicious_urls': 0,
            'whitelisted_filtered': 0
        }
    
    def _resolve_profile_path(self, profile_path: Optional[str]) -> Path:
        """Resolve Brave profile path"""
        if profile_path:
            return Path(profile_path).expanduser()
        
        # Default Brave profile location on macOS
        default_profile = Path.home() / 'Library/Application Support/BraveSoftware/Brave-Browser/Default'
        
        if not default_profile.exists():
            raise FileNotFoundError(
                f"Brave profile not found: {default_profile}\n"
                "Use -p to specify profile path"
            )
        
        return default_profile
    
    @staticmethod
    def chrome_time_to_datetime(chrome_time: int) -> Optional[str]:
        """
        Convert Chromium/Brave timestamp to UTC datetime string
        
        Brave uses Chromium's timestamp format: microseconds since 1601-01-01 (WebKit epoch)
        
        Args:
            chrome_time: Brave timestamp in microseconds
            
        Returns:
            ISO format UTC timestamp with 'Z' suffix, or None if invalid
        """
        if chrome_time == 0:
            return None
        
        try:
            # Windows/WebKit epoch: 1601-01-01
            # Unix epoch: 1970-01-01
            # Difference: 11644473600 seconds
            epoch_diff = 11644473600
            
            # Convert microseconds to seconds, then adjust epoch
            unix_timestamp = (chrome_time / 1000000) - epoch_diff
            
            # Create UTC datetime with 'Z' suffix
            dt = datetime.fromtimestamp(unix_timestamp, tz=timezone.utc)
            return dt.isoformat().replace('+00:00', 'Z')
        except (ValueError, OSError):
            return None
    
    def load_whitelist(self, whitelist_file: str):
        """
        Load domain and extension whitelist from file
        
        Args:
            whitelist_file: Path to whitelist file
        """
        whitelist_path = Path(whitelist_file)
        
        if not whitelist_path.exists():
            print(f"{Colors.YELLOW}Warning: Whitelist file not found: {whitelist_file}{Colors.ENDC}")
            return
        
        with open(whitelist_path, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Parse DOMAIN: entries
                if line.startswith('DOMAIN:'):
                    domain = line.split('|')[0].replace('DOMAIN:', '').strip()
                    self.whitelist['domains'].add(domain)
                
                # Parse EXTENSION: entries
                elif line.startswith('EXTENSION:'):
                    ext = line.split('|')[0].replace('EXTENSION:', '').strip()
                    self.whitelist['extensions'].add(ext)
        
        print(f"{Colors.GREEN}✓ Loaded {len(self.whitelist['domains'])} domains, {len(self.whitelist['extensions'])} extensions{Colors.ENDC}")
    
    def is_whitelisted(self, url: str) -> Tuple[bool, Optional[str]]:
        """
        Check if URL is whitelisted
        
        Args:
            url: URL to check
            
        Returns:
            (is_whitelisted, reason)
        """
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            extension = Path(parsed.path).suffix.lower()
            
            # Check domain whitelist
            for whitelisted_domain in self.whitelist['domains']:
                if domain.endswith(whitelisted_domain):
                    return True, f"Whitelisted domain: {whitelisted_domain}"
            
            # Check extension whitelist
            if extension and extension in self.whitelist['extensions']:
                return True, f"Whitelisted extension: {extension}"
            
            return False, None
        
        except Exception:
            return False, None
    
    def analyze_url_for_threats(self, url: str) -> Optional[Dict]:
        """
        Analyze URL for suspicious patterns
        
        Args:
            url: URL to analyze
            
        Returns:
            Finding dictionary if suspicious, None if benign
        """
        # Check whitelist first
        is_whitelisted_flag, whitelist_reason = self.is_whitelisted(url)
        if is_whitelisted_flag:
            self.stats['whitelisted_filtered'] += 1
            return None
        
        indicators = []
        severity = 'LOW'
        category = 'Suspicious URL'
        
        # Executable downloads
        if re.search(r'\.(exe|dll|bat|cmd|vbs|ps1|scr|app)$', url, re.IGNORECASE):
            indicators.append('Executable file extension')
            severity = 'HIGH'
            category = 'Suspicious Download'
        
        # Known malicious TLDs
        if re.search(r'\.(xyz|top|tk|ml|ga|cf|gq)$', url, re.IGNORECASE):
            indicators.append('Suspicious TLD')
            severity = 'MEDIUM'
            category = 'Suspicious Domain'
        
        # IP address URLs
        if re.search(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
            indicators.append('Direct IP access')
            severity = 'MEDIUM'
            category = 'Direct IP Access'
        
        # Typosquatting patterns
        typosquat_patterns = [
            'gooogle', 'faceboook', 'amazoon', 'paypa1', 'microsft',
            'netfliix', 'appleid-secure', 'icloud-verify', 'coinbrase', 'metamask-secure'
        ]
        url_lower = url.lower()
        for pattern in typosquat_patterns:
            if pattern in url_lower:
                indicators.append('Possible typosquatting')
                severity = 'HIGH'
                category = 'Typosquatting'
                break
        
        # Suspicious keywords
        suspicious_keywords = ['malware', 'keylog', 'crack', 'keygen', 'hack']
        for keyword in suspicious_keywords:
            if keyword in url_lower:
                indicators.append(f'Suspicious keyword: {keyword}')
                severity = 'HIGH'
                category = 'Suspicious Content'
                break
        
        if indicators:
            self.stats['suspicious_urls'] += 1
            return {
                'severity': severity,
                'category': category,
                'reason': ', '.join(indicators)
            }
        
        return None
    
    def extract_history(self):
        """Extract URL history from Brave History database"""
        history_db = self.profile_path / 'History'
        
        if not history_db.exists():
            raise FileNotFoundError(f"Brave History database not found: {history_db}")
        
        # Create temporary copy to avoid locking
        temp_db = f'/tmp/brave_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract URLs (Chromium schema)
            cursor.execute("""
                SELECT 
                    urls.id,
                    urls.url,
                    urls.title,
                    urls.visit_count,
                    urls.last_visit_time
                FROM urls
                ORDER BY urls.last_visit_time DESC
            """)
            
            for row in cursor.fetchall():
                url_id, url, title, visit_count, last_visit_time = row
                
                if not url:
                    continue
                
                # Convert timestamp
                timestamp_utc = self.chrome_time_to_datetime(last_visit_time)
                
                url_data = {
                    'url_id': url_id,
                    'url': url,
                    'title': title or '',
                    'visit_count': visit_count or 0,
                    'last_visit_time': timestamp_utc
                }
                
                self.urls.append(url_data)
                self.stats['total_urls'] += 1
                
                # Check for suspicious URLs
                threat_analysis = self.analyze_url_for_threats(url)
                if threat_analysis:
                    finding = {
                        **url_data,
                        **threat_analysis
                    }
                    self.findings.append(finding)
                    
                    # Add to timeline
                    if timestamp_utc:
                        self.timeline_events.append({
                            'timestamp_utc': timestamp_utc,
                            'event_type': 'browser_visit',
                            'source_artifact': 'brave_history',
                            'artifact_path': str(history_db),
                            'browser': 'brave',
                            'profile': 'Default',
                            'details': {
                                'url': url,
                                'title': title or '',
                                'visit_count': visit_count,
                                'severity': threat_analysis['severity'],
                                'category': threat_analysis['category'],
                                'reason': threat_analysis['reason']
                            }
                        })
            
            self.stats['unique_urls'] = len(set(u['url'] for u in self.urls))
            
            conn.close()
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_downloads(self):
        """Extract download history from Brave History database"""
        history_db = self.profile_path / 'History'
        temp_db = f'/tmp/brave_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract downloads (Chromium schema)
            cursor.execute("""
                SELECT 
                    downloads.id,
                    downloads.target_path,
                    downloads.tab_url,
                    downloads.start_time,
                    downloads.received_bytes,
                    downloads.total_bytes
                FROM downloads
                ORDER BY downloads.start_time DESC
            """)
            
            for row in cursor.fetchall():
                download_id, target_path, tab_url, start_time, received_bytes, total_bytes = row
                
                # Convert timestamp
                timestamp_utc = self.chrome_time_to_datetime(start_time) if start_time else None
                
                download_data = {
                    'download_id': download_id,
                    'path': target_path or '',
                    'url': tab_url or '',
                    'download_time': timestamp_utc,
                    'bytes_received': received_bytes or 0,
                    'bytes_total': total_bytes or 0
                }
                
                self.downloads.append(download_data)
                self.stats['downloads'] += 1
                
                # Add to timeline
                if timestamp_utc and tab_url:
                    self.timeline_events.append({
                        'timestamp_utc': timestamp_utc,
                        'event_type': 'browser_download',
                        'source_artifact': 'brave_history',
                        'artifact_path': str(history_db),
                        'browser': 'brave',
                        'profile': 'Default',
                        'details': {
                            'url': tab_url,
                            'path': target_path or '',
                            'bytes': total_bytes or 0
                        }
                    })
            
            conn.close()
        
        except Exception as e:
            print(f"{Colors.YELLOW}Note: Could not extract downloads: {e}{Colors.ENDC}")
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_search_queries(self):
        """Extract search queries from Brave History database"""
        history_db = self.profile_path / 'History'
        temp_db = f'/tmp/brave_history_{self.case_id}_{os.getpid()}.db'
        shutil.copy2(history_db, temp_db)
        
        try:
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            
            # Extract search queries (Chromium schema)
            cursor.execute("""
                SELECT 
                    keyword_search_terms.term,
                    keyword_search_terms.url_id,
                    urls.url,
                    urls.last_visit_time
                FROM keyword_search_terms
                LEFT JOIN urls ON keyword_search_terms.url_id = urls.id
                ORDER BY urls.last_visit_time DESC
            """)
            
            for row in cursor.fetchall():
                term, url_id, url, last_visit_time = row
                
                # Convert timestamp
                timestamp_utc = self.chrome_time_to_datetime(last_visit_time) if last_visit_time else None
                
                search_data = {
                    'term': term or '',
                    'url': url or '',
                    'timestamp': timestamp_utc
                }
                
                self.search_queries.append(search_data)
                self.stats['search_queries'] += 1
            
            conn.close()
        
        except Exception as e:
            print(f"{Colors.YELLOW}Note: Could not extract search queries: {e}{Colors.ENDC}")
        
        finally:
            if os.path.exists(temp_db):
                os.remove(temp_db)
    
    def extract_extensions(self):
        """Extract installed extensions from Brave Preferences"""
        preferences_file = self.profile_path / 'Preferences'
        
        if not preferences_file.exists():
            print(f"{Colors.YELLOW}Note: Preferences file not found{Colors.ENDC}")
            return
        
        try:
            with open(preferences_file, 'r') as f:
                prefs = json.load(f)
            
            # Extract extensions
            extensions_data = prefs.get('extensions', {}).get('settings', {})
            
            for ext_id, ext_info in extensions_data.items():
                extension_data = {
                    'id': ext_id,
                    'name': ext_info.get('manifest', {}).get('name', 'Unknown'),
                    'version': ext_info.get('manifest', {}).get('version', 'Unknown'),
                    'description': ext_info.get('manifest', {}).get('description', '')
                }
                
                self.extensions.append(extension_data)
                self.stats['installed_extensions'] += 1
        
        except Exception as e:
            print(f"{Colors.YELLOW}Note: Could not extract extensions: {e}{Colors.ENDC}")
    
    def generate_summary(self) -> Dict:
        """Generate analysis summary"""
        # Calculate date range
        earliest_date = None
        latest_date = None
        
        if self.urls:
            valid_timestamps = [u['last_visit_time'] for u in self.urls if u['last_visit_time']]
            if valid_timestamps:
                earliest_date = min(valid_timestamps)
                latest_date = max(valid_timestamps)
        
        # Top domains
        domain_counts = {}
        for url_data in self.urls:
            try:
                domain = urlparse(url_data['url']).netloc
                domain_counts[domain] = domain_counts.get(domain, 0) + url_data['visit_count']
            except Exception:
                continue
        
        top_domains = [
            {'domain': domain, 'visit_count': count}
            for domain, count in sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        ]
        
        return {
            'total_urls': self.stats['total_urls'],
            'unique_urls': self.stats['unique_urls'],
            'date_range': {
                'earliest': earliest_date,
                'latest': latest_date
            },
            'downloads': self.stats['downloads'],
            'search_queries': self.stats['search_queries'],
            'installed_extensions': self.stats['installed_extensions'],
            'suspicious_urls': self.stats['suspicious_urls'],
            'whitelisted_filtered': self.stats['whitelisted_filtered'],
            'top_domains': top_domains
        }
    
    def save_json(self, output_dir: Path, case_id: str):
        """Save results as JSON"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'brave_history_{case_id}_{timestamp}.json'
        output_file = output_dir / filename
        
        # Build complete JSON output
        output_data = {
            'analysis_metadata': {
                'tool': 'brave_history_analyzer',
                'version': '1.0',
                'analysis_timestamp_utc': self.analysis_timestamp,
                'case_id': case_id,
                'profile_path': str(self.profile_path),
                'history_file': str(self.profile_path / 'History'),
                'suspicious_only_mode': self.suspicious_only,
                'whitelist_applied': len(self.whitelist['domains']) > 0 or len(self.whitelist['extensions']) > 0,
                'whitelist_domains': len(self.whitelist['domains']),
                'whitelist_extensions': len(self.whitelist['extensions'])
            },
            'summary': self.generate_summary(),
            'findings': self.findings,
            'downloads': self.downloads,
            'search_queries': self.search_queries,
            'extensions': self.extensions,
            'timeline': {
                'timeline_format_version': '1.0',
                'events': sorted(self.timeline_events, key=lambda x: x['timestamp_utc'] or '')
            }
        }
        
        # Include all URLs if not in suspicious-only mode
        if not self.suspicious_only:
            output_data['all_urls'] = self.urls
        
        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2)
        
        # Calculate SHA-256 hash for evidence integrity
        sha256_hash = hashlib.sha256()
        with open(output_file, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        
        hash_file = output_dir / f'{filename}.sha256'
        with open(hash_file, 'w') as f:
            f.write(f"{sha256_hash.hexdigest()}  {filename}\n")
        
        print(f"{Colors.GREEN}✓ JSON saved: {output_file}{Colors.ENDC}")
        print(f"{Colors.GREEN}✓ SHA-256: {hash_file}{Colors.ENDC}")
    
    def save_csv(self, output_dir: Path, case_id: str):
        """Save findings as CSV"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'brave_history_{case_id}_{timestamp}.csv'
        output_file = output_dir / filename
        
        with open(output_file, 'w', newline='') as f:
            if self.suspicious_only:
                # Only suspicious URLs
                if self.findings:
                    fieldnames = ['url', 'title', 'visit_count', 'last_visit_time', 'severity', 'category', 'reason']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    for finding in self.findings:
                        writer.writerow({
                            'url': finding['url'],
                            'title': finding['title'],
                            'visit_count': finding['visit_count'],
                            'last_visit_time': finding['last_visit_time'],
                            'severity': finding['severity'],
                            'category': finding['category'],
                            'reason': finding['reason']
                        })
            else:
                # All URLs
                if self.urls:
                    fieldnames = ['url', 'title', 'visit_count', 'last_visit_time', 'suspicious', 'severity', 'category', 'reason']
                    writer = csv.DictWriter(f, fieldnames=fieldnames)
                    writer.writeheader()
                    
                    # Create lookup for findings
                    findings_dict = {f['url']: f for f in self.findings}
                    
                    for url_data in self.urls:
                        url = url_data['url']
                        row = {
                            'url': url,
                            'title': url_data['title'],
                            'visit_count': url_data['visit_count'],
                            'last_visit_time': url_data['last_visit_time'],
                            'suspicious': 'Yes' if url in findings_dict else 'No',
                            'severity': findings_dict[url]['severity'] if url in findings_dict else '',
                            'category': findings_dict[url]['category'] if url in findings_dict else '',
                            'reason': findings_dict[url]['reason'] if url in findings_dict else ''
                        }
                        writer.writerow(row)
        
        print(f"{Colors.GREEN}✓ CSV saved: {output_file}{Colors.ENDC}")
    
    def save_markdown(self, output_dir: Path, case_id: str):
        """Save results as Markdown report"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'brave_history_{case_id}_{timestamp}.md'
        output_file = output_dir / filename
        
        summary = self.generate_summary()
        
        with open(output_file, 'w') as f:
            # Header
            f.write(f"# Brave Browser History Analysis Report\n\n")
            f.write(f"**Case ID:** {case_id}  \n")
            f.write(f"**Analysis Timestamp:** {self.analysis_timestamp}  \n")
            f.write(f"**Profile:** {self.profile_path}  \n")
            f.write(f"**Tool:** brave_history_analyzer v1.0  \n")
            f.write(f"**Note:** Brave is Chromium-based (privacy-focused)  \n\n")
            
            f.write("---\n\n")
            
            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total URLs:** {summary['total_urls']:,}\n")
            f.write(f"- **Unique URLs:** {summary['unique_urls']:,}\n")
            f.write(f"- **Downloads:** {summary['downloads']:,}\n")
            f.write(f"- **Search Queries:** {summary['search_queries']:,}\n")
            f.write(f"- **Installed Extensions:** {summary['installed_extensions']:,}\n")
            f.write(f"- **Suspicious URLs:** {summary['suspicious_urls']:,}\n")
            f.write(f"- **Whitelisted (Filtered):** {summary['whitelisted_filtered']:,}\n\n")
            
            if summary['date_range']['earliest'] and summary['date_range']['latest']:
                f.write(f"**Date Range:** {summary['date_range']['earliest']} to {summary['date_range']['latest']}\n\n")
            
            # Findings
            if self.findings:
                f.write("---\n\n")
                f.write("## 🔍 Suspicious Findings\n\n")
                
                # Group by severity
                high_findings = [f for f in self.findings if f['severity'] == 'HIGH']
                medium_findings = [f for f in self.findings if f['severity'] == 'MEDIUM']
                low_findings = [f for f in self.findings if f['severity'] == 'LOW']
                
                if high_findings:
                    f.write(f"### HIGH Severity ({len(high_findings)})\n\n")
                    for finding in high_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n")
                        f.write(f"- **Visit Count:** {finding['visit_count']}  \n\n")
                
                if medium_findings:
                    f.write(f"### MEDIUM Severity ({len(medium_findings)})\n\n")
                    for finding in medium_findings:
                        f.write(f"**{finding['title'] or 'No Title'}**  \n")
                        f.write(f"- **URL:** {finding['url']}  \n")
                        f.write(f"- **Category:** {finding['category']}  \n")
                        f.write(f"- **Reason:** {finding['reason']}  \n")
                        f.write(f"- **Last Visit:** {finding['last_visit_time']}  \n\n")
                
                if low_findings:
                    f.write(f"### LOW Severity ({len(low_findings)})\n\n")
                    for finding in low_findings[:10]:
                        f.write(f"- {finding['url']} ({finding['category']})\n")
                    if len(low_findings) > 10:
                        f.write(f"\n*...and {len(low_findings) - 10} more*\n")
            
            # All URLs section (if not in suspicious-only mode)
            if not self.suspicious_only and self.urls:
                f.write("\n---\n\n")
                f.write(f"## 🌐 All URLs Visited ({len(self.urls)})\n\n")
                f.write("*Complete browsing history (most recent first)*\n\n")
                
                # Show first 50 URLs
                for url_data in self.urls[:50]:
                    f.write(f"**{url_data['title'] or 'No Title'}**  \n")
                    f.write(f"- **URL:** {url_data['url']}  \n")
                    f.write(f"- **Visits:** {url_data['visit_count']}  \n")
                    f.write(f"- **Last Visit:** {url_data['last_visit_time']}  \n\n")
                
                if len(self.urls) > 50:
                    f.write(f"*...and {len(self.urls) - 50} more URLs (see JSON/CSV for complete list)*\n\n")
            
            # Top Domains
            if summary['top_domains']:
                f.write("\n---\n\n")
                f.write("## 📊 Top Domains\n\n")
                for domain_info in summary['top_domains'][:10]:
                    f.write(f"- **{domain_info['domain']}** - {domain_info['visit_count']:,} visits\n")
            
            # Downloads
            if self.downloads:
                f.write("\n---\n\n")
                f.write(f"## 📥 Downloads ({len(self.downloads)})\n\n")
                for download in self.downloads[:20]:
                    f.write(f"**{Path(download['path']).name if download['path'] else 'Unknown'}**  \n")
                    f.write(f"- **URL:** {download['url']}  \n")
                    f.write(f"- **Path:** {download['path']}  \n")
                    f.write(f"- **Time:** {download['download_time']}  \n")
                    f.write(f"- **Size:** {download['bytes_total']:,} bytes  \n\n")
            
            # Search Queries
            if self.search_queries:
                f.write("\n---\n\n")
                f.write(f"## 🔍 Search Queries ({len(self.search_queries)})\n\n")
                for query in self.search_queries[:20]:
                    f.write(f"- **{query['term']}** ({query['timestamp']})\n")
            
            # Extensions
            if self.extensions:
                f.write("\n---\n\n")
                f.write(f"## 🧩 Installed Extensions ({len(self.extensions)})\n\n")
                for ext in self.extensions:
                    f.write(f"- **{ext['name']}** v{ext['version']}\n")
                    if ext['description']:
                        f.write(f"  - {ext['description']}\n")
            
            f.write("\n---\n\n")
            f.write("*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*\n")
        
        print(f"{Colors.GREEN}✓ Markdown saved: {output_file}{Colors.ENDC}")
    
    def run(self, output_dir: Path, verbose: bool = False):
        """Run complete analysis"""
        print(f"\n{Colors.CYAN}{'=' * 70}{Colors.ENDC}")
        print(f"{Colors.CYAN}{Colors.BOLD}{'Brave Browser History Analyzer'.center(70)}{Colors.ENDC}")
        print(f"{Colors.CYAN}{'=' * 70}{Colors.ENDC}\n")
        
        print(f"{Colors.BOLD}Case ID:{Colors.ENDC} {self.case_id}")
        print(f"{Colors.BOLD}Profile:{Colors.ENDC} {self.profile_path}")
        print(f"{Colors.BOLD}Analysis Time:{Colors.ENDC} {self.analysis_timestamp}")
        print(f"{Colors.BOLD}Browser:{Colors.ENDC} Brave (Chromium-based, privacy-focused)\n")
        
        # Extract data
        steps = [
            ("Extracting URL history", self.extract_history),
            ("Extracting downloads", self.extract_downloads),
            ("Extracting search queries", self.extract_search_queries),
            ("Extracting extensions", self.extract_extensions)
        ]
        
        for step_name, step_func in steps:
            if verbose:
                print(f"{Colors.CYAN}→ {step_name}...{Colors.ENDC}")
            try:
                step_func()
                if verbose:
                    print(f"{Colors.GREEN}  ✓ Complete{Colors.ENDC}")
            except Exception as e:
                print(f"{Colors.RED}  ✗ Error: {e}{Colors.ENDC}")
        
        # Save outputs
        print(f"\n{Colors.BOLD}Saving results...{Colors.ENDC}\n")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        self.save_json(output_dir, self.case_id)
        self.save_csv(output_dir, self.case_id)
        self.save_markdown(output_dir, self.case_id)
        
        # Print summary
        print(f"\n{Colors.BOLD}Analysis Summary:{Colors.ENDC}")
        print(f"  URLs: {self.stats['total_urls']:,}")
        print(f"  Downloads: {self.stats['downloads']:,}")
        print(f"  Search Queries: {self.stats['search_queries']:,}")
        print(f"  Extensions: {self.stats['installed_extensions']:,}")
        print(f"  Suspicious: {self.stats['suspicious_urls']:,}")
        print(f"  Whitelisted: {self.stats['whitelisted_filtered']:,}")
        
        print(f"\n{Colors.GREEN}✓ Analysis complete!{Colors.ENDC}\n")


def main():
    parser = argparse.ArgumentParser(
        description='Brave History Analyzer - Forensic browser history extraction',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze current user's Brave history
  %(prog)s
  
  # Use whitelist and specify case ID
  %(prog)s -w brave_whitelist.txt --case-id CASE-001
  
  # Output only suspicious URLs
  %(prog)s --suspicious-only -w brave_whitelist.txt --case-id CASE-001
  
  # Output to specific directory
  %(prog)s -o /evidence/brave_analysis/ --case-id CASE-001 -v

Part of: Apple FORENSICS • Backwater Forensics
        """
    )
    
    parser.add_argument('-p', '--profile', help='Brave profile path (default: ~/Library/Application Support/BraveSoftware/Brave-Browser/Default)')
    parser.add_argument('-o', '--output', default='.', help='Output directory (default: current)')
    parser.add_argument('--case-id', default='UNKNOWN', help='Case ID for tracking')
    parser.add_argument('-w', '--whitelist', action='append', help='Whitelist file (can specify multiple)')
    parser.add_argument('--suspicious-only', action='store_true', help='Output only suspicious URLs (excludes benign URLs from reports)')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    try:
        # Initialize analyzer
        analyzer = BraveHistoryAnalyzer(
            profile_path=args.profile,
            case_id=args.case_id,
            suspicious_only=args.suspicious_only
        )
        
        # Load whitelists
        if args.whitelist:
            for whitelist_file in args.whitelist:
                analyzer.load_whitelist(whitelist_file)
        
        # Run analysis
        output_dir = Path(args.output).expanduser()
        analyzer.run(output_dir, verbose=args.verbose)
        
        return 0
    
    except FileNotFoundError as e:
        print(f"{Colors.RED}Error: {e}{Colors.ENDC}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"{Colors.RED}Unexpected error: {e}{Colors.ENDC}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
