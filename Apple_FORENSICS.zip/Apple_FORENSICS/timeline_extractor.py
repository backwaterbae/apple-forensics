#!/usr/bin/env python3
"""
Timeline Context Extractor for Apple FORENSICS Log Analyzer
Extracts all activity within specified time windows around suspicious findings

Part of the Apple FORENSICS toolkit
"""

import sys
import json
import csv
import argparse
import re
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict
from typing import List, Dict, Any, Tuple

class TimelineExtractor:
    """Extract timeline context around suspicious findings"""
    
    def __init__(self, log_results: Path, window_minutes: int = 5):
        self.log_results = log_results
        self.window_minutes = window_minutes
        self.findings = []
        self.all_entries = []
        
    def load_results(self) -> bool:
        """Load log analysis results from JSON or CSV"""
        
        if not self.log_results.exists():
            print(f"❌ Results file not found: {self.log_results}")
            return False
            
        try:
            if self.log_results.suffix == '.json':
                return self._load_json()
            elif self.log_results.suffix == '.csv':
                return self._load_csv()
            else:
                print(f"❌ Unsupported format: {self.log_results.suffix}")
                return False
        except Exception as e:
            print(f"❌ Error loading results: {e}")
            return False
    
    def _load_json(self) -> bool:
        """Load from JSON format"""
        with open(self.log_results, 'r') as f:
            data = json.load(f)
            self.findings = data.get('findings', [])
            print(f"✅ Loaded {len(self.findings)} findings from JSON")
            return len(self.findings) > 0
    
    def _load_csv(self) -> bool:
        """Load from CSV format"""
        with open(self.log_results, 'r') as f:
            reader = csv.DictReader(f)
            self.findings = list(reader)
            print(f"✅ Loaded {len(self.findings)} findings from CSV")
            return len(self.findings) > 0
    
    def parse_timestamp(self, ts_str: str) -> datetime:
        """Parse ISO timestamp from findings"""
        # Handle both ISO format and Unix timestamps in zsh history
        try:
            return datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
        except:
            try:
                # Try Unix timestamp
                return datetime.fromtimestamp(float(ts_str))
            except:
                return None
    
    def extract_unix_timestamps_from_context(self, context: str) -> List[int]:
        """Extract Unix timestamps from zsh_history format"""
        # Pattern: : 1703001322:0;command
        timestamps = []
        pattern = r': (\d{10}):\d+;'
        matches = re.findall(pattern, context)
        for match in matches:
            timestamps.append(int(match))
        return timestamps
    
    def get_time_window(self, finding: Dict) -> Tuple[datetime, datetime]:
        """Calculate time window around a finding"""
        
        timestamp = self.parse_timestamp(finding.get('timestamp', ''))
        
        if not timestamp:
            # Try to extract from context (zsh history format)
            context = finding.get('context', '')
            unix_ts = self.extract_unix_timestamps_from_context(context)
            if unix_ts:
                timestamp = datetime.fromtimestamp(unix_ts[0])
        
        if not timestamp:
            return None, None
        
        window = timedelta(minutes=self.window_minutes)
        start_time = timestamp - window
        end_time = timestamp + window
        
        return start_time, end_time
    
    def find_correlated_activity(self, finding: Dict) -> List[Dict]:
        """Find all activity within time window of this finding"""
        
        start_time, end_time = self.get_time_window(finding)
        
        if not start_time:
            return []
        
        correlated = []
        
        for entry in self.findings:
            entry_time = self.parse_timestamp(entry.get('timestamp', ''))
            
            if not entry_time:
                # Try context extraction
                context = entry.get('context', '')
                unix_ts = self.extract_unix_timestamps_from_context(context)
                if unix_ts:
                    entry_time = datetime.fromtimestamp(unix_ts[0])
            
            if entry_time and start_time <= entry_time <= end_time:
                correlated.append(entry)
        
        # Sort by timestamp
        correlated.sort(key=lambda x: self.parse_timestamp(x.get('timestamp', '')) or datetime.min)
        
        return correlated
    
    def extract_timeline_for_finding(self, finding_index: int) -> Dict[str, Any]:
        """Extract complete timeline context for a specific finding"""
        
        if finding_index >= len(self.findings):
            return None
        
        target_finding = self.findings[finding_index]
        correlated = self.find_correlated_activity(target_finding)
        start_time, end_time = self.get_time_window(target_finding)
        
        return {
            'target_finding': target_finding,
            'time_window': {
                'start': start_time.isoformat() if start_time else None,
                'end': end_time.isoformat() if end_time else None,
                'window_minutes': self.window_minutes
            },
            'correlated_activity': correlated,
            'activity_count': len(correlated)
        }
    
    def extract_all_high_severity_timelines(self) -> List[Dict]:
        """Extract timelines for all HIGH severity findings"""
        
        timelines = []
        
        for idx, finding in enumerate(self.findings):
            print(f'  Processing finding {idx+1}/{len(self.findings)}...', end='\r', flush=True)
            severity = finding.get('severity', '').upper()
            if severity == 'HIGH':
                timeline = self.extract_timeline_for_finding(idx)
                if timeline:
                    timelines.append(timeline)
        
        return timelines
    
    def generate_report(self, timeline_data: Dict, output_format: str = 'markdown') -> str:
        """Generate timeline report"""
        
        if output_format == 'markdown':
            return self._generate_markdown_report(timeline_data)
        elif output_format == 'json':
            return json.dumps(timeline_data, indent=2)
        else:
            return str(timeline_data)
    
    def _generate_markdown_report(self, timeline_data: Dict) -> str:
        """Generate Markdown timeline report"""
        
        if isinstance(timeline_data, list):
            # Multiple timelines
            report = "# Timeline Context Analysis\n\n"
            report += f"**Analysis Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            report += f"**Timelines Extracted:** {len(timeline_data)}\n\n"
            report += "---\n\n"
            
            for idx, timeline in enumerate(timeline_data, 1):
                report += f"## Timeline {idx}\n\n"
                report += self._format_single_timeline(timeline)
                report += "\n---\n\n"
            
            return report
        else:
            # Single timeline
            report = "# Timeline Context Analysis\n\n"
            report += f"**Analysis Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            report += self._format_single_timeline(timeline_data)
            return report
    
    def _format_single_timeline(self, timeline: Dict) -> str:
        """Format a single timeline for markdown"""
        
        report = ""
        
        # Target finding
        target = timeline['target_finding']
        report += "### 🎯 Target Finding\n\n"
        report += f"- **Severity:** {target.get('severity', 'N/A')}\n"
        report += f"- **Category:** {target.get('category', 'N/A')}\n"
        report += f"- **Source:** `{target.get('log_file', 'N/A')}`\n"
        report += f"- **Pattern:** {target.get('pattern_matched', 'N/A')}\n"
        report += f"- **Context:** `{target.get('context', 'N/A')[:100]}...`\n\n"
        
        # Time window
        window = timeline['time_window']
        report += f"### ⏰ Time Window\n\n"
        report += f"- **Window:** ±{window['window_minutes']} minutes\n"
        if window['start']:
            start_dt = datetime.fromisoformat(window['start'])
            end_dt = datetime.fromisoformat(window['end'])
            report += f"- **Start:** {start_dt.strftime('%Y-%m-%d %H:%M:%S')} UTC\n"
            report += f"- **End:** {end_dt.strftime('%Y-%m-%d %H:%M:%S')} UTC\n"
        report += f"- **Events Found:** {timeline['activity_count']}\n\n"
        
        # Correlated activity
        if timeline['correlated_activity']:
            report += "### 📋 Correlated Activity (Chronological)\n\n"
            
            for idx, activity in enumerate(timeline['correlated_activity'], 1):
                timestamp = activity.get('timestamp', 'N/A')
                if timestamp != 'N/A':
                    try:
                        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        timestamp = dt.strftime('%H:%M:%S')
                    except:
                        pass
                
                report += f"**{idx}. [{timestamp}] {activity.get('severity', 'N/A')}** - {activity.get('category', 'N/A')}\n"
                report += f"   - **Source:** `{activity.get('log_file', 'N/A')}`\n"
                report += f"   - **Pattern:** {activity.get('pattern_matched', 'N/A')}\n"
                
                # Extract command from context if available
                context = activity.get('context', '')
                if 'command' in activity:
                    report += f"   - **Command:** `{activity['command']}`\n"
                elif ': ' in context and ';' in context:
                    # Extract from zsh history format
                    try:
                        cmd = context.split(';', 1)[1].strip()
                        report += f"   - **Command:** `{cmd}`\n"
                    except:
                        report += f"   - **Context:** `{context[:80]}...`\n"
                else:
                    report += f"   - **Context:** `{context[:80]}...`\n"
                
                report += "\n"
        
        return report
    
    def convert_to_est(self, timeline_data: Dict) -> Dict:
        """Convert all timestamps in timeline to EST"""
        
        from datetime import timezone
        est = timezone(timedelta(hours=-5))
        
        def convert_timestamp(ts_str):
            if not ts_str:
                return ts_str
            try:
                dt = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
                dt_est = dt.astimezone(est)
                return dt_est.isoformat()
            except:
                return ts_str
        
        # Convert time window
        if 'time_window' in timeline_data:
            timeline_data['time_window']['start'] = convert_timestamp(
                timeline_data['time_window'].get('start')
            )
            timeline_data['time_window']['end'] = convert_timestamp(
                timeline_data['time_window'].get('end')
            )
        
        # Convert target finding
        if 'target_finding' in timeline_data:
            timeline_data['target_finding']['timestamp'] = convert_timestamp(
                timeline_data['target_finding'].get('timestamp')
            )
        
        # Convert correlated activity
        if 'correlated_activity' in timeline_data:
            for activity in timeline_data['correlated_activity']:
                activity['timestamp'] = convert_timestamp(
                    activity.get('timestamp')
                )
        
        return timeline_data


def main():
    parser = argparse.ArgumentParser(
        description='Extract timeline context from log analysis results',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract timeline for finding #5 (±5 min window)
  %(prog)s -r log_analysis.json -f 5
  
  # Extract with 10 minute window
  %(prog)s -r log_analysis.json -f 5 -w 10
  
  # Extract all HIGH severity timelines
  %(prog)s -r log_analysis.json --all-high
  
  # Output as JSON
  %(prog)s -r log_analysis.json -f 5 --format json
  
  # Convert to EST timezone
  %(prog)s -r log_analysis.json -f 5 --timezone EST
        """
    )
    
    parser.add_argument('-r', '--results', required=True, type=Path,
                       help='Log analysis results file (JSON or CSV)')
    parser.add_argument('-f', '--finding', type=int,
                       help='Finding index to extract timeline for (0-based)')
    parser.add_argument('-w', '--window', type=int, default=5,
                       help='Time window in minutes (default: 5)')
    parser.add_argument('--all-high', action='store_true',
                       help='Extract timelines for all HIGH severity findings')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown',
                       help='Output format (default: markdown)')
    parser.add_argument('--timezone', choices=['UTC', 'EST'], default='UTC',
                       help='Timezone for timestamps (default: UTC)')
    parser.add_argument('-o', '--output', type=Path,
                       help='Output file (default: timeline_TIMESTAMP.md)')
    
    args = parser.parse_args()
    
    # Initialize extractor
    extractor = TimelineExtractor(args.results, args.window)
    
    if not extractor.load_results():
        return 1
    
    # Extract timeline(s)
    timeline_data = None
    
    if args.all_high:
        print(f"\n🔍 Extracting timelines for all HIGH severity findings...")
        timeline_data = extractor.extract_all_high_severity_timelines()
        print(f"✅ Extracted {len(timeline_data)} timelines")
    elif args.finding is not None:
        print(f"\n🔍 Extracting timeline for finding #{args.finding}...")
        timeline_data = extractor.extract_timeline_for_finding(args.finding)
        if timeline_data:
            print(f"✅ Found {timeline_data['activity_count']} correlated events")
        else:
            print("❌ Finding not found")
            return 1
    else:
        print("❌ Must specify --finding or --all-high")
        return 1
    
    # Convert timezone if requested
    if args.timezone == 'EST':
        print("🌐 Converting timestamps to EST...")
        if isinstance(timeline_data, list):
            timeline_data = [extractor.convert_to_est(t) for t in timeline_data]
        else:
            timeline_data = extractor.convert_to_est(timeline_data)
    
    # Generate report
    report = extractor.generate_report(timeline_data, args.format)
    
    # Determine output file
    if args.output:
        output_file = args.output
    else:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        ext = 'md' if args.format == 'markdown' else 'json'
        output_file = Path(f'timeline_context_{timestamp}.{ext}')
    
    # Write output
    with open(output_file, 'w') as f:
        f.write(report)
    
    print(f"\n✅ Timeline report saved to: {output_file}")
    
    return 0


if __name__ == '__main__':
    try:
        exit(main())
    except Exception as e:
        print(f"❌ FATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        exit(1)
