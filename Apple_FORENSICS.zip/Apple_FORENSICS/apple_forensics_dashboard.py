#!/usr/bin/env python3
"""
Apple FORENSICS Log Analyzer Dashboard
========================================
Interactive command-line interface for macOS forensic log analysis.
Orchestrates investigation creation, log analysis, and evidence reporting.

Part of: Backwater Forensics • Victim Investigator Approach
Author: Apple FORENSICS Project
Version: 1.0
"""

import sys
import os
import json
import subprocess
import re
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime
import hashlib


# Terminal colors - Apple FORENSICS branding
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'           # Forensic Blue
    CYAN = '\033[96m'           # Cyber Cyan
    GREEN = '\033[92m'          # Investigation Green
    YELLOW = '\033[93m'         # Warning Yellow
    ORANGE = '\033[38;5;208m'
    RED = '\033[91m'            # Alert Red
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'


def print_header(text: str):
    """Print formatted header"""
    print(f"\n{Colors.CYAN}{'=' * 70}{Colors.ENDC}")
    print(f"{Colors.CYAN}{Colors.BOLD}{text.center(70)}{Colors.ENDC}")
    print(f"{Colors.CYAN}{'=' * 70}{Colors.ENDC}\n")


def print_section(text: str):
    """Print formatted section"""
    print(f"\n{Colors.BLUE}{text}{Colors.ENDC}")
    print(f"{Colors.BLUE}{'-' * len(text)}{Colors.ENDC}")


def print_success(text: str):
    """Print success message"""
    print(f"{Colors.GREEN}✅ {text}{Colors.ENDC}")


def print_error(text: str):
    """Print error message"""
    print(f"{Colors.RED}❌ {text}{Colors.ENDC}")


def print_info(text: str):
    """Print info message"""
    print(f"{Colors.BLUE}ℹ️  {text}{Colors.ENDC}")


def print_warning(text: str):
    """Print warning message"""
    print(f"{Colors.ORANGE}⚠️  {text}{Colors.ENDC}")


class Investigation:
    """Represents a log analysis investigation"""
    
    def __init__(self, case_id: str, investigator: str, description: str):
        self.case_id = case_id
        self.investigator = investigator
        self.description = description
        self.created_at = datetime.utcnow().isoformat() + 'Z'
        
        # New forensic metadata
        self.victim_target: str = ""  # Who was targeted/affected
        self.incident_date: str = ""  # When incident occurred
        self.event_type: str = "present"  # "past" or "present"
        self.case_type: str = "single"  # "single" or "ongoing"
        self.suspect: str = ""  # Optional suspect information
        self.case_reference: str = ""  # Auto-assigned (C001, C002, etc.)
        
        # Existing fields
        self.log_directories: List[str] = []
        self.pattern_files: List[str] = []
        self.whitelist_files: List[str] = []  # NEW: Whitelist files
        self.analysis_runs: List[Dict] = []
        self.notes: List[str] = []
    
    def add_log_directory(self, directory: str):
        """Add a log directory to scan"""
        if directory not in self.log_directories:
            self.log_directories.append(directory)
    
    def add_pattern_file(self, pattern_file: str):
        """Add a pattern file"""
        if pattern_file not in self.pattern_files:
            self.pattern_files.append(pattern_file)
    
    def add_whitelist_file(self, whitelist_file: str):
        """Add a whitelist file"""
        if whitelist_file not in self.whitelist_files:
            self.whitelist_files.append(whitelist_file)
    
    def add_analysis_run(self, run_info: Dict):
        """Record an analysis run"""
        self.analysis_runs.append(run_info)
    
    def add_note(self, note: str):
        """Add investigator note"""
        timestamp = datetime.utcnow().isoformat() + 'Z'
        self.notes.append({
            'timestamp': timestamp,
            'note': note
        })
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'case_id': self.case_id,
            'investigator': self.investigator,
            'description': self.description,
            'created_at': self.created_at,
            'victim_target': self.victim_target,
            'incident_date': self.incident_date,
            'event_type': self.event_type,
            'case_type': self.case_type,
            'suspect': self.suspect,
            'case_reference': self.case_reference,
            'log_directories': self.log_directories,
            'pattern_files': self.pattern_files,
            'whitelist_files': self.whitelist_files,
            'analysis_runs': self.analysis_runs,
            'notes': self.notes
        }
    
    def save(self, output_dir: Path):
        """Save investigation metadata and create folder structure"""
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Create comprehensive folder structure
        self.create_folder_structure(output_dir)
        
        # Save investigation JSON
        inv_file = output_dir / f"{self.case_id}_investigation.json"
        with open(inv_file, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    def create_folder_structure(self, base_dir: Path):
        """Create comprehensive investigation folder structure"""
        folders = [
            'logs',                          # Source logs (if copied)
            'analysis',                      # Log analysis results
            'artifacts/home_directory',      # Home directory analysis
            'artifacts/shell_history',       # Shell command history
            'artifacts/ssh_keys',            # SSH configuration and keys
            'artifacts/browser_forensics',   # Browser artifacts
            'artifacts/application_data',    # Application-specific artifacts
            'context/network',               # Network context extractions
            'context/process',               # Process context extractions
            'context/logs',                  # Log context extractions
            'runtime_monitoring/process_snapshots',
            'runtime_monitoring/network_captures',
            'runtime_monitoring/combined_captures',
            'reports/context_reports',       # Context analysis reports
            'reports/final_reports',         # Final investigation reports
            'evidence',                      # Preserved evidence files
            'notes'                          # Investigation notes/documentation
        ]
        
        for folder in folders:
            folder_path = base_dir / folder
            folder_path.mkdir(parents=True, exist_ok=True)
        
        # Create README in base directory
        readme_path = base_dir / 'README.md'
        if not readme_path.exists():
            readme_content = f"""# Investigation: {self.case_id}

**Investigator:** {self.investigator}  
**Description:** {self.description}  
**Created:** {self.created_at}  
**Case Reference:** {self.case_reference}

## Forensic Metadata
- **Victim/Target:** {self.victim_target}
- **Incident Date:** {self.incident_date}
- **Event Type:** {self.event_type}
- **Case Type:** {self.case_type}
- **Suspect:** {self.suspect or 'Not specified'}

## Folder Structure
- `logs/` - Source log files (if copied to investigation)
- `analysis/` - Log analysis results (CSV, JSON, Markdown)
- `artifacts/` - Collected system artifacts
  - `home_directory/` - Home directory forensic analysis
  - `shell_history/` - Shell command history analysis
  - `ssh_keys/` - SSH configuration and key analysis
  - `browser_forensics/` - Browser history and artifacts
  - `application_data/` - Application-specific artifacts
- `context/` - Context extraction results
  - `network/` - Network context analysis
  - `process/` - Process context analysis
  - `logs/` - Log context analysis
- `runtime_monitoring/` - Live system captures
  - `process_snapshots/` - Process memory snapshots
  - `network_captures/` - Network traffic captures (PCAP)
  - `combined_captures/` - Combined process + network
- `reports/` - Generated reports
  - `context_reports/` - Aggregated context analysis
  - `final_reports/` - Final investigation reports
- `evidence/` - Preserved evidence files
- `notes/` - Investigation documentation and notes

## Quick Access
- Investigation metadata: `{self.case_id}_investigation.json`
- Latest analysis: `analysis/[latest]/`
- Context reports: `reports/context_reports/`

---
*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*
"""
            readme_path.write_text(readme_content)
    
    @classmethod
    def load(cls, filepath: Path):
        """Load investigation from file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        inv = cls(
            data['case_id'],
            data['investigator'],
            data['description']
        )
        inv.created_at = data['created_at']
        
        # Load new forensic metadata
        inv.victim_target = data.get('victim_target', '')
        inv.incident_date = data.get('incident_date', '')
        inv.event_type = data.get('event_type', 'present')
        inv.case_type = data.get('case_type', 'single')
        inv.suspect = data.get('suspect', '')
        inv.case_reference = data.get('case_reference', '')
        
        # Load existing fields
        inv.log_directories = data.get('log_directories', [])
        inv.pattern_files = data.get('pattern_files', [])
        inv.whitelist_files = data.get('whitelist_files', [])
        inv.analysis_runs = data.get('analysis_runs', [])
        inv.notes = data.get('notes', [])
        
        return inv


class Dashboard:
    """Main dashboard for Apple FORENSICS Log Analyzer"""
    
    def __init__(self):
        self.current_investigation: Optional[Investigation] = None
        # Investigations stored inside Apple_FORENSICS folder
        self.investigations_dir = Path("Investigations")
        self.investigations_dir.mkdir(parents=True, exist_ok=True)
        
        # Default pattern files
        self.default_patterns = {
            'security': 'macos_security_patterns.txt',
            'crash': 'crash_patterns.txt',
            'malware': 'malware_patterns.txt'
        }
        
        # Whitelist file for filtering false positives
        self.whitelist_file = 'macos_whitelist.txt'
        
        # Default log directories
        self.common_log_dirs = [
            str(Path.home() / "Library/Logs"),
            "/Library/Logs",
            str(Path.home() / "Library/Logs/DiagnosticReports"),
            "/var/log"
        ]
    
    def generate_case_reference(self) -> str:
        """Generate unique case reference (C001, C002, etc.)"""
        # Find all existing investigations
        investigations = list(self.investigations_dir.glob("*/*_investigation.json"))
        
        # Extract existing case references
        existing_refs = []
        for inv_file in investigations:
            try:
                with open(inv_file, 'r') as f:
                    data = json.load(f)
                    ref = data.get('case_reference', '')
                    if ref and ref.startswith('C'):
                        existing_refs.append(ref)
            except:
                pass
        
        # Find the next available number
        if not existing_refs:
            return "C001"
        
        # Extract numbers from refs like "C001", "C002"
        numbers = []
        for ref in existing_refs:
            try:
                num = int(ref[1:])  # Skip the 'C'
                numbers.append(num)
            except:
                pass
        
        if not numbers:
            return "C001"
        
        next_num = max(numbers) + 1
        return f"C{next_num:03d}"  # Format as C001, C002, etc.
    
    def show_banner(self):
        """Display Apple FORENSICS banner"""
        banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║               █████╗ ██████╗ ██████╗ ██╗     ███████╗             ║
║              ██╔══██╗██╔══██╗██╔══██╗██║     ██╔════╝             ║
║              ███████║██████╔╝██████╔╝██║     █████╗               ║
║              ██╔══██║██╔═══╝ ██╔═══╝ ██║     ██╔══╝               ║
║              ██║  ██║██║     ██║     ███████╗███████╗             ║
║              ╚═╝  ╚═╝╚═╝     ╚═╝     ╚══════╝╚══════╝             ║
║                                                                   ║
║                      FORENSICS                                    ║
║                                                                   ║
║              Professional macOS Forensic Analysis                 ║
║                   Victim Investigator Approach                    ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
{Colors.BLUE}Version 1.0 • December 2025 • Backwater Forensics{Colors.ENDC}
"""
        print(banner)
    
    def main_menu(self):
        """Display and handle main menu"""
        while True:
            print_header("APPLE FORENSICS MAIN MENU")
            
            print(f"{Colors.BOLD}INVESTIGATION{Colors.ENDC}")
            print("  1. Create New Investigation")
            print("  2. Load Existing Investigation")
            print("  3. List All Investigations")
            
            if self.current_investigation:
                print(f"\n{Colors.BOLD}CURRENT INVESTIGATION{Colors.ENDC}")
                print(f"  {Colors.GREEN}• {self.current_investigation.case_id}{Colors.ENDC}")
                print(f"  {Colors.DIM}  {self.current_investigation.description}{Colors.ENDC}")
                print("\n  4. View Investigation Details")
                print("  5. Edit Investigation Details")
                print(" 10. Add Investigator Note")
                print(" 11. Close Investigation")
            
            print(f"\n{Colors.BOLD}TOOLS{Colors.ENDC}")
            if self.current_investigation:
                print(f" {Colors.GREEN}13. Configure Log Directories{Colors.ENDC}")
                print(f" {Colors.GREEN}14. Configure Pattern Files{Colors.ENDC}")
                print(f" {Colors.GREEN}15. Configure Whitelist Files{Colors.ENDC}")
                print(f" {Colors.GREEN}16. Analysis Cleanup Tool{Colors.ENDC}  {Colors.DIM}← Filter false positives{Colors.ENDC}")
            else:
                print(f" {Colors.DIM}13. Configure Log Directories{Colors.ENDC}")
                print(f" {Colors.DIM}14. Configure Pattern Files{Colors.ENDC}")
                print(f" {Colors.DIM}15. Configure Whitelist Files{Colors.ENDC}")
                print(f" {Colors.DIM}16. Analysis Cleanup Tool{Colors.ENDC}")
            print(" 17. Create Custom Pattern File")
            print(" 18. List Available Patterns")
            print(" 19. Quick Scan (No Investigation)")
            
            if self.current_investigation:
                print(f"\n{Colors.BOLD}LOG ANALYSIS{Colors.ENDC}")
                print(f" {Colors.GREEN}8. Run Log Analysis{Colors.ENDC}")
                print(f" {Colors.GREEN}9. View Analysis Results{Colors.ENDC}")
            
            print(f"\n{Colors.BOLD}RUNTIME MONITORING{Colors.ENDC}")
            print(" 20. Process Memory Snapshot (Single PID)")
            print(" 21. System Process Triage (All Processes)")
            print(" 22. Network Capture")
            print(" 23. Combined Process + Network (Single PID)")
            print(" 24. System + Network Capture (Complete State)")
            
            print(f"\n{Colors.BOLD}ARTIFACT COLLECTION{Colors.ENDC}")
            print(" 25. Home Directory Analysis")
            
            print(f"\n{Colors.BOLD}BROWSER FORENSICS{Colors.ENDC}")
            if self.current_investigation:
                print(f" {Colors.GREEN}38. Chrome History Analysis{Colors.ENDC}")
                print(f" {Colors.GREEN}39. Safari History Analysis{Colors.ENDC}")
                print(f" {Colors.GREEN}40. Firefox History Analysis{Colors.ENDC}")
                print(f" {Colors.GREEN}41. Brave History Analysis{Colors.ENDC}")
            else:
                print(f" {Colors.DIM}38. Chrome History Analysis{Colors.ENDC}")
                print(f" {Colors.DIM}39. Safari History Analysis{Colors.ENDC}")
                print(f" {Colors.DIM}40. Firefox History Analysis{Colors.ENDC}")
                print(f" {Colors.DIM}41. Brave History Analysis{Colors.ENDC}")
            
            print(f"\n{Colors.BOLD}SEARCH & REPORTING{Colors.ENDC}")
            if self.current_investigation:
                print(f" {Colors.GREEN}42. Search Analysis by Date Range{Colors.ENDC}")
                print(f" {Colors.GREEN}43. Generate Investigation Status Report{Colors.ENDC}")
            else:
                print(f" {Colors.DIM}42. Search Analysis by Date Range{Colors.ENDC}")
                print(f" {Colors.DIM}43. Generate Investigation Status Report{Colors.ENDC}")
            
            print(f"\n{Colors.BOLD}SYSTEM{Colors.ENDC}")
            print("  0. Exit")
            
            choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
            
            if choice == "1":
                self.create_investigation()
            elif choice == "2":
                self.load_investigation()
            elif choice == "3":
                self.list_investigations()
            elif choice == "4" and self.current_investigation:
                self.view_investigation_details()
            elif choice == "5" and self.current_investigation:
                self.edit_investigation()
            elif choice == "6" and self.current_investigation:
                # Legacy route - redirects to 13
                self.configure_log_directories()
            elif choice == "7" and self.current_investigation:
                # Legacy route - redirects to 14
                self.configure_pattern_files()
            elif choice == "7b" and self.current_investigation:
                # Legacy route - redirects to 15
                self.configure_whitelist_files()
            elif choice == "8" and self.current_investigation:
                self.run_analysis()
            elif choice == "9" and self.current_investigation:
                self.view_results()
            elif choice == "10" and self.current_investigation:
                self.add_note()
            elif choice == "11" and self.current_investigation:
                self.close_investigation()
            elif choice == "12" and self.current_investigation:
                # Legacy route - redirects to 43
                self.investigation_status_report()
            elif choice == "13" and self.current_investigation:
                # New: Configure Log Directories (was 6)
                self.configure_log_directories()
            elif choice == "14" and self.current_investigation:
                # New: Configure Pattern Files (was 7)
                self.configure_pattern_files()
            elif choice == "15" and self.current_investigation:
                # New: Configure Whitelist Files (was 7b)
                self.configure_whitelist_files()
            elif choice == "16" and self.current_investigation:
                # New: Analysis Cleanup Tool (was 26)
                self.analysis_cleanup_tool()
            elif choice == "17":
                self.create_pattern_file()
            elif choice == "18":
                self.list_patterns()
            elif choice == "19":
                self.quick_scan()
            elif choice == "20":
                self.process_memory_snapshot()
            elif choice == "21":
                self.system_process_triage()
            elif choice == "22":
                self.network_capture()
            elif choice == "23":
                self.combined_capture()
            elif choice == "24":
                self.system_network_capture()
            elif choice == "25":
                self.home_directory_analysis()
            elif choice == "26" and self.current_investigation:
                # Legacy route - redirects to 16
                self.analysis_cleanup_tool()
            elif choice == "38" and self.current_investigation:
                self.analysis_chrome_history()
            elif choice == "39" and self.current_investigation:
                self.analysis_safari_history()
            elif choice == "40" and self.current_investigation:
                self.analysis_firefox_history()
            elif choice == "41" and self.current_investigation:
                self.analysis_brave_history()
            elif choice == "42" and self.current_investigation:
                self.search_date_range()
            elif choice == "43" and self.current_investigation:
                # New: Generate Investigation Status Report (was 12)
                self.investigation_status_report()
            elif choice == "0":
                self.exit_dashboard()
                break
            else:
                print_error("Invalid option")
    
    def create_investigation(self):
        """Create a new investigation"""
        print_header("CREATE NEW INVESTIGATION")
        
        print_info("Creating forensic investigation case")
        print()
        
        # Get basic case information
        case_id = input(f"{Colors.CYAN}Case ID (e.g., 2025-001): {Colors.ENDC}").strip()
        if not case_id:
            print_error("Case ID required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        investigator = input(f"{Colors.CYAN}Investigator name: {Colors.ENDC}").strip()
        if not investigator:
            print_error("Investigator name required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        description = input(f"{Colors.CYAN}Case description: {Colors.ENDC}").strip()
        if not description:
            print_error("Description required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Create investigation
        self.current_investigation = Investigation(case_id, investigator, description)
        
        # Collect forensic metadata
        print()
        print_section("Forensic Metadata")
        
        victim_target = input(f"{Colors.CYAN}Victim/Target (who was affected): {Colors.ENDC}").strip()
        self.current_investigation.victim_target = victim_target
        
        incident_date = input(f"{Colors.CYAN}Incident date (YYYY-MM-DD or 'today'): {Colors.ENDC}").strip()
        if incident_date.lower() == 'today':
            incident_date = datetime.utcnow().strftime('%Y-%m-%d')
        self.current_investigation.incident_date = incident_date
        
        print(f"\n{Colors.BOLD}Event Type:{Colors.ENDC}")
        print("  1. Present (happening now / real-time)")
        print("  2. Past (historical / analyzing old logs)")
        event_choice = input(f"{Colors.CYAN}Select (1-2): {Colors.ENDC}").strip()
        self.current_investigation.event_type = "present" if event_choice == "1" else "past"
        
        print(f"\n{Colors.BOLD}Case Type:{Colors.ENDC}")
        print("  1. Single incident")
        print("  2. Ongoing case")
        case_choice = input(f"{Colors.CYAN}Select (1-2): {Colors.ENDC}").strip()
        self.current_investigation.case_type = "single" if case_choice == "1" else "ongoing"
        
        suspect = input(f"{Colors.CYAN}Suspect (optional, press Enter to skip): {Colors.ENDC}").strip()
        self.current_investigation.suspect = suspect
        
        # Auto-generate case reference
        case_ref = self.generate_case_reference()
        self.current_investigation.case_reference = case_ref
        
        # Save investigation
        inv_dir = self.investigations_dir / case_id
        self.current_investigation.save(inv_dir)
        
        print()
        print_success(f"Investigation {case_id} created")
        print_info(f"Case Reference: {Colors.BOLD}{case_ref}{Colors.ENDC}")
        print_info(f"Event Type: {self.current_investigation.event_type.upper()}")
        print_info(f"Saved to: {inv_dir}")
        
        # Add default pattern files if they exist
        print_section("Checking for pattern files")
        for name, filename in self.default_patterns.items():
            if Path(filename).exists():
                self.current_investigation.add_pattern_file(filename)
                print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {name}: {filename}")
        
        self.current_investigation.save(inv_dir)
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def load_investigation(self):
        """Load an existing investigation"""
        print_header("LOAD INVESTIGATION")
        
        # List available investigations
        investigations = list(self.investigations_dir.glob("*/*_investigation.json"))
        
        if not investigations:
            print_info("No investigations found")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        print("Available investigations:\n")
        for i, inv_file in enumerate(investigations, 1):
            with open(inv_file, 'r') as f:
                data = json.load(f)
            print(f"{Colors.CYAN}{i}. {data['case_id']}{Colors.ENDC}")
            print(f"   {data['description']}")
            print(f"   Created: {data['created_at']}")
            print()
        
        choice = input(f"{Colors.CYAN}Select investigation (1-{len(investigations)}): {Colors.ENDC}").strip()
        
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(investigations):
                self.current_investigation = Investigation.load(investigations[idx])
                print_success(f"Loaded {self.current_investigation.case_id}")
            else:
                print_error("Invalid selection")
        except ValueError:
            print_error("Invalid input")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def list_investigations(self):
        """List all investigations"""
        print_header("ALL INVESTIGATIONS")
        
        investigations = list(self.investigations_dir.glob("*/*_investigation.json"))
        
        if not investigations:
            print_info("No investigations found")
        else:
            print(f"Found {len(investigations)} investigation(s):\n")
            
            for inv_file in sorted(investigations):
                with open(inv_file, 'r') as f:
                    data = json.load(f)
                
                print(f"{Colors.CYAN}{Colors.BOLD}{data['case_id']}{Colors.ENDC}")
                print(f"  Investigator: {data['investigator']}")
                print(f"  Description: {data['description']}")
                print(f"  Created: {data['created_at']}")
                print(f"  Analysis runs: {len(data.get('analysis_runs', []))}")
                print(f"  Location: {inv_file.parent}")
                print()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def view_investigation_details(self):
        """View current investigation details"""
        print_header(f"INVESTIGATION: {self.current_investigation.case_id}")
        
        inv = self.current_investigation
        
        print(f"{Colors.BOLD}Case Information{Colors.ENDC}")
        print(f"  Case ID: {inv.case_id}")
        print(f"  Case Reference: {Colors.BOLD}{inv.case_reference}{Colors.ENDC}")
        print(f"  Investigator: {inv.investigator}")
        print(f"  Description: {inv.description}")
        print(f"  Created: {inv.created_at}")
        
        print(f"\n{Colors.BOLD}Forensic Metadata{Colors.ENDC}")
        print(f"  Victim/Target: {inv.victim_target or Colors.DIM + '(not specified)' + Colors.ENDC}")
        print(f"  Incident Date: {inv.incident_date or Colors.DIM + '(not specified)' + Colors.ENDC}")
        
        event_badge = f"{Colors.GREEN}PRESENT{Colors.ENDC}" if inv.event_type == "present" else f"{Colors.YELLOW}PAST{Colors.ENDC}"
        print(f"  Event Type: {event_badge} ({inv.event_type})")
        
        case_badge = f"{Colors.YELLOW}ONGOING{Colors.ENDC}" if inv.case_type == "ongoing" else f"{Colors.GREEN}SINGLE{Colors.ENDC}"
        print(f"  Case Type: {case_badge} ({inv.case_type})")
        
        print(f"  Suspect: {inv.suspect or Colors.DIM + '(none identified)' + Colors.ENDC}")
        
        print(f"\n{Colors.BOLD}Log Directories ({len(inv.log_directories)}){Colors.ENDC}")
        if inv.log_directories:
            for d in inv.log_directories:
                print(f"  • {d}")
        else:
            print(f"  {Colors.DIM}(none configured){Colors.ENDC}")
        
        print(f"\n{Colors.BOLD}Pattern Files ({len(inv.pattern_files)}){Colors.ENDC}")
        if inv.pattern_files:
            for p in inv.pattern_files:
                exists = "✓" if Path(p).exists() else "✗"
                print(f"  {exists} {p}")
        else:
            print(f"  {Colors.DIM}(none configured){Colors.ENDC}")
        
        print(f"\n{Colors.BOLD}Whitelist Files ({len(inv.whitelist_files)}){Colors.ENDC}")
        if inv.whitelist_files:
            for w in inv.whitelist_files:
                exists = "✓" if Path(w).exists() else "✗"
                print(f"  {exists} {w}")
        else:
            print(f"  {Colors.DIM}(none configured){Colors.ENDC}")
        
        print(f"\n{Colors.BOLD}Analysis Runs ({len(inv.analysis_runs)}){Colors.ENDC}")
        if inv.analysis_runs:
            for i, run in enumerate(inv.analysis_runs, 1):
                print(f"  {i}. {run['timestamp']}")
                print(f"     Findings: {run.get('findings_count', 'N/A')}")
                print(f"     Output: {run.get('output_dir', 'N/A')}")
        else:
            print(f"  {Colors.DIM}(no analysis runs yet){Colors.ENDC}")
        
        print(f"\n{Colors.BOLD}Investigator Notes ({len(inv.notes)}){Colors.ENDC}")
        if inv.notes:
            for note in inv.notes[-5:]:  # Show last 5
                print(f"  • [{note['timestamp']}]")
                print(f"    {note['note']}")
        else:
            print(f"  {Colors.DIM}(no notes){Colors.ENDC}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def edit_investigation(self):
        """Edit investigation details and metadata"""
        print_header(f"EDIT INVESTIGATION: {self.current_investigation.case_id}")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        
        while True:
            print(f"\n{Colors.BOLD}What would you like to edit?{Colors.ENDC}\n")
            print("  1. Description")
            print("  2. Victim/Target")
            print("  3. Incident Date")
            print("  4. Event Type (Past/Present)")
            print("  5. Case Type (Single/Ongoing)")
            print("  6. Suspect")
            print("  0. Done editing")
            
            choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
            
            if choice == "0":
                break
            elif choice == "1":
                print(f"\n{Colors.BOLD}Current Description:{Colors.ENDC} {inv.description}")
                new_desc = input(f"{Colors.CYAN}New description (or Enter to keep): {Colors.ENDC}").strip()
                if new_desc:
                    inv.description = new_desc
                    print_success("Description updated")
            
            elif choice == "2":
                print(f"\n{Colors.BOLD}Current Victim/Target:{Colors.ENDC} {inv.victim_target or '(not specified)'}")
                new_victim = input(f"{Colors.CYAN}New victim/target (or Enter to keep): {Colors.ENDC}").strip()
                if new_victim or new_victim == "":  # Allow clearing
                    inv.victim_target = new_victim
                    print_success("Victim/Target updated")
            
            elif choice == "3":
                print(f"\n{Colors.BOLD}Current Incident Date:{Colors.ENDC} {inv.incident_date or '(not specified)'}")
                new_date = input(f"{Colors.CYAN}New incident date (YYYY-MM-DD or 'today'): {Colors.ENDC}").strip()
                if new_date:
                    if new_date.lower() == 'today':
                        new_date = datetime.utcnow().strftime('%Y-%m-%d')
                    inv.incident_date = new_date
                    print_success("Incident Date updated")
            
            elif choice == "4":
                print(f"\n{Colors.BOLD}Current Event Type:{Colors.ENDC} {inv.event_type}")
                print("\n  1. Present (happening now / real-time)")
                print("  2. Past (historical / analyzing old logs)")
                event_choice = input(f"{Colors.CYAN}Select (1-2): {Colors.ENDC}").strip()
                if event_choice == "1":
                    inv.event_type = "present"
                    print_success("Event Type updated to PRESENT")
                elif event_choice == "2":
                    inv.event_type = "past"
                    print_success("Event Type updated to PAST")
            
            elif choice == "5":
                print(f"\n{Colors.BOLD}Current Case Type:{Colors.ENDC} {inv.case_type}")
                print("\n  1. Single incident")
                print("  2. Ongoing case")
                case_choice = input(f"{Colors.CYAN}Select (1-2): {Colors.ENDC}").strip()
                if case_choice == "1":
                    inv.case_type = "single"
                    print_success("Case Type updated to SINGLE")
                elif case_choice == "2":
                    inv.case_type = "ongoing"
                    print_success("Case Type updated to ONGOING")
            
            elif choice == "6":
                print(f"\n{Colors.BOLD}Current Suspect:{Colors.ENDC} {inv.suspect or '(not specified)'}")
                new_suspect = input(f"{Colors.CYAN}New suspect info (or Enter to keep): {Colors.ENDC}").strip()
                if new_suspect or new_suspect == "":  # Allow clearing
                    inv.suspect = new_suspect
                    print_success("Suspect information updated")
            
            else:
                print_error("Invalid option")
        
        # Save changes
        inv.save(inv_dir)
        # Recreate README with updated info
        inv.create_folder_structure(inv_dir)
        
        print_success("Investigation details saved")
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def configure_log_directories(self):
        """Configure log directories to scan"""
        print_header("CONFIGURE LOG DIRECTORIES")
        
        print_info("Select directories to scan for logs")
        print()
        
        print(f"{Colors.BOLD}Common macOS Log Locations:{Colors.ENDC}\n")
        for i, d in enumerate(self.common_log_dirs, 1):
            exists = Path(d).exists()
            status = f"{Colors.GREEN}✓{Colors.ENDC}" if exists else f"{Colors.RED}✗{Colors.ENDC}"
            selected = f"{Colors.CYAN}[SELECTED]{Colors.ENDC}" if d in self.current_investigation.log_directories else ""
            print(f"  {i}. {status} {d} {selected}")
        
        # Show custom directories (those not in common_log_dirs)
        custom_dirs = [d for d in self.current_investigation.log_directories 
                       if d not in self.common_log_dirs]
        
        if custom_dirs:
            print(f"\n{Colors.BOLD}Custom Directories:{Colors.ENDC}\n")
            custom_start_idx = len(self.common_log_dirs) + 1
            for i, d in enumerate(custom_dirs):
                exists = Path(d).exists()
                status = f"{Colors.GREEN}✓{Colors.ENDC}" if exists else f"{Colors.RED}✗{Colors.ENDC}"
                print(f"  {custom_start_idx + i}. {status} {d} {Colors.CYAN}[CUSTOM]{Colors.ENDC}")
        
        # Calculate option numbers
        next_option = len(self.common_log_dirs) + len(custom_dirs) + 1
        print(f"\n  {next_option}. Add custom directory")
        print(f"  {next_option + 1}. Clear all")
        print(f"  0. Done")
        
        while True:
            choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
            
            if choice == "0":
                break
            
            try:
                idx = int(choice)
                
                # Handle common directories (toggle)
                if 1 <= idx <= len(self.common_log_dirs):
                    directory = self.common_log_dirs[idx - 1]
                    if directory in self.current_investigation.log_directories:
                        self.current_investigation.log_directories.remove(directory)
                        print(f"  {Colors.RED}✗{Colors.ENDC} Removed {directory}")
                    else:
                        self.current_investigation.add_log_directory(directory)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {directory}")
                
                # Handle custom directories (remove only)
                elif len(self.common_log_dirs) < idx <= len(self.common_log_dirs) + len(custom_dirs):
                    custom_idx = idx - len(self.common_log_dirs) - 1
                    directory = custom_dirs[custom_idx]
                    self.current_investigation.log_directories.remove(directory)
                    print(f"  {Colors.RED}✗{Colors.ENDC} Removed custom directory: {directory}")
                    # Rebuild custom_dirs list for next iteration
                    custom_dirs = [d for d in self.current_investigation.log_directories 
                                   if d not in self.common_log_dirs]
                
                # Add custom directory
                elif idx == next_option:
                    custom = input(f"  {Colors.CYAN}Enter directory path: {Colors.ENDC}").strip()
                    if custom:
                        # Expand ~ to home directory
                        custom = os.path.expanduser(custom)
                        self.current_investigation.add_log_directory(custom)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {custom}")
                        # Rebuild custom_dirs list
                        custom_dirs = [d for d in self.current_investigation.log_directories 
                                       if d not in self.common_log_dirs]
                        # Recalculate next_option
                        next_option = len(self.common_log_dirs) + len(custom_dirs) + 1
                
                # Clear all
                elif idx == next_option + 1:
                    self.current_investigation.log_directories = []
                    custom_dirs = []
                    next_option = len(self.common_log_dirs) + 1
                    print_info("Cleared all directories")
                
                else:
                    print_error("Invalid option")
            
            except ValueError:
                print_error("Invalid input")
        
        # Save
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        self.current_investigation.save(inv_dir)
        print_success("Configuration saved")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def configure_pattern_files(self):
        """Configure pattern files to use"""
        print_header("CONFIGURE PATTERN FILES")
        
        print_info("Select pattern files for analysis")
        print()
        
        # List available pattern files
        available_patterns = []
        
        # Check default patterns
        for name, filename in self.default_patterns.items():
            if Path(filename).exists():
                available_patterns.append((name, filename))
        
        # Check current directory for other .txt files
        for txt_file in Path('.').glob('*_patterns.txt'):
            if str(txt_file) not in [p[1] for p in available_patterns]:
                available_patterns.append(('custom', str(txt_file)))
        
        if not available_patterns:
            print_warning("No pattern files found in current directory")
            print_info("Pattern files should end with '_patterns.txt'")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        print(f"{Colors.BOLD}Available Pattern Files:{Colors.ENDC}\n")
        for i, (name, filename) in enumerate(available_patterns, 1):
            selected = f"{Colors.CYAN}[SELECTED]{Colors.ENDC}" if filename in self.current_investigation.pattern_files else ""
            print(f"  {i}. {name}: {filename} {selected}")
        
        print(f"\n  {len(available_patterns) + 1}. Add custom file")
        print(f"  {len(available_patterns) + 2}. Clear all")
        print(f"  0. Done")
        
        while True:
            choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
            
            if choice == "0":
                break
            
            try:
                idx = int(choice)
                
                if 1 <= idx <= len(available_patterns):
                    filename = available_patterns[idx - 1][1]
                    if filename in self.current_investigation.pattern_files:
                        self.current_investigation.pattern_files.remove(filename)
                        print(f"  {Colors.RED}✗{Colors.ENDC} Removed {filename}")
                    else:
                        self.current_investigation.add_pattern_file(filename)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {filename}")
                
                elif idx == len(available_patterns) + 1:
                    custom = input(f"  {Colors.CYAN}Enter pattern file path: {Colors.ENDC}").strip()
                    if custom and Path(custom).exists():
                        self.current_investigation.add_pattern_file(custom)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {custom}")
                    else:
                        print_error("File not found")
                
                elif idx == len(available_patterns) + 2:
                    self.current_investigation.pattern_files = []
                    print_info("Cleared all pattern files")
            
            except ValueError:
                print_error("Invalid input")
        
        # Save
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        self.current_investigation.save(inv_dir)
        print_success("Configuration saved")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def configure_whitelist_files(self):
        """Configure whitelist files to filter false positives"""
        print_header("CONFIGURE WHITELIST FILES")
        
        print_info("Select whitelist files to filter false positives")
        print()
        print(f"{Colors.DIM}Whitelists exclude known-good patterns from findings{Colors.ENDC}")
        print(f"{Colors.DIM}Example: macos_whitelist.txt filters legitimate Apple services{Colors.ENDC}")
        print()
        
        # List available whitelist files
        available_whitelists = []
        
        # Check for whitelist files
        for whitelist_file in Path('.').glob('*whitelist*.txt'):
            available_whitelists.append(str(whitelist_file))
        
        if not available_whitelists:
            print_warning("No whitelist files found in current directory")
            print_info("Whitelist files should contain 'whitelist' in the name (e.g., macos_whitelist.txt)")
            print()
            print("You can:")
            print("  1. Create one manually")
            print("  2. Add custom whitelist below")
            print()
        else:
            print(f"{Colors.BOLD}Available Whitelist Files:{Colors.ENDC}\n")
            for i, filename in enumerate(available_whitelists, 1):
                selected = f"{Colors.CYAN}[SELECTED]{Colors.ENDC}" if filename in self.current_investigation.whitelist_files else ""
                print(f"  {i}. {filename} {selected}")
        
        print(f"\n  {len(available_whitelists) + 1}. Add custom whitelist file")
        print(f"  {len(available_whitelists) + 2}. Clear all")
        print(f"  0. Done")
        
        while True:
            choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
            
            if choice == "0":
                break
            
            try:
                idx = int(choice)
                
                if 1 <= idx <= len(available_whitelists):
                    filename = available_whitelists[idx - 1]
                    if filename in self.current_investigation.whitelist_files:
                        self.current_investigation.whitelist_files.remove(filename)
                        print(f"  {Colors.RED}✗{Colors.ENDC} Removed {filename}")
                    else:
                        self.current_investigation.add_whitelist_file(filename)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {filename}")
                
                elif idx == len(available_whitelists) + 1:
                    custom = input(f"  {Colors.CYAN}Enter whitelist file path: {Colors.ENDC}").strip()
                    if custom and Path(custom).exists():
                        self.current_investigation.add_whitelist_file(custom)
                        print(f"  {Colors.GREEN}✓{Colors.ENDC} Added {custom}")
                    else:
                        print_error("File not found")
                
                elif idx == len(available_whitelists) + 2:
                    self.current_investigation.whitelist_files = []
                    print_info("Cleared all whitelist files")
            
            except ValueError:
                print_error("Invalid input")
        
        # Save
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        self.current_investigation.save(inv_dir)
        print_success("Configuration saved")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def run_analysis(self):
        """Run log analysis"""
        print_header("RUN LOG ANALYSIS")
        
        inv = self.current_investigation
        
        # Validate configuration
        if not inv.log_directories:
            print_error("No log directories configured")
            print_info("Configure directories first (option 5)")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        if not inv.pattern_files:
            print_error("No pattern files configured")
            print_info("Configure pattern files first (option 6)")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Show configuration
        print(f"{Colors.BOLD}Analysis Configuration:{Colors.ENDC}\n")
        print(f"  Case: {inv.case_id}")
        print(f"  Directories: {len(inv.log_directories)}")
        for d in inv.log_directories:
            print(f"    • {d}")
        print(f"  Pattern files: {len(inv.pattern_files)}")
        for p in inv.pattern_files:
            print(f"    • {p}")
        
        # Show whitelist status
        if inv.whitelist_files:
            print(f"  Whitelist files: {len(inv.whitelist_files)}")
            for w in inv.whitelist_files:
                exists = Path(w).exists()
                status = f"{Colors.GREEN}✓{Colors.ENDC}" if exists else f"{Colors.RED}✗{Colors.ENDC}"
                print(f"    {status} {w}")
            print(f"    {Colors.DIM}(Filtering false positives){Colors.ENDC}")
        else:
            print(f"  Whitelist: {Colors.DIM}None configured{Colors.ENDC}")
        
        # Confirm
        print()
        confirm = input(f"{Colors.CYAN}Proceed with analysis? (yes/no): {Colors.ENDC}").strip().lower()
        
        if confirm != 'yes':
            print_info("Analysis cancelled")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Create output directory
        inv_dir = self.investigations_dir / inv.case_id
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        output_dir = inv_dir / f"analysis_{timestamp}"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['./log_directory_analyzer.py']
        
        # Add directories
        for d in inv.log_directories:
            cmd.extend(['-d', d])
        
        # Add pattern files
        for p in inv.pattern_files:
            cmd.extend(['-p', p])
        
        # Add whitelist files if configured
        if inv.whitelist_files:
            for w in inv.whitelist_files:
                if Path(w).exists():
                    cmd.extend(['-w', w])
        
        # Add output directory
        cmd.extend(['-o', str(output_dir)])
        
        # Add verbose
        cmd.append('-v')
        
        print_section("Running Analysis")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
        
        try:
            # Run analysis
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print_success("Analysis completed successfully")
                
                # Parse results
                findings_count = 0
                for line in result.stdout.split('\n'):
                    if 'findings found' in line.lower():
                        try:
                            findings_count = int(line.split()[0])
                        except:
                            pass
                
                # Record analysis run
                run_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'directories': inv.log_directories,
                    'pattern_files': inv.pattern_files,
                    'output_dir': str(output_dir),
                    'findings_count': findings_count
                }
                inv.add_analysis_run(run_info)
                inv.save(inv_dir)
                
                print_info(f"Findings: {findings_count}")
                print_info(f"Results saved to: {output_dir}")
                
                # Show output files
                result_files = list(output_dir.glob('log_analysis_*'))
                if result_files:
                    print_section("Output Files")
                    for f in result_files:
                        print(f"  • {f.name}")
            
            else:
                print_error("Analysis failed")
                print(result.stderr)
        
        except FileNotFoundError:
            print_error("log_directory_analyzer.py not found")
            print_info("Make sure log_directory_analyzer.py is in the current directory")
            print_info("And it's executable: chmod +x log_directory_analyzer.py")
        except Exception as e:
            print_error(f"Error running analysis: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def view_results(self):
        """View analysis results"""
        print_header("VIEW ANALYSIS RESULTS")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        
        # List analysis runs
        if not inv.analysis_runs:
            print_info("No analysis runs yet")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        print(f"{Colors.BOLD}Analysis Runs:{Colors.ENDC}\n")
        for i, run in enumerate(inv.analysis_runs, 1):
            print(f"{Colors.CYAN}{i}. {run['timestamp']}{Colors.ENDC}")
            print(f"   Findings: {run.get('findings_count', 'N/A')}")
            print(f"   Output: {run.get('output_dir', 'N/A')}")
            print()
        
        choice = input(f"{Colors.CYAN}Select run to view (1-{len(inv.analysis_runs)}), or 0 to cancel: {Colors.ENDC}").strip()
        
        try:
            idx = int(choice)
            if idx == 0:
                return
            
            if 1 <= idx <= len(inv.analysis_runs):
                run = inv.analysis_runs[idx - 1]
                output_dir = Path(run['output_dir'])
                
                if not output_dir.exists():
                    print_error("Output directory not found")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                # Find markdown report
                md_files = list(output_dir.glob('log_analysis_*.md'))
                
                if md_files:
                    md_file = md_files[0]
                    print_section(f"Report: {md_file.name}")
                    
                    # Read and display report
                    with open(md_file, 'r') as f:
                        content = f.read()
                    
                    # Show first 50 lines
                    lines = content.split('\n')[:50]
                    for line in lines:
                        print(line)
                    
                    if len(content.split('\n')) > 50:
                        print(f"\n{Colors.DIM}[Report truncated - view full file at {md_file}]{Colors.ENDC}")
                    
                    print_info(f"\nFull report: {md_file}")
                    
                    # Offer to open
                    open_report = input(f"\n{Colors.CYAN}Open report in default app? (yes/no): {Colors.ENDC}").strip().lower()
                    if open_report == 'yes':
                        subprocess.run(['open', str(md_file)])
                else:
                    print_warning("No markdown report found")
                    print_info(f"Check directory: {output_dir}")
            else:
                print_error("Invalid selection")
        
        except ValueError:
            print_error("Invalid input")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def extract_timeline_quick(self):
        """Extract timeline context from analysis results (QUICK - for incident response)"""
        print_header("EXTRACT TIMELINE CONTEXT")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        
        # Check for analysis results
        if not inv.analysis_runs:
            print_error("No analysis runs found")
            print_info("Run log analysis first (option 7)")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # List analysis runs
        print(f"{Colors.BOLD}Available Analysis Runs:{Colors.ENDC}\n")
        for i, run in enumerate(inv.analysis_runs, 1):
            print(f"{Colors.CYAN}{i}. {run['timestamp']}{Colors.ENDC}")
            print(f"   Findings: {run.get('findings_count', 'N/A')}")
            print(f"   Output: {run.get('output_dir', 'N/A')}")
            print()
        
        choice = input(f"{Colors.CYAN}Select run to analyze (1-{len(inv.analysis_runs)}), or 0 to cancel: {Colors.ENDC}").strip()
        
        try:
            idx = int(choice)
            if idx == 0:
                return
            
            if 1 <= idx <= len(inv.analysis_runs):
                run = inv.analysis_runs[idx - 1]
                output_dir = Path(run['output_dir'])
                
                # Find JSON results file
                json_files = list(output_dir.glob('log_analysis_*.json'))
                
                if not json_files:
                    print_error("No JSON results found")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                results_file = json_files[0]
                
                # Get extraction options
                print_section("Timeline Extraction Options")
                print("1. Extract all HIGH severity timelines")
                print("2. Extract specific finding by index")
                
                extract_choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
                
                # Get time window
                window = input(f"{Colors.CYAN}Time window in minutes (default: 5): {Colors.ENDC}").strip()
                if not window:
                    window = "5"
                
                # Build command
                cmd = ['./timeline_extractor.py', '-r', str(results_file), '-w', window]
                
                if extract_choice == "1":
                    cmd.append('--all-high')
                elif extract_choice == "2":
                    finding_idx = input(f"{Colors.CYAN}Enter finding index (0-based): {Colors.ENDC}").strip()
                    if finding_idx:
                        cmd.extend(['-f', finding_idx])
                    else:
                        print_error("Finding index required")
                        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                        return
                else:
                    print_error("Invalid choice")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                # Add output to investigation directory
                timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
                output_file = output_dir / f'timeline_context_{timestamp}.md'
                cmd.extend(['-o', str(output_file)])
                
                print_section("Extracting Timeline")
                print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
                
                # Check if timeline_extractor.py exists
                if not Path('./timeline_extractor.py').exists():
                    print_error("timeline_extractor.py not found")
                    print_info("Make sure timeline_extractor.py is in the current directory")
                    print_info("And it's executable: chmod +x timeline_extractor.py")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                # Run extraction
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print_success("Timeline extraction completed")
                    print_info(f"Timeline report: {output_file}")
                    
                    # Offer to open
                    open_report = input(f"\n{Colors.CYAN}Open timeline report? (yes/no): {Colors.ENDC}").strip().lower()
                    if open_report == 'yes':
                        subprocess.run(['open', str(output_file)])
                else:
                    print_error("Timeline extraction failed")
                    print(result.stderr)
            else:
                print_error("Invalid selection")
        
        except ValueError:
            print_error("Invalid input")
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def extract_network_quick(self):
        """Extract network indicators from analysis results (QUICK - for incident response)"""
        print_header("EXTRACT NETWORK INDICATORS")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        
        # Check for analysis results
        if not inv.analysis_runs:
            print_error("No analysis runs found")
            print_info("Run log analysis first (option 7)")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # List analysis runs
        print(f"{Colors.BOLD}Available Analysis Runs:{Colors.ENDC}\n")
        for i, run in enumerate(inv.analysis_runs, 1):
            print(f"{Colors.CYAN}{i}. {run['timestamp']}{Colors.ENDC}")
            print(f"   Findings: {run.get('findings_count', 'N/A')}")
            print(f"   Output: {run.get('output_dir', 'N/A')}")
            print()
        
        choice = input(f"{Colors.CYAN}Select run to analyze (1-{len(inv.analysis_runs)}), or 0 to cancel: {Colors.ENDC}").strip()
        
        try:
            idx = int(choice)
            if idx == 0:
                return
            
            if 1 <= idx <= len(inv.analysis_runs):
                run = inv.analysis_runs[idx - 1]
                output_dir = Path(run['output_dir'])
                
                # Find JSON results file
                json_files = list(output_dir.glob('log_analysis_*.json'))
                
                if not json_files:
                    print_error("No JSON results found")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                results_file = json_files[0]
                
                # Get extraction options
                print_section("Network Indicator Extraction Options")
                print("1. Extract all indicators")
                print("2. Extract HIGH severity only")
                print("3. Extract specific category")
                
                extract_choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
                
                # Build command
                cmd = ['./network_indicator_extractor.py', '-r', str(results_file)]
                
                if extract_choice == "2":
                    cmd.extend(['--severity', 'HIGH'])
                elif extract_choice == "3":
                    category = input(f"{Colors.CYAN}Enter category (Security, Malware, etc.): {Colors.ENDC}").strip()
                    if category:
                        cmd.extend(['--category', category])
                    else:
                        print_error("Category required")
                        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                        return
                elif extract_choice != "1":
                    print_error("Invalid choice")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                # Add output to investigation directory
                timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
                output_file = output_dir / f'network_indicators_{timestamp}.md'
                cmd.extend(['-o', str(output_file)])
                
                print_section("Extracting Network Indicators")
                print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
                
                # Check if network_indicator_extractor.py exists
                if not Path('./network_indicator_extractor.py').exists():
                    print_error("network_indicator_extractor.py not found")
                    print_info("Make sure network_indicator_extractor.py is in the current directory")
                    print_info("And it's executable: chmod +x network_indicator_extractor.py")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
                
                # Run extraction
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print_success("Network indicator extraction completed")
                    print_info(f"Report: {output_file}")
                    
                    # Show summary from output
                    if result.stdout:
                        print_section("Summary")
                        for line in result.stdout.split('\n')[-10:]:  # Last 10 lines
                            if line.strip():
                                print(f"  {line}")
                    
                    # Offer to open
                    open_report = input(f"\n{Colors.CYAN}Open network indicators report? (yes/no): {Colors.ENDC}").strip().lower()
                    if open_report == 'yes':
                        subprocess.run(['open', str(output_file)])
                else:
                    print_error("Network indicator extraction failed")
                    print(result.stderr)
            else:
                print_error("Invalid selection")
        
        except ValueError:
            print_error("Invalid input")
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def extract_timeline_direct(self):
        """Extract timeline from log folders with date range (DIRECT - for past events)"""
        print_header("DIRECT TIMELINE EXTRACTION")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        output_dir = inv_dir / "context_analysis"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        print_info(f"Investigation Type: {inv.event_type.upper()}")
        print_info(f"Incident Date: {inv.incident_date or '(not specified)'}")
        print()
        
        # Get log source
        print(f"{Colors.BOLD}Log Source:{Colors.ENDC}")
        print("1. Use investigation's configured directories")
        print("2. Specify custom directory or file")
        
        source_choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
        
        if source_choice == "1":
            if not inv.log_directories:
                print_error("No log directories configured")
                print_info("Configure directories first (option 5)")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            source_path = inv.log_directories[0]  # Use first configured
        elif source_choice == "2":
            source_path = input(f"{Colors.CYAN}Enter log directory or file path: {Colors.ENDC}").strip()
            if not source_path or not Path(source_path).exists():
                print_error("Invalid path")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Get date range
        print()
        print(f"{Colors.BOLD}Date Range:{Colors.ENDC}")
        print("Examples: '2025-12-25', '2025-12-25 14:30', 'today', '2 hours ago'")
        
        start_date = input(f"{Colors.CYAN}Start date/time: {Colors.ENDC}").strip()
        if not start_date:
            print_error("Start date required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        end_date = input(f"{Colors.CYAN}End date/time (or 'now'): {Colors.ENDC}").strip()
        if not end_date:
            print_error("End date required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Build command
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        output_file = output_dir / f'timeline_direct_{timestamp}.md'
        
        cmd = [
            './timeline_extractor.py',
            '--source', source_path,
            '--start-date', start_date,
            '--end-date', end_date,
            '--output', str(output_file)
        ]
        
        print_section("Extracting Timeline")
        print(f"{Colors.DIM}Source: {source_path}{Colors.ENDC}")
        print(f"{Colors.DIM}Date Range: {start_date} to {end_date}{Colors.ENDC}")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
        
        # Check if tool exists
        if not Path('./timeline_extractor.py').exists():
            print_error("timeline_extractor.py not found")
            print_info("Make sure timeline_extractor.py is in the current directory")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Run extraction
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print_success("Timeline extraction completed")
            print_info(f"Timeline report: {output_file}")
            
            # Offer to open
            open_report = input(f"\n{Colors.CYAN}Open timeline report? (yes/no): {Colors.ENDC}").strip().lower()
            if open_report == 'yes':
                subprocess.run(['open', str(output_file)])
        else:
            print_error("Timeline extraction failed")
            if result.stderr:
                print(result.stderr)
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def extract_network_direct(self):
        """Extract network indicators from log folders with date range (DIRECT - for past events)"""
        print_header("DIRECT NETWORK IOC EXTRACTION")
        
        inv = self.current_investigation
        inv_dir = self.investigations_dir / inv.case_id
        output_dir = inv_dir / "context_analysis"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        print_info(f"Investigation Type: {inv.event_type.upper()}")
        print_info(f"Incident Date: {inv.incident_date or '(not specified)'}")
        print()
        
        # Get log source
        print(f"{Colors.BOLD}Log Source:{Colors.ENDC}")
        print("1. Use investigation's configured directories")
        print("2. Specify custom directory or file")
        
        source_choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
        
        if source_choice == "1":
            if not inv.log_directories:
                print_error("No log directories configured")
                print_info("Configure directories first (option 5)")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            source_path = inv.log_directories[0]  # Use first configured
        elif source_choice == "2":
            source_path = input(f"{Colors.CYAN}Enter log directory or file path: {Colors.ENDC}").strip()
            if not source_path or not Path(source_path).exists():
                print_error("Invalid path")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Get optional date range
        print()
        print(f"{Colors.BOLD}Date Range (optional - press Enter to skip):{Colors.ENDC}")
        print("Examples: '2025-12-25', '2025-12-25 14:30', 'today', '2 hours ago'")
        
        start_date = input(f"{Colors.CYAN}Start date/time (optional): {Colors.ENDC}").strip()
        end_date = input(f"{Colors.CYAN}End date/time (optional): {Colors.ENDC}").strip()
        
        # Build command
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        output_file = output_dir / f'network_iocs_direct_{timestamp}.md'
        
        cmd = [
            './network_indicator_extractor.py',
            '--source', source_path,
            '--output', str(output_file)
        ]
        
        if start_date:
            cmd.extend(['--start-date', start_date])
        if end_date:
            cmd.extend(['--end-date', end_date])
        
        print_section("Extracting Network Indicators")
        print(f"{Colors.DIM}Source: {source_path}{Colors.ENDC}")
        if start_date or end_date:
            date_range = f"{start_date or 'beginning'} to {end_date or 'end'}"
            print(f"{Colors.DIM}Date Range: {date_range}{Colors.ENDC}")
        else:
            print(f"{Colors.DIM}Date Range: All logs{Colors.ENDC}")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
        
        # Check if tool exists
        if not Path('./network_indicator_extractor.py').exists():
            print_error("network_indicator_extractor.py not found")
            print_info("Make sure network_indicator_extractor.py is in the current directory")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Run extraction
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print_success("Network IOC extraction completed")
            print_info(f"Report: {output_file}")
            
            # Show summary from output
            if result.stdout:
                print_section("Summary")
                for line in result.stdout.split('\n')[-10:]:  # Last 10 lines
                    if line.strip():
                        print(f"  {line}")
            
            # Offer to open
            open_report = input(f"\n{Colors.CYAN}Open network indicators report? (yes/no): {Colors.ENDC}").strip().lower()
            if open_report == 'yes':
                subprocess.run(['open', str(output_file)])
        else:
            print_error("Network IOC extraction failed")
            if result.stderr:
                print(result.stderr)
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def add_note(self):
        """Add investigator note"""
        print_header("ADD INVESTIGATOR NOTE")
        
        print_info(f"Case: {self.current_investigation.case_id}")
        print()
        
        note = input(f"{Colors.CYAN}Enter note (or 'cancel' to abort): {Colors.ENDC}").strip()
        
        if note.lower() == 'cancel':
            print_info("Cancelled")
        elif note:
            self.current_investigation.add_note(note)
            
            # Save
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            self.current_investigation.save(inv_dir)
            
            print_success("Note added")
        else:
            print_error("Note cannot be empty")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def close_investigation(self):
        """Close current investigation"""
        print_header("CLOSE INVESTIGATION")
        
        print(f"Closing: {self.current_investigation.case_id}")
        confirm = input(f"{Colors.CYAN}Confirm close? (yes/no): {Colors.ENDC}").strip().lower()
        
        if confirm == 'yes':
            # Save before closing
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            self.current_investigation.save(inv_dir)
            
            self.current_investigation = None
            print_success("Investigation closed")
        else:
            print_info("Close cancelled")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def investigation_status_report(self):
        """Generate investigation status report"""
        print_header("INVESTIGATION STATUS REPORT")
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        
        print_info(f"Analyzing investigation: {self.current_investigation.case_id}")
        print()
        
        # Choose format
        print(f"{Colors.BOLD}Select Report Format:{Colors.ENDC}")
        print("  1. All Formats (JSON + CSV + Markdown + PDF)")
        print("  2. JSON only")
        print("  3. CSV only")
        print("  4. Markdown only")
        print("  5. PDF only")
        print()
        
        format_choice = input(f"{Colors.CYAN}Choice (1-5): {Colors.ENDC}").strip()
        
        format_map = {
            '1': 'all',
            '2': 'json',
            '3': 'csv',
            '4': 'markdown',
            '5': 'pdf'
        }
        
        output_format = format_map.get(format_choice, 'all')
        
        print()
        print_info("Scanning investigation directory...")
        
        # Aggregate all analysis data
        status_data = self._aggregate_investigation_data(inv_dir)
        
        # Generate reports
        report_dir = inv_dir / 'reports'
        report_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        generated_files = []
        
        try:
            if output_format in ['json', 'all']:
                json_file = report_dir / f'status_report_{timestamp}.json'
                self._generate_status_json(status_data, json_file)
                generated_files.append(json_file)
                print_success(f"✓ JSON: {json_file.name}")
            
            if output_format in ['csv', 'all']:
                csv_file = report_dir / f'status_report_{timestamp}.csv'
                self._generate_status_csv(status_data, csv_file)
                generated_files.append(csv_file)
                print_success(f"✓ CSV: {csv_file.name}")
            
            if output_format in ['markdown', 'all']:
                md_file = report_dir / f'status_report_{timestamp}.md'
                self._generate_status_markdown(status_data, md_file)
                generated_files.append(md_file)
                print_success(f"✓ Markdown: {md_file.name}")
            
            if output_format in ['pdf', 'all']:
                pdf_file = report_dir / f'status_report_{timestamp}.pdf'
                self._generate_status_pdf(status_data, pdf_file)
                generated_files.append(pdf_file)
                print_success(f"✓ PDF: {pdf_file.name}")
            
            print()
            print_success(f"Status report generated: {len(generated_files)} file(s)")
            print_info(f"Location: {report_dir}")
            
            # Show summary
            print()
            print(f"{Colors.BOLD}Investigation Summary:{Colors.ENDC}")
            print(f"  Tools Run: {status_data['tools_run_count']}")
            print(f"  Total Findings: {status_data['total_findings']}")
            print(f"  HIGH Severity: {status_data['severity_summary'].get('HIGH', 0)}")
            print(f"  MEDIUM Severity: {status_data['severity_summary'].get('MEDIUM', 0)}")
            print(f"  LOW Severity: {status_data['severity_summary'].get('LOW', 0)}")
            
            if status_data['category_summary']:
                print()
                print(f"{Colors.BOLD}Top Categories:{Colors.ENDC}")
                sorted_cats = sorted(status_data['category_summary'].items(), 
                                   key=lambda x: x[1], reverse=True)[:5]
                for cat, count in sorted_cats:
                    print(f"  {cat}: {count}")
            
        except Exception as e:
            print_error(f"Error generating report: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def _aggregate_investigation_data(self, inv_dir):
        """Aggregate all analysis data from investigation directory - DYNAMIC SCANNING"""
        from collections import defaultdict
        import json
        
        status_data = {
            'case_id': self.current_investigation.case_id,
            'investigator': self.current_investigation.investigator,
            'description': self.current_investigation.description,
            'created_at': self.current_investigation.created_at,
            'victim_target': self.current_investigation.victim_target,
            'case_reference': self.current_investigation.case_reference,
            'pattern_files': self.current_investigation.pattern_files,
            'whitelist_files': self.current_investigation.whitelist_files,
            'timestamp_utc': datetime.utcnow().isoformat() + 'Z',
            'timezone': 'UTC',
            'tools_run': [],
            'tools_run_count': 0,
            'total_findings': 0,
            'severity_summary': defaultdict(int),
            'category_summary': defaultdict(int),
            'analysis_timestamps': [],
            'recommendations': []
        }
        
        # DYNAMIC APPROACH: Scan ALL subdirectories for JSON files
        print_info(f"Scanning all subdirectories for analysis files...")
        
        all_json_files = list(inv_dir.rglob('*.json'))
        json_count = 0
        
        for json_file in all_json_files:
            # Skip investigation metadata file
            if json_file.name.endswith('_investigation.json'):
                continue
            
            # Skip report files in reports/ directory
            if 'reports' in json_file.parts:
                continue
            
            try:
                with open(json_file) as f:
                    data = json.load(f)
                
                # Detect file type and aggregate accordingly
                if self._is_log_analysis_file(data):
                    self._aggregate_log_analysis(data, json_file, inv_dir, status_data)
                    json_count += 1
                elif self._is_home_analysis_file(data):
                    self._aggregate_home_analysis(data, json_file, inv_dir, status_data)
                    json_count += 1
                elif self._is_network_capture_file(data):
                    self._aggregate_network_capture(data, json_file, inv_dir, status_data)
                    json_count += 1
                elif self._is_runtime_monitoring_file(data):
                    self._aggregate_runtime_monitoring(data, json_file, inv_dir, status_data)
                    json_count += 1
                # Add more file type detections as needed
                
            except Exception as e:
                # Silently skip files we can't parse
                pass
        
        status_data['tools_run_count'] = len(status_data['tools_run'])
        
        if json_count == 0:
            status_data['recommendations'].append("No analysis files found. Run analysis tools to collect evidence.")
        
        print_info(f"Found and processed {json_count} analysis file(s)")
        
        return status_data
    
    def _is_log_analysis_file(self, data):
        """Check if JSON is from log_directory_analyzer"""
        return ('findings' in data and 
                'analysis_metadata' in data and
                'log_file' in str(data.get('analysis_metadata', {})))
    
    def _is_home_analysis_file(self, data):
        """Check if JSON is from home_directory_analyzer"""
        return ('findings' in data and 
                'analysis_metadata' in data and
                'home_directory' in str(data.get('analysis_metadata', {})))
    
    def _is_network_capture_file(self, data):
        """Check if JSON is from network capture tool"""
        return ('capture_metadata' in data or 
                'network_interface' in data or
                'pcap_file' in str(data))
    
    def _is_runtime_monitoring_file(self, data):
        """Check if JSON is from runtime monitoring tool"""
        return ('process_snapshots' in data or
                'system_state' in data or
                'memory_snapshot' in str(data))
    
    def _aggregate_log_analysis(self, data, json_file, inv_dir, status_data):
        """Aggregate findings from log_directory_analyzer"""
        metadata = data.get('analysis_metadata', {})
        timestamp = metadata.get('analysis_timestamp_utc') or metadata.get('analysis_timestamp', 'unknown')
        
        status_data['tools_run'].append({
            'tool': 'Log Directory Analyzer',
            'timestamp': timestamp,
            'findings_count': len(data.get('findings', [])),
            'file': str(json_file.relative_to(inv_dir)),
            'tool_version': metadata.get('tool_version', '1.0')
        })
        
        for finding in data.get('findings', []):
            status_data['total_findings'] += 1
            severity = finding.get('severity', 'UNKNOWN')
            status_data['severity_summary'][severity] += 1
            
            category = finding.get('category')
            if category:
                status_data['category_summary'][category] += 1
            
            # Track artifact timestamps for timeline
            artifact_ts = finding.get('artifact_timestamp')
            if artifact_ts:
                status_data['analysis_timestamps'].append({
                    'tool': 'Log Directory Analyzer',
                    'timestamp': artifact_ts,
                    'timestamp_source': finding.get('timestamp_source', 'unknown'),
                    'severity': severity,
                    'category': category
                })
    
    def _aggregate_home_analysis(self, data, json_file, inv_dir, status_data):
        """Aggregate findings from home_directory_analyzer"""
        findings = data.get('findings', [])
        metadata = data.get('analysis_metadata', {})
        timestamp = metadata.get('analysis_timestamp') or metadata.get('analysis_timestamp_utc', 'unknown')
        
        status_data['tools_run'].append({
            'tool': 'Home Directory Analyzer',
            'timestamp': timestamp,
            'findings_count': len(findings),
            'file': str(json_file.relative_to(inv_dir)),
            'tool_version': metadata.get('tool_version', '1.0')
        })
        
        for finding in findings:
            status_data['total_findings'] += 1
            severity = finding.get('severity', 'UNKNOWN')
            status_data['severity_summary'][severity] += 1
            
            category = finding.get('category')
            if category:
                status_data['category_summary'][category] += 1
            
            # Track artifact timestamps for timeline
            artifact_ts = finding.get('artifact_timestamp')
            if artifact_ts:
                status_data['analysis_timestamps'].append({
                    'tool': 'Home Directory Analyzer',
                    'timestamp': artifact_ts,
                    'timestamp_source': finding.get('timestamp_source', 'unknown'),
                    'severity': severity,
                    'category': category
                })
    
    def _aggregate_network_capture(self, data, json_file, inv_dir, status_data):
        """Aggregate data from network capture tools"""
        metadata = data.get('capture_metadata', {})
        timestamp = metadata.get('start_time', 'unknown')
        
        status_data['tools_run'].append({
            'tool': 'Network Capture',
            'timestamp': timestamp,
            'findings_count': 0,  # Network captures don't have "findings"
            'file': str(json_file.relative_to(inv_dir)),
            'tool_version': metadata.get('tool_version', '1.0')
        })
    
    def _aggregate_runtime_monitoring(self, data, json_file, inv_dir, status_data):
        """Aggregate data from runtime monitoring tools"""
        # Get timestamp from various possible fields
        timestamp = (data.get('capture_timestamp') or 
                    data.get('analysis_timestamp') or 
                    'unknown')
        
        status_data['tools_run'].append({
            'tool': 'Runtime Monitoring',
            'timestamp': timestamp,
            'findings_count': 0,  # Runtime monitoring doesn't have "findings"
            'file': str(json_file.relative_to(inv_dir)),
            'tool_version': data.get('tool_version', '1.0')
        })
        
        # Generate recommendations based on what's been run
        if status_data['tools_run_count'] == 0:
            status_data['recommendations'].append("No analysis tools have been run yet. Start with Log Analysis (Option 8).")
        else:
            if not any(t['tool'] == 'Log Directory Analyzer' for t in status_data['tools_run']):
                status_data['recommendations'].append("Run Log Analysis to check for security events, crashes, and malware indicators.")
            
            if not any(t['tool'] == 'Home Directory Analyzer' for t in status_data['tools_run']):
                status_data['recommendations'].append("Run Home Directory Analysis to check shell history and suspicious files.")
            
            if not any(t['tool'] == 'Network Capture' for t in status_data['tools_run']):
                status_data['recommendations'].append("Run Network Capture to monitor active network connections.")
            
            if status_data['severity_summary'].get('HIGH', 0) > 0:
                status_data['recommendations'].append(f"PRIORITY: Investigate {status_data['severity_summary']['HIGH']} HIGH severity findings immediately.")
        
        return status_data
    
    def _generate_status_json(self, status_data, filepath):
        """Generate JSON status report"""
        import json
        with open(filepath, 'w') as f:
            json.dump(status_data, f, indent=2, default=str)
    
    def _generate_status_csv(self, status_data, filepath):
        """Generate CSV status report"""
        import csv
        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow(['Investigation Status Report'])
            writer.writerow([])
            
            # Case info
            writer.writerow(['Case ID', status_data['case_id']])
            writer.writerow(['Case Reference', status_data.get('case_reference', 'N/A')])
            writer.writerow(['Investigator', status_data['investigator']])
            writer.writerow(['Description', status_data['description']])
            writer.writerow(['Victim/Target', status_data.get('victim_target', 'N/A')])
            writer.writerow(['Created', status_data.get('created_at', 'N/A')])
            writer.writerow(['Report Generated (UTC)', status_data['timestamp_utc']])
            writer.writerow([])
            
            # Configuration
            writer.writerow(['Investigation Configuration'])
            writer.writerow(['Pattern Files'])
            if status_data.get('pattern_files'):
                for pf in status_data['pattern_files']:
                    writer.writerow(['', pf])
            else:
                writer.writerow(['', 'None configured'])
            writer.writerow([])
            
            writer.writerow(['Whitelist Files'])
            if status_data.get('whitelist_files'):
                for wf in status_data['whitelist_files']:
                    writer.writerow(['', wf])
            else:
                writer.writerow(['', 'None configured'])
            writer.writerow([])
            
            # Summary
            writer.writerow(['Tools Run', status_data['tools_run_count']])
            writer.writerow(['Total Findings', status_data['total_findings']])
            writer.writerow([])
            
            # Severity
            writer.writerow(['Severity Summary'])
            writer.writerow(['Severity', 'Count'])
            for severity, count in sorted(status_data['severity_summary'].items()):
                writer.writerow([severity, count])
            writer.writerow([])
            
            # Tools
            writer.writerow(['Tools Executed'])
            writer.writerow(['Tool', 'Timestamp (UTC)', 'Findings', 'File'])
            for tool in status_data['tools_run']:
                writer.writerow([
                    tool['tool'],
                    tool['timestamp'],
                    tool['findings_count'],
                    tool['file']
                ])
    
    def _generate_status_markdown(self, status_data, filepath):
        """Generate Markdown status report"""
        with open(filepath, 'w') as f:
            f.write("# Investigation Status Report\n\n")
            
            # Case info
            f.write("## Case Information\n\n")
            f.write(f"- **Case ID:** {status_data['case_id']}\n")
            f.write(f"- **Case Reference:** {status_data.get('case_reference', 'N/A')}\n")
            f.write(f"- **Investigator:** {status_data['investigator']}\n")
            f.write(f"- **Description:** {status_data['description']}\n")
            f.write(f"- **Victim/Target:** {status_data.get('victim_target', 'N/A')}\n")
            f.write(f"- **Created:** {status_data.get('created_at', 'N/A')}\n")
            f.write(f"- **Report Generated (UTC):** {status_data['timestamp_utc']}\n\n")
            
            # Configuration
            f.write("## Investigation Configuration\n\n")
            
            # Pattern files
            if status_data.get('pattern_files'):
                f.write(f"### Pattern Files ({len(status_data['pattern_files'])})\n\n")
                for pf in status_data['pattern_files']:
                    f.write(f"- `{pf}`\n")
                f.write("\n")
            else:
                f.write("### Pattern Files\n\n")
                f.write("*No pattern files configured*\n\n")
            
            # Whitelist files
            if status_data.get('whitelist_files'):
                f.write(f"### Whitelist Files ({len(status_data['whitelist_files'])})\n\n")
                for wf in status_data['whitelist_files']:
                    f.write(f"- `{wf}`\n")
                f.write("\n")
            else:
                f.write("### Whitelist Files\n\n")
                f.write("*No whitelist files configured*\n\n")
            
            # Summary
            f.write("## Analysis Summary\n\n")
            f.write(f"- **Tools Run:** {status_data['tools_run_count']}\n")
            f.write(f"- **Total Findings:** {status_data['total_findings']}\n\n")
            
            # Severity
            f.write("### Severity Breakdown\n\n")
            if status_data['severity_summary']:
                for severity in ['HIGH', 'MEDIUM', 'LOW']:
                    count = status_data['severity_summary'].get(severity, 0)
                    if count > 0:
                        f.write(f"- **{severity}:** {count}\n")
            else:
                f.write("No findings with severity ratings.\n")
            f.write("\n")
            
            # Categories
            if status_data['category_summary']:
                f.write("### Top Categories\n\n")
                top_categories = sorted(status_data['category_summary'].items(), 
                                      key=lambda x: x[1], reverse=True)[:10]
                for category, count in top_categories:
                    f.write(f"- **{category}:** {count}\n")
                f.write("\n")
            
            # Tools executed
            f.write("## Tools Executed\n\n")
            if status_data['tools_run']:
                for tool in sorted(status_data['tools_run'], key=lambda x: x['timestamp'], reverse=True):
                    f.write(f"### {tool['tool']}\n\n")
                    f.write(f"- **Timestamp (UTC):** {tool['timestamp']}\n")
                    f.write(f"- **Findings:** {tool['findings_count']}\n")
                    
                    if 'details' in tool:
                        f.write(f"- **Details:**\n")
                        for key, value in tool['details'].items():
                            f.write(f"  - {key}: {value}\n")
                    
                    f.write(f"- **Data File:** `{tool['file']}`\n\n")
            else:
                f.write("No analysis tools have been run yet.\n\n")
            
            # Recommendations
            if status_data['recommendations']:
                f.write("## Recommendations\n\n")
                for i, rec in enumerate(status_data['recommendations'], 1):
                    f.write(f"{i}. {rec}\n")
                f.write("\n")
            
            f.write("---\n\n")
            f.write("*Generated by Apple FORENSICS Dashboard*\n")
    
    def _generate_status_pdf(self, status_data, filepath):
        """Generate PDF status report"""
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.lib import colors
            
            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []
            
            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1a5490'),
                spaceAfter=30,
            )
            story.append(Paragraph("Investigation Status Report", title_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Case Information
            story.append(Paragraph("Case Information", styles['Heading2']))
            case_data = [
                ['Case ID:', status_data['case_id']],
                ['Case Reference:', status_data.get('case_reference', 'N/A')],
                ['Investigator:', status_data['investigator']],
                ['Description:', status_data['description']],
                ['Victim/Target:', status_data.get('victim_target', 'N/A')],
                ['Created:', status_data.get('created_at', 'N/A')],
                ['Report Generated (UTC):', status_data['timestamp_utc']],
            ]
            
            case_table = Table(case_data, colWidths=[2*inch, 4*inch])
            case_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(case_table)
            story.append(Spacer(1, 0.3*inch))
            
            # Configuration
            story.append(Paragraph("Investigation Configuration", styles['Heading2']))
            
            # Pattern files
            if status_data.get('pattern_files'):
                story.append(Paragraph(f"Pattern Files ({len(status_data['pattern_files'])})", styles['Heading3']))
                pattern_list = []
                for pf in status_data['pattern_files']:
                    pattern_list.append(Paragraph(f"• {pf}", styles['Normal']))
                for p in pattern_list:
                    story.append(p)
                story.append(Spacer(1, 0.15*inch))
            else:
                story.append(Paragraph("Pattern Files: None configured", styles['Normal']))
                story.append(Spacer(1, 0.15*inch))
            
            # Whitelist files
            if status_data.get('whitelist_files'):
                story.append(Paragraph(f"Whitelist Files ({len(status_data['whitelist_files'])})", styles['Heading3']))
                whitelist_list = []
                for wf in status_data['whitelist_files']:
                    whitelist_list.append(Paragraph(f"• {wf}", styles['Normal']))
                for w in whitelist_list:
                    story.append(w)
                story.append(Spacer(1, 0.15*inch))
            else:
                story.append(Paragraph("Whitelist Files: None configured", styles['Normal']))
                story.append(Spacer(1, 0.15*inch))
            
            story.append(Spacer(1, 0.2*inch))
            
            # Analysis Summary
            story.append(Paragraph("Analysis Summary", styles['Heading2']))
            summary_data = [
                ['Tools Run:', str(status_data['tools_run_count'])],
                ['Total Findings:', str(status_data['total_findings'])],
            ]
            
            summary_table = Table(summary_data, colWidths=[2*inch, 4*inch])
            summary_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(summary_table)
            story.append(Spacer(1, 0.2*inch))
            
            # Severity Breakdown
            if status_data['severity_summary']:
                story.append(Paragraph("Severity Breakdown", styles['Heading3']))
                severity_data = [['Severity', 'Count']]
                for severity in ['HIGH', 'MEDIUM', 'LOW']:
                    count = status_data['severity_summary'].get(severity, 0)
                    if count > 0:
                        severity_data.append([severity, str(count)])
                
                severity_table = Table(severity_data, colWidths=[2*inch, 1*inch])
                severity_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ]))
                story.append(severity_table)
                story.append(Spacer(1, 0.3*inch))
            
            # Category Breakdown
            if status_data['category_summary']:
                story.append(Paragraph("Category Breakdown", styles['Heading3']))
                # Sort by count, show top 10
                sorted_categories = sorted(status_data['category_summary'].items(), 
                                         key=lambda x: x[1], reverse=True)[:10]
                category_data = [['Category', 'Count']]
                for category, count in sorted_categories:
                    category_data.append([str(category), str(count)])
                
                category_table = Table(category_data, colWidths=[3*inch, 1*inch])
                category_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ]))
                story.append(category_table)
                story.append(Spacer(1, 0.3*inch))
            
            # Tools Executed
            story.append(Paragraph("Tools Executed", styles['Heading2']))
            if status_data['tools_run']:
                for tool in sorted(status_data['tools_run'], key=lambda x: x['timestamp'], reverse=True):
                    story.append(Paragraph(f"<b>{tool['tool']}</b>", styles['Heading3']))
                    tool_data = [
                        ['Timestamp (UTC):', tool['timestamp']],
                        ['Findings:', str(tool['findings_count'])],
                        ['Data File:', tool['file']],
                    ]
                    
                    tool_table = Table(tool_data, colWidths=[1.5*inch, 4.5*inch])
                    tool_table.setStyle(TableStyle([
                        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 9),
                        ('TOPPADDING', (0, 0), (-1, -1), 4),
                        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
                    ]))
                    story.append(tool_table)
                    story.append(Spacer(1, 0.15*inch))
            else:
                story.append(Paragraph("No analysis tools have been run yet.", styles['Normal']))
                story.append(Spacer(1, 0.2*inch))
            
            # Recommendations
            if status_data['recommendations']:
                story.append(Spacer(1, 0.2*inch))
                story.append(Paragraph("Recommendations", styles['Heading2']))
                for i, rec in enumerate(status_data['recommendations'], 1):
                    story.append(Paragraph(f"{i}. {rec}", styles['Normal']))
                    story.append(Spacer(1, 0.1*inch))
            
            # Build PDF
            doc.build(story)
            
        except ImportError as e:
            print_error("reportlab library not found!")
            print()
            print_info("PDF generation requires the 'reportlab' library.")
            print_info("Please install it using one of these methods:")
            print()
            print(f"  {Colors.BOLD}Method 1 - Run installation script:{Colors.ENDC}")
            print(f"    ./install_dependencies.sh")
            print()
            print(f"  {Colors.BOLD}Method 2 - Manual install:{Colors.ENDC}")
            print(f"    pip3 install reportlab --break-system-packages")
            print()
            print_info("After installing, restart the dashboard and try again.")
            print()
            raise Exception("reportlab not installed - please install and restart dashboard")
    
    def create_pattern_file(self):
        """Create custom pattern file"""
        print_header("CREATE CUSTOM PATTERN FILE")
        
        print_info("Create a custom pattern file for log analysis")
        print()
        
        filename = input(f"{Colors.CYAN}Enter filename (e.g., custom_patterns.txt): {Colors.ENDC}").strip()
        
        if not filename:
            print_error("Filename required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        if not filename.endswith('.txt'):
            filename += '.txt'
        
        if Path(filename).exists():
            overwrite = input(f"{Colors.ORANGE}File exists. Overwrite? (yes/no): {Colors.ENDC}").strip().lower()
            if overwrite != 'yes':
                print_info("Cancelled")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        # Create example pattern file
        try:
            subprocess.run(['./log_directory_analyzer.py', '--create-example', filename])
            print_success(f"Created {filename}")
            print_info("Edit the file to add your custom patterns")
            print_info(f"Then use it in analysis with: -p {filename}")
        except Exception as e:
            print_error(f"Error creating pattern file: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def list_patterns(self):
        """List available pattern files"""
        print_header("AVAILABLE PATTERN FILES")
        
        # Check default patterns
        print(f"{Colors.BOLD}Default Pattern Files:{Colors.ENDC}\n")
        for name, filename in self.default_patterns.items():
            exists = Path(filename).exists()
            status = f"{Colors.GREEN}✓{Colors.ENDC}" if exists else f"{Colors.RED}✗{Colors.ENDC}"
            print(f"  {status} {name}: {filename}")
        
        # Check whitelist
        print(f"\n{Colors.BOLD}Whitelist File (False Positive Filter):{Colors.ENDC}\n")
        whitelist_exists = Path(self.whitelist_file).exists()
        status = f"{Colors.GREEN}✓{Colors.ENDC}" if whitelist_exists else f"{Colors.RED}✗{Colors.ENDC}"
        print(f"  {status} {self.whitelist_file}")
        if whitelist_exists:
            print(f"     {Colors.DIM}Filters legitimate Apple services (XProtect, Safari, iCloud, etc.){Colors.ENDC}")
        
        
        # Check for custom patterns
        custom_patterns = [f for f in Path('.').glob('*_patterns.txt') 
                          if str(f) not in self.default_patterns.values()]
        
        if custom_patterns:
            print(f"\n{Colors.BOLD}Custom Pattern Files:{Colors.ENDC}\n")
            for p in custom_patterns:
                print(f"  {Colors.GREEN}✓{Colors.ENDC} {p}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def quick_scan(self):
        """Quick scan without investigation"""
        print_header("QUICK SCAN")
        
        print_info("Quick log scan without creating an investigation")
        print_warning("For formal investigations, create a case first")
        print()
        
        # Select directory
        print(f"{Colors.BOLD}Select directory to scan:{Colors.ENDC}\n")
        for i, d in enumerate(self.common_log_dirs, 1):
            exists = Path(d).exists()
            status = f"{Colors.GREEN}✓{Colors.ENDC}" if exists else f"{Colors.RED}✗{Colors.ENDC}"
            print(f"  {i}. {status} {d}")
        print(f"  {len(self.common_log_dirs) + 1}. Custom directory")
        
        choice = input(f"\n{Colors.CYAN}Select directory: {Colors.ENDC}").strip()
        
        try:
            idx = int(choice)
            
            if 1 <= idx <= len(self.common_log_dirs):
                scan_dir = self.common_log_dirs[idx - 1]
            elif idx == len(self.common_log_dirs) + 1:
                scan_dir = input(f"  {Colors.CYAN}Enter directory path: {Colors.ENDC}").strip()
            else:
                print_error("Invalid selection")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            if not Path(scan_dir).exists():
                print_error("Directory not found")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Select pattern files
            pattern_files = []
            print(f"\n{Colors.BOLD}Available patterns:{Colors.ENDC}\n")
            for i, (name, filename) in enumerate(self.default_patterns.items(), 1):
                if Path(filename).exists():
                    print(f"  {i}. {name}: {filename}")
                    pattern_files.append(filename)
            
            if not pattern_files:
                print_error("No pattern files found")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Use all available patterns
            print_info(f"Using {len(pattern_files)} pattern file(s)")
            
            # Show whitelist status
            if Path(self.whitelist_file).exists():
                print_info(f"Whitelist: {self.whitelist_file} (filtering false positives)")
            
            
            # Create temp output
            output_dir = Path.home() / "Apple_FORENSICS_Quick_Scans" / datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Build command
            cmd = ['./log_directory_analyzer.py', '-d', scan_dir]
            for p in pattern_files:
                cmd.extend(['-p', p])
            
            # Add whitelist if it exists
            if Path(self.whitelist_file).exists():
                cmd.extend(['-w', self.whitelist_file])
            
            cmd.extend(['-o', str(output_dir), '-v'])
            
            print_section("Running Quick Scan")
            print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
            
            # Run
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print_success("Quick scan completed")
                print_info(f"Results: {output_dir}")
                
                # Find markdown report
                md_files = list(output_dir.glob('log_analysis_*.md'))
                if md_files:
                    print_info(f"Report: {md_files[0]}")
                    
                    open_report = input(f"\n{Colors.CYAN}Open report? (yes/no): {Colors.ENDC}").strip().lower()
                    if open_report == 'yes':
                        subprocess.run(['open', str(md_files[0])])
            else:
                print_error("Quick scan failed")
                print(result.stderr)
        
        except ValueError:
            print_error("Invalid input")
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def process_memory_snapshot(self):
        """Capture detailed memory snapshot of a specific process"""
        print_header("PROCESS MEMORY SNAPSHOT")
        
        print_info("Capture detailed memory information for a specific process")
        print_warning("Requires PID - use System Process Triage (option 21) to find PIDs")
        print()
        print(f"{Colors.DIM}Note: Most processes work without sudo. Use sudo if you get permission errors.{Colors.ENDC}")
        print()
        
        pid = input(f"{Colors.CYAN}Enter PID to snapshot: {Colors.ENDC}").strip()
        
        if not pid or not pid.isdigit():
            print_error("Invalid PID")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "runtime_monitoring"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "memory_snapshots"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['./process_memory_snapshot.py', pid, str(output_dir)]
        
        print_section("Capturing Process Memory Snapshot")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
        
        generated_file = None
        
        try:
            # Check if script exists
            if not Path('./process_memory_snapshot.py').exists():
                print_error("process_memory_snapshot.py not found")
                print_info("Make sure process_memory_snapshot.py is in the current directory")
                print_info("And it's executable: chmod +x process_memory_snapshot.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run snapshot
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(result.stdout)
                print_success(f"Memory snapshot completed")
                print_info(f"Saved to: {output_dir}")
                
                # Extract filename from output
                import re
                match = re.search(r'process_\d+_\d+\.json', result.stdout)
                if match:
                    generated_file = output_dir / match.group(0)
            else:
                print_error("Snapshot failed")
                print(result.stderr)
                if "Permission denied" in result.stderr:
                    print()
                    print_warning("Try running with sudo for this process:")
                    print(f"{Colors.DIM}  sudo {' '.join(cmd)}{Colors.ENDC}")
        
        except Exception as e:
            print_error(f"Error: {e}")
        
        # Offer to view the generated file
        if generated_file and generated_file.exists():
            print()
            view = input(f"{Colors.CYAN}View snapshot file? (y/n): {Colors.ENDC}").strip().lower()
            if view == 'y':
                try:
                    subprocess.run(['open', str(generated_file)])
                    print_info(f"Opening {generated_file.name} in default JSON viewer")
                except Exception as e:
                    print_warning(f"Could not open file: {e}")
                    print_info(f"View manually: open {generated_file}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def system_process_triage(self):
        """Capture snapshot of ALL running processes"""
        print_header("SYSTEM PROCESS TRIAGE")
        
        print_info("Capture snapshot of ALL running processes")
        print_info("Perfect for: finding PIDs, memory hogs, suspicious processes")
        print()
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "runtime_monitoring"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "process_triage"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Ask for options
        print(f"{Colors.BOLD}Options:{Colors.ENDC}")
        print("  1. All processes (full snapshot)")
        print("  2. Top 20 by memory")
        print("  3. Top 20 by CPU")
        
        choice = input(f"\n{Colors.CYAN}Select option: {Colors.ENDC}").strip()
        
        # Build command
        cmd = ['./process_triage_collector.py', '-o', str(output_dir)]
        
        if choice == "2":
            cmd.extend(['--top', '20', '--sort', 'memory'])
        elif choice == "3":
            cmd.extend(['--top', '20', '--sort', 'cpu'])
        else:
            cmd.extend(['--sort', 'memory'])
        
        print_section("Capturing System Process Triage")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}\n")
        
        try:
            # Check if script exists
            if not Path('./process_triage_collector.py').exists():
                print_error("process_triage_collector.py not found")
                print_info("Make sure process_triage_collector.py is in the current directory")
                print_info("And it's executable: chmod +x process_triage_collector.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run triage
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                print(result.stdout)
                print_success(f"Process triage completed")
                print_info(f"Saved to: {output_dir}")
            else:
                print_error("Triage failed")
                print(result.stderr)
        
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def network_capture(self):
        """Capture network traffic"""
        print_header("NETWORK TRAFFIC CAPTURE")
        
        print_warning("Requires sudo privileges")
        print_info("Captures network packets for forensic analysis")
        print()
        
        # Get parameters
        duration = input(f"{Colors.CYAN}Capture duration in seconds (default: 60): {Colors.ENDC}").strip()
        if not duration:
            duration = "60"
        elif not duration.isdigit():
            print_error("Invalid duration")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        interface = input(f"{Colors.CYAN}Network interface (default: en0): {Colors.ENDC}").strip()
        if not interface:
            interface = "en0"
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "runtime_monitoring"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "network_captures"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['sudo', './network_capture.py', duration, interface, str(output_dir)]
        
        print_section("Capturing Network Traffic")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}")
        print_warning("This will prompt for your password")
        print()
        
        try:
            # Check if script exists
            if not Path('./network_capture.py').exists():
                print_error("network_capture.py not found")
                print_info("Make sure network_capture.py is in the current directory")
                print_info("And it's executable: chmod +x network_capture.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run capture
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print_success(f"Network capture completed")
                print_info(f"Saved to: {output_dir}")
            else:
                print_error("Network capture failed or was cancelled")
        
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def combined_capture(self):
        """Combined process memory + network capture for single PID"""
        print_header("COMBINED PROCESS + NETWORK CAPTURE")
        
        print_warning("Requires sudo privileges for network capture")
        print_info("Captures process memory snapshots + network activity simultaneously")
        print_info("Perfect for: malware analysis, pre-spindump triage, performance investigation")
        print()
        
        # Get PID
        pid = input(f"{Colors.CYAN}Enter PID to monitor: {Colors.ENDC}").strip()
        
        if not pid or not pid.isdigit():
            print_error("Invalid PID")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Get duration
        duration = input(f"{Colors.CYAN}Capture duration in seconds (default: 60): {Colors.ENDC}").strip()
        if not duration:
            duration = "60"
        elif not duration.isdigit():
            print_error("Invalid duration")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Get interface
        interface = input(f"{Colors.CYAN}Network interface (default: en0): {Colors.ENDC}").strip()
        if not interface:
            interface = "en0"
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "runtime_monitoring" / "combined_captures"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "combined_captures"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['sudo', './combined_capture.py', pid, duration, interface]
        
        print_section("Combined Process + Network Capture")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}")
        print_warning("This will prompt for your password")
        print()
        
        # Change to output directory for the script
        original_dir = os.getcwd()
        try:
            os.chdir(output_dir)
            
            # Check if script exists in original directory
            script_path = Path(original_dir) / 'combined_capture.py'
            if not script_path.exists():
                print_error("combined_capture.py not found")
                print_info("Make sure combined_capture.py is in the current directory")
                print_info("And it's executable: chmod +x combined_capture.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run from original directory
            os.chdir(original_dir)
            cmd_with_output = cmd + [str(output_dir)]
            
            # Run capture
            result = subprocess.run(cmd_with_output)
            
            if result.returncode == 0:
                print_success(f"Combined capture completed")
                print_info(f"Saved to: {output_dir}")
            else:
                print_error("Combined capture failed or was cancelled")
        
        except Exception as e:
            print_error(f"Error: {e}")
        finally:
            os.chdir(original_dir)
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def system_network_capture(self):
        """System-wide process triage + network capture"""
        print_header("SYSTEM + NETWORK CAPTURE")
        
        print_warning("Requires sudo privileges for network capture")
        print_info("Captures ALL processes + network traffic simultaneously")
        print_info("Perfect for: incident response, complete system state, baseline")
        print()
        
        # Get duration
        duration = input(f"{Colors.CYAN}Capture duration in seconds (default: 60): {Colors.ENDC}").strip()
        if not duration:
            duration = "60"
        elif not duration.isdigit():
            print_error("Invalid duration")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Get interface
        interface = input(f"{Colors.CYAN}Network interface (default: en0): {Colors.ENDC}").strip()
        if not interface:
            interface = "en0"
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "runtime_monitoring" / "system_captures"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "system_captures"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['sudo', './system_network_capture.py', duration, interface]
        
        print_section("System + Network Capture")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}")
        print_warning("This will prompt for your password")
        print()
        
        # Change to output directory for the script
        original_dir = os.getcwd()
        try:
            os.chdir(output_dir)
            
            # Check if script exists in original directory
            script_path = Path(original_dir) / 'system_network_capture.py'
            if not script_path.exists():
                print_error("system_network_capture.py not found")
                print_info("Make sure system_network_capture.py is in the current directory")
                print_info("And it's executable: chmod +x system_network_capture.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run from original directory
            os.chdir(original_dir)
            cmd_with_output = cmd + [str(output_dir)]
            
            # Run capture
            result = subprocess.run(cmd_with_output)
            
            if result.returncode == 0:
                print_success(f"System + network capture completed")
                print_info(f"Saved to: {output_dir}")
            else:
                print_error("Capture failed or was cancelled")
        
        except Exception as e:
            print_error(f"Error: {e}")
        finally:
            os.chdir(original_dir)
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def home_directory_analysis(self):
        """Analyze user home directory for forensic artifacts"""
        print_header("HOME DIRECTORY FORENSIC ANALYSIS")
        
        print_info("Analyzes user home directory for suspicious artifacts:")
        print("  • Shell command history (bash, zsh, fish)")
        print("  • Downloads folder (suspicious files)")
        print("  • SSH keys and configuration")
        print("  • Hidden configuration files")
        print("  • Suspicious scripts and executables")
        print()
        
        # Get target directory
        print(f"{Colors.BOLD}Target Directory:{Colors.ENDC}")
        print("  1. Current user's home directory")
        print("  2. Specify custom directory")
        
        dir_choice = input(f"{Colors.CYAN}Select (1-2): {Colors.ENDC}").strip()
        
        if dir_choice == "2":
            target_dir = input(f"{Colors.CYAN}Enter directory path: {Colors.ENDC}").strip()
            if not target_dir:
                print_error("Directory path required")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        else:
            target_dir = str(Path.home())
        
        # Check if directory exists
        if not Path(target_dir).exists():
            print_error(f"Directory does not exist: {target_dir}")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Ask about whitelist
        use_whitelist = input(f"{Colors.CYAN}Use whitelist to exclude legitimate tools? (y/n, default: y): {Colors.ENDC}").strip().lower()
        if use_whitelist == '' or use_whitelist == 'y':
            # Use investigation's configured whitelists if available
            whitelist_arg = []
            if self.current_investigation and self.current_investigation.whitelist_files:
                for w in self.current_investigation.whitelist_files:
                    if Path(w).exists():
                        whitelist_arg.extend(['-w', w])
                if whitelist_arg:
                    print_info(f"Using {len(self.current_investigation.whitelist_files)} configured whitelist(s)")
            else:
                # Fallback to default whitelists
                for whitelist_file in ['macos_whitelist.txt', 'apple_forensics_whitelist.txt']:
                    whitelist_path = Path(whitelist_file)
                    if whitelist_path.exists():
                        whitelist_arg.extend(['-w', whitelist_file])
                        print_info(f"Using whitelist: {whitelist_file}")
                
                if not whitelist_arg:
                    print_warning("No whitelist files found")
                    print_info("Analysis will continue without whitelist filtering")
        else:
            whitelist_arg = []
        
        # Determine output directory
        if self.current_investigation:
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            output_dir = inv_dir / "artifacts" / "home_directory"
            output_dir.mkdir(parents=True, exist_ok=True)
        else:
            output_dir = Path.home() / "Apple_FORENSICS_Runtime" / "artifact_analysis"
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command
        cmd = ['./home_directory_analyzer.py', '-d', target_dir, '-o', str(output_dir), '-v'] + whitelist_arg
        
        print_section("Analyzing Home Directory")
        print(f"{Colors.DIM}Target: {target_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Command: {' '.join(cmd)}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./home_directory_analyzer.py').exists():
                print_error("home_directory_analyzer.py not found")
                print_info("Make sure home_directory_analyzer.py is in the current directory")
                print_info("And it's executable: chmod +x home_directory_analyzer.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run analysis
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success(f"Home directory analysis completed")
                print_info(f"Reports saved to: {output_dir}")
                print()
                print_info("Review the Markdown report for human-readable findings:")
                
                # Find the most recent report
                md_files = list(output_dir.glob("home_analysis_*.md"))
                if md_files:
                    latest_md = max(md_files, key=lambda p: p.stat().st_mtime)
                    print(f"  {Colors.CYAN}{latest_md}{Colors.ENDC}")
                    
                    # Ask if user wants to view summary
                    view_summary = input(f"\n{Colors.CYAN}View findings summary? (y/n): {Colors.ENDC}").strip().lower()
                    if view_summary == 'y':
                        # Find corresponding JSON file for summary
                        json_files = list(output_dir.glob("home_analysis_*.json"))
                        if json_files:
                            latest_json = max(json_files, key=lambda p: p.stat().st_mtime)
                            with open(latest_json, 'r') as f:
                                data = json.load(f)
                                findings = data.get('findings', [])
                                
                                print()
                                print_section("Analysis Summary")
                                print(f"Total findings: {len(findings)}")
                                
                                high_count = sum(1 for f in findings if f['severity'] == 'HIGH')
                                medium_count = sum(1 for f in findings if f['severity'] == 'MEDIUM')
                                low_count = sum(1 for f in findings if f['severity'] == 'LOW')
                                
                                if high_count > 0:
                                    print(f"{Colors.RED}  HIGH severity: {high_count}{Colors.ENDC}")
                                if medium_count > 0:
                                    print(f"{Colors.ORANGE}  MEDIUM severity: {medium_count}{Colors.ENDC}")
                                if low_count > 0:
                                    print(f"{Colors.YELLOW}  LOW severity: {low_count}{Colors.ENDC}")
                                
                                print()
                                
                                # Show HIGH severity findings
                                if high_count > 0:
                                    print_section("HIGH Severity Findings")
                                    high_findings = [f for f in findings if f['severity'] == 'HIGH'][:5]
                                    for f in high_findings:
                                        print(f"{Colors.RED}• {f['category']}: {f['description']}{Colors.ENDC}")
                                    
                                    if high_count > 5:
                                        print(f"\n{Colors.DIM}  ... and {high_count - 5} more HIGH severity findings{Colors.ENDC}")
                                    print()
                
                # Record in investigation if one is active
                if self.current_investigation:
                    run_info = {
                        'timestamp': datetime.utcnow().isoformat() + 'Z',
                        'tool': 'home_directory_analyzer',
                        'target_directory': target_dir,
                        'output_directory': str(output_dir),
                        'findings_count': len(findings) if 'findings' in locals() else 'unknown'
                    }
                    self.current_investigation.add_analysis_run(run_info)
                    inv_dir = self.investigations_dir / self.current_investigation.case_id
                    self.current_investigation.save(inv_dir)
            else:
                print_error("Analysis failed")
        
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def analysis_cleanup_tool(self):
        """Run analysis cleanup tool to retroactively filter false positives"""
        print_header("ANALYSIS CLEANUP TOOL")
        
        print_info("Retroactively filter false positives from existing analysis files")
        print_info("Uses updated whitelists to clean already-completed analyses")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        
        # Select input directory
        print(f"{Colors.BOLD}Select analysis files to clean:{Colors.ENDC}")
        print("  1. All analysis files in investigation")
        print("  2. Specific analysis directory")
        print("  3. Single analysis file")
        print()
        
        choice = input(f"{Colors.CYAN}Choice (1-3): {Colors.ENDC}").strip()
        
        input_path = None
        
        if choice == "1":
            # Entire investigation
            input_path = inv_dir
            print_info(f"Will scan: {inv_dir}")
        
        elif choice == "2":
            # Specific directory
            print()
            print("Common analysis directories:")
            analysis_dirs = []
            
            # List possible analysis directories
            for d in inv_dir.iterdir():
                if d.is_dir() and ('analysis' in d.name.lower() or 'artifacts' in d.name.lower()):
                    analysis_dirs.append(d)
            
            if analysis_dirs:
                for i, d in enumerate(analysis_dirs, 1):
                    print(f"  {i}. {d.name}")
                print(f"  0. Enter custom path")
                print()
                
                dir_choice = input(f"{Colors.CYAN}Select directory: {Colors.ENDC}").strip()
                
                if dir_choice == "0":
                    custom_path = input(f"{Colors.CYAN}Enter directory path: {Colors.ENDC}").strip()
                    input_path = Path(custom_path)
                elif dir_choice.isdigit() and 1 <= int(dir_choice) <= len(analysis_dirs):
                    input_path = analysis_dirs[int(dir_choice) - 1]
                else:
                    print_error("Invalid choice")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
            else:
                print_info("No analysis directories found")
                custom_path = input(f"{Colors.CYAN}Enter directory path: {Colors.ENDC}").strip()
                input_path = Path(custom_path)
        
        elif choice == "3":
            # Single file
            file_path = input(f"{Colors.CYAN}Enter JSON file path: {Colors.ENDC}").strip()
            input_path = Path(file_path)
        
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        if not input_path or not input_path.exists():
            print_error(f"Path does not exist: {input_path}")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Ask about whitelist
        print()
        use_whitelist = input(f"{Colors.CYAN}Use configured whitelists? (y/n, default: y): {Colors.ENDC}").strip().lower()
        
        whitelist_files = []
        if use_whitelist == '' or use_whitelist == 'y':
            # Use investigation's configured whitelists
            if self.current_investigation.whitelist_files:
                for w in self.current_investigation.whitelist_files:
                    if Path(w).exists():
                        whitelist_files.append(w)
                print_info(f"Using {len(whitelist_files)} configured whitelist(s)")
            else:
                # Fallback to default whitelists
                for whitelist_file in ['macos_whitelist.txt', 'apple_forensics_whitelist.txt']:
                    if Path(whitelist_file).exists():
                        whitelist_files.append(whitelist_file)
                        print_info(f"Found whitelist: {whitelist_file}")
        
        if not whitelist_files:
            print_warning("No whitelist files available")
            proceed = input(f"{Colors.CYAN}Proceed anyway? (y/n): {Colors.ENDC}").strip().lower()
            if proceed != 'y':
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        # Determine output directory
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        output_dir = inv_dir / f"cleaned_{timestamp}"
        
        # Build command
        if input_path.is_file():
            cmd = ['./analysis_cleanup_tool.py', '-f', str(input_path)]
        else:
            cmd = ['./analysis_cleanup_tool.py', '-i', str(input_path)]
        
        # Add whitelists
        for w in whitelist_files:
            cmd.extend(['-w', w])
        
        # Add output directory
        cmd.extend(['-o', str(output_dir)])
        
        # Add verbose
        cmd.append('-v')
        
        print()
        print_section("Running Cleanup Tool")
        print(f"{Colors.DIM}Input: {input_path}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Whitelists: {len(whitelist_files)}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./analysis_cleanup_tool.py').exists():
                print_error("analysis_cleanup_tool.py not found")
                print_info("Make sure analysis_cleanup_tool.py is in the current directory")
                print_info("And it's executable: chmod +x analysis_cleanup_tool.py")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run cleanup tool
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Cleanup completed")
                print_info(f"Cleaned reports saved to: {output_dir}")
            else:
                print_error("Cleanup failed")
        
        except Exception as e:
            print_error(f"Error: {e}")
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def analysis_chrome_history(self):
        """Run Chrome history analyzer - Option 38"""
        print_header("CHROME HISTORY ANALYSIS")
        
        print_info("Extract and analyze Chrome browser history for forensic investigation")
        print_info("Detects: Suspicious URLs, Downloads, Search Queries, Extensions, Incognito Mode")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        output_dir = inv_dir / 'artifacts' / 'browser_forensics' / 'chrome'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Profile selection
        print(f"{Colors.BOLD}Target Chrome Profile:{Colors.ENDC}")
        print("  1. Current user's default profile")
        print("  2. Specific Chrome profile (enter path)")
        print("  3. All Chrome profiles (analyze all found)")
        print()
        
        profile_choice = input(f"{Colors.CYAN}Choice (1-3): {Colors.ENDC}").strip()
        
        profile_path = None
        
        if profile_choice == "1":
            # Use default
            default_profile = Path.home() / 'Library/Application Support/Google/Chrome/Default'
            if default_profile.exists():
                profile_path = str(default_profile)
                print_info(f"Using: {profile_path}")
            else:
                print_error("Default Chrome profile not found")
                print_info("Chrome may not be installed or profile is in different location")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        elif profile_choice == "2":
            # Custom path
            print()
            custom_path = input(f"{Colors.CYAN}Enter Chrome profile path: {Colors.ENDC}").strip()
            custom_path = custom_path.strip('"').strip("'")  # Remove quotes if pasted
            expanded_path = Path(custom_path).expanduser()
            
            if expanded_path.exists():
                profile_path = str(expanded_path)
                print_info(f"Using: {profile_path}")
            else:
                print_error(f"Profile not found: {custom_path}")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        elif profile_choice == "3":
            # All profiles
            chrome_base = Path.home() / 'Library/Application Support/Google/Chrome'
            if chrome_base.exists():
                profiles = [p for p in chrome_base.iterdir() 
                           if p.is_dir() and (p / 'History').exists()]
                if profiles:
                    print_info(f"Found {len(profiles)} Chrome profile(s)")
                    print_info("Analyzing default profile (multi-profile support coming soon)")
                    profile_path = str(chrome_base / 'Default')
                else:
                    print_error("No Chrome profiles found")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
            else:
                print_error("Chrome not found on this system")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Date range
        print()
        print(f"{Colors.BOLD}Date Range:{Colors.ENDC}")
        print("  1. All history")
        print("  2. Last 30 days")
        print("  3. Last 90 days")
        print("  4. Custom range (future enhancement)")
        print()
        
        date_choice = input(f"{Colors.CYAN}Choice (1-4, default: 1): {Colors.ENDC}").strip()
        if not date_choice:
            date_choice = "1"
        
        # Filters
        print()
        print(f"{Colors.BOLD}Analysis Focus:{Colors.ENDC}")
        print_info("Leave all blank for comprehensive analysis")
        print()
        
        downloads_only = input(f"{Colors.CYAN}Focus on downloads only? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        searches_only = input(f"{Colors.CYAN}Focus on search queries only? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        suspicious_only = input(f"{Colors.CYAN}Show only suspicious URLs? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        
        # Build command
        cmd = [
            './chrome_history_analyzer.py',
            '-p', profile_path,
            '-o', str(output_dir),
            '--case-id', self.current_investigation.case_id
        ]
        
        # Add whitelist if configured
        whitelist_applied = False
        if self.current_investigation.whitelist_files:
            for w in self.current_investigation.whitelist_files:
                if Path(w).exists():
                    cmd.extend(['-w', w])
                    whitelist_applied = True
        
        # Check for default chrome_whitelist.txt
        if not whitelist_applied and Path('chrome_whitelist.txt').exists():
            cmd.extend(['-w', 'chrome_whitelist.txt'])
            print_info("Using default chrome_whitelist.txt for false positive filtering")
            whitelist_applied = True
        
        if not whitelist_applied:
            print_warning("No whitelist configured - may produce many false positives")
            print_info("Consider adding chrome_whitelist.txt to reduce noise")
        
        # Add date filters (future enhancement - not yet implemented in tool)
        if date_choice == '2':
            cmd.extend(['--last-days', '30'])
        elif date_choice == '3':
            cmd.extend(['--last-days', '90'])
        elif date_choice == '4':
            print_warning("Custom date range not yet implemented")
            # Future: prompt for dates
        
        # Add verbose
        cmd.append('-v')
        
        print()
        print_section("Running Chrome History Analyzer")
        print(f"{Colors.DIM}Profile: {profile_path}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Whitelist: {'Applied' if whitelist_applied else 'Not applied'}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./chrome_history_analyzer.py').exists():
                print_error("chrome_history_analyzer.py not found in current directory")
                print()
                print_info("Installation required:")
                print_info("1. Download chrome_history_analyzer.py")
                print_info("2. Place in Apple FORENSICS directory")
                print_info("3. chmod +x chrome_history_analyzer.py")
                print()
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run analyzer
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Chrome history analysis completed")
                print_info(f"Results saved to: {output_dir}")
                print()
                
                # List generated files
                json_files = list(output_dir.glob('chrome_history_*.json'))
                csv_files = list(output_dir.glob('chrome_history_*.csv'))
                md_files = list(output_dir.glob('chrome_history_*.md'))
                sha_files = list(output_dir.glob('*.sha256'))
                
                print_section("Generated Reports")
                if json_files:
                    print(f"{Colors.GREEN}  JSON:{Colors.ENDC} {json_files[0].name}")
                if csv_files:
                    print(f"{Colors.GREEN}  CSV:{Colors.ENDC}  {csv_files[0].name}")
                if md_files:
                    print(f"{Colors.GREEN}  MD:{Colors.ENDC}   {md_files[0].name}")
                if sha_files:
                    print(f"{Colors.DIM}  Hash: {sha_files[0].name}{Colors.ENDC}")
                
                print()
                print_info(f"Review findings in: {md_files[0].name if md_files else 'Markdown report'}")
                
                # Record analysis run
                run_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'tool': 'chrome_history_analyzer',
                    'version': '1.0',
                    'profile_path': profile_path,
                    'output_directory': str(output_dir),
                    'whitelist_applied': whitelist_applied,
                    'filters': {
                        'downloads_only': downloads_only,
                        'searches_only': searches_only,
                        'suspicious_only': suspicious_only
                    },
                    'date_filter': date_choice
                }
                self.current_investigation.add_analysis_run(run_info)
                self.current_investigation.save(inv_dir)
                
                print()
                print_success("Analysis run recorded in investigation metadata")
            else:
                print()
                print_error("Analysis failed - check error messages above")
        
        except FileNotFoundError as e:
            print_error(f"Error: {e}")
            print_info("Make sure chrome_history_analyzer.py is executable")
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def analysis_safari_history(self):
        """Run Safari history analyzer - Option 39"""
        print_header("SAFARI HISTORY ANALYSIS")
        
        print_info("Extract and analyze Safari browser history for forensic investigation")
        print_info("Detects: Suspicious URLs, Downloads, Timeline Events")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        output_dir = inv_dir / 'artifacts' / 'browser_forensics' / 'safari'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Safari directory location
        print(f"{Colors.BOLD}Safari Data Location:{Colors.ENDC}")
        print("  1. Current user's default Safari directory")
        print("  2. Specific Safari directory (enter path)")
        print()
        
        safari_choice = input(f"{Colors.CYAN}Choice (1-2, default: 1): {Colors.ENDC}").strip()
        if not safari_choice:
            safari_choice = "1"
        
        safari_dir = None
        
        if safari_choice == "1":
            # Use default
            default_safari = Path.home() / 'Library/Safari'
            if default_safari.exists():
                safari_dir = str(default_safari)
                print_info(f"Using: {safari_dir}")
            else:
                print_error("Default Safari directory not found")
                print_info("Safari may not be used on this system")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        elif safari_choice == "2":
            # Custom path
            print()
            custom_path = input(f"{Colors.CYAN}Enter Safari directory path: {Colors.ENDC}").strip()
            custom_path = custom_path.strip('"').strip("'")  # Remove quotes if pasted
            expanded_path = Path(custom_path).expanduser()
            
            if expanded_path.exists():
                safari_dir = str(expanded_path)
                print_info(f"Using: {safari_dir}")
            else:
                print_error(f"Safari directory not found: {custom_path}")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Analysis focus
        print()
        print(f"{Colors.BOLD}Analysis Focus:{Colors.ENDC}")
        print_info("Suspicious URLs only = Faster, focused on threats")
        print_info("All URLs = Complete timeline, alibi verification, comprehensive review")
        print()
        
        suspicious_only = input(f"{Colors.CYAN}Show only suspicious URLs? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        
        # Build command
        cmd = [
            './safari_history_analyzer.py',
            '--safari-dir', safari_dir,
            '-o', str(output_dir),
            '--case-id', self.current_investigation.case_id
        ]
        
        # Add whitelist if configured
        whitelist_applied = False
        if self.current_investigation.whitelist_files:
            for w in self.current_investigation.whitelist_files:
                if Path(w).exists():
                    cmd.extend(['-w', w])
                    whitelist_applied = True
        
        # Check for default safari_whitelist.txt
        if not whitelist_applied and Path('safari_whitelist.txt').exists():
            cmd.extend(['-w', 'safari_whitelist.txt'])
            print()
            print_info("Using default safari_whitelist.txt for false positive filtering")
            whitelist_applied = True
        
        if not whitelist_applied:
            print()
            print_warning("No whitelist configured - may produce many false positives")
            print_info("Consider adding safari_whitelist.txt to reduce noise")
        
        # Add suspicious-only flag if enabled
        if suspicious_only:
            cmd.append('--suspicious-only')
        
        # Add verbose
        cmd.append('-v')
        
        print()
        print_section("Running Safari History Analyzer")
        print(f"{Colors.DIM}Safari Directory: {safari_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Whitelist: {'Applied' if whitelist_applied else 'Not applied'}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./safari_history_analyzer.py').exists():
                print_error("safari_history_analyzer.py not found in current directory")
                print()
                print_info("Installation required:")
                print_info("1. Download safari_history_analyzer.py")
                print_info("2. Place in Apple FORENSICS directory")
                print_info("3. chmod +x safari_history_analyzer.py")
                print()
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run analyzer
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Safari history analysis completed")
                print_info(f"Results saved to: {output_dir}")
                print()
                
                # List generated files
                json_files = list(output_dir.glob('safari_history_*.json'))
                csv_files = list(output_dir.glob('safari_history_*.csv'))
                md_files = list(output_dir.glob('safari_history_*.md'))
                sha_files = list(output_dir.glob('*.sha256'))
                
                print_section("Generated Reports")
                if json_files:
                    print(f"{Colors.GREEN}  JSON:{Colors.ENDC} {json_files[0].name}")
                if csv_files:
                    print(f"{Colors.GREEN}  CSV:{Colors.ENDC}  {csv_files[0].name}")
                if md_files:
                    print(f"{Colors.GREEN}  MD:{Colors.ENDC}   {md_files[0].name}")
                if sha_files:
                    print(f"{Colors.DIM}  Hash: {sha_files[0].name}{Colors.ENDC}")
                
                print()
                print_info(f"Review findings in: {md_files[0].name if md_files else 'Markdown report'}")
                
                # Record analysis run
                run_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'tool': 'safari_history_analyzer',
                    'version': '1.0',
                    'safari_directory': safari_dir,
                    'output_directory': str(output_dir),
                    'whitelist_applied': whitelist_applied,
                    'suspicious_only': suspicious_only
                }
                self.current_investigation.add_analysis_run(run_info)
                self.current_investigation.save(inv_dir)
                
                print()
                print_success("Analysis run recorded in investigation metadata")
            else:
                print()
                print_error("Analysis failed - check error messages above")
        
        except FileNotFoundError as e:
            print_error(f"Error: {e}")
            print_info("Make sure safari_history_analyzer.py is executable")
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def analysis_firefox_history(self):
        """Run Firefox history analyzer - Option 40"""
        print_header("FIREFOX HISTORY ANALYSIS")
        
        print_info("Extract and analyze Firefox browser history for forensic investigation")
        print_info("Detects: Suspicious URLs, Downloads, Form History, Timeline Events")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        output_dir = inv_dir / 'artifacts' / 'browser_forensics' / 'firefox'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Firefox profile selection
        print(f"{Colors.BOLD}Firefox Profile:{Colors.ENDC}")
        print("  1. Auto-detect default profile")
        print("  2. Specific Firefox profile (enter path)")
        print()
        
        profile_choice = input(f"{Colors.CYAN}Choice (1-2, default: 1): {Colors.ENDC}").strip()
        if not profile_choice:
            profile_choice = "1"
        
        profile_path = None
        
        if profile_choice == "1":
            # Auto-detect
            firefox_base = Path.home() / 'Library/Application Support/Firefox/Profiles'
            if firefox_base.exists():
                profiles = list(firefox_base.glob('*.default*'))
                if profiles:
                    profile_path = str(profiles[0])
                    print_info(f"Auto-detected: {profiles[0].name}")
                else:
                    print_error("No Firefox profiles found")
                    input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                    return
            else:
                print_error("Firefox not found on this system")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        elif profile_choice == "2":
            # Custom path
            print()
            custom_path = input(f"{Colors.CYAN}Enter Firefox profile path: {Colors.ENDC}").strip()
            custom_path = custom_path.strip('"').strip("'")  # Remove quotes if pasted
            expanded_path = Path(custom_path).expanduser()
            
            if expanded_path.exists():
                profile_path = str(expanded_path)
                print_info(f"Using: {profile_path}")
            else:
                print_error(f"Profile not found: {custom_path}")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Analysis focus
        print()
        print(f"{Colors.BOLD}Analysis Focus:{Colors.ENDC}")
        print_info("Suspicious URLs only = Faster, focused on threats")
        print_info("All URLs = Complete timeline, alibi verification, comprehensive review")
        print()
        
        suspicious_only = input(f"{Colors.CYAN}Show only suspicious URLs? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        
        # Build command
        cmd = [
            './firefox_history_analyzer.py',
            '-p', profile_path,
            '-o', str(output_dir),
            '--case-id', self.current_investigation.case_id
        ]
        
        # Add whitelist if configured
        whitelist_applied = False
        if self.current_investigation.whitelist_files:
            for w in self.current_investigation.whitelist_files:
                if Path(w).exists():
                    cmd.extend(['-w', w])
                    whitelist_applied = True
        
        # Check for default firefox_whitelist.txt
        if not whitelist_applied and Path('firefox_whitelist.txt').exists():
            cmd.extend(['-w', 'firefox_whitelist.txt'])
            print()
            print_info("Using default firefox_whitelist.txt for false positive filtering")
            whitelist_applied = True
        
        if not whitelist_applied:
            print()
            print_warning("No whitelist configured - may produce many false positives")
            print_info("Consider adding firefox_whitelist.txt to reduce noise")
        
        # Add suspicious-only flag if enabled
        if suspicious_only:
            cmd.append('--suspicious-only')
        
        # Add verbose
        cmd.append('-v')
        
        print()
        print_section("Running Firefox History Analyzer")
        print(f"{Colors.DIM}Profile: {profile_path}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Whitelist: {'Applied' if whitelist_applied else 'Not applied'}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./firefox_history_analyzer.py').exists():
                print_error("firefox_history_analyzer.py not found in current directory")
                print()
                print_info("Installation required:")
                print_info("1. Download firefox_history_analyzer.py")
                print_info("2. Place in Apple FORENSICS directory")
                print_info("3. chmod +x firefox_history_analyzer.py")
                print()
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run analyzer
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Firefox history analysis completed")
                print_info(f"Results saved to: {output_dir}")
                print()
                
                # List generated files
                json_files = list(output_dir.glob('firefox_history_*.json'))
                csv_files = list(output_dir.glob('firefox_history_*.csv'))
                md_files = list(output_dir.glob('firefox_history_*.md'))
                sha_files = list(output_dir.glob('*.sha256'))
                
                print_section("Generated Reports")
                if json_files:
                    print(f"{Colors.GREEN}  JSON:{Colors.ENDC} {json_files[0].name}")
                if csv_files:
                    print(f"{Colors.GREEN}  CSV:{Colors.ENDC}  {csv_files[0].name}")
                if md_files:
                    print(f"{Colors.GREEN}  MD:{Colors.ENDC}   {md_files[0].name}")
                if sha_files:
                    print(f"{Colors.DIM}  Hash: {sha_files[0].name}{Colors.ENDC}")
                
                print()
                print_info(f"Review findings in: {md_files[0].name if md_files else 'Markdown report'}")
                
                # Record analysis run
                run_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'tool': 'firefox_history_analyzer',
                    'version': '1.0',
                    'profile_path': profile_path,
                    'output_directory': str(output_dir),
                    'whitelist_applied': whitelist_applied,
                    'suspicious_only': suspicious_only
                }
                self.current_investigation.add_analysis_run(run_info)
                self.current_investigation.save(inv_dir)
                
                print()
                print_success("Analysis run recorded in investigation metadata")
            else:
                print()
                print_error("Analysis failed - check error messages above")
        
        except FileNotFoundError as e:
            print_error(f"Error: {e}")
            print_info("Make sure firefox_history_analyzer.py is executable")
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def analysis_brave_history(self):
        """Run Brave history analyzer - Option 41"""
        print_header("BRAVE HISTORY ANALYSIS")
        
        print_info("Extract and analyze Brave browser history for forensic investigation")
        print_info("Detects: Suspicious URLs, Downloads, Search Queries, Extensions")
        print_info("Note: Brave is Chromium-based (privacy-focused)")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        output_dir = inv_dir / 'artifacts' / 'browser_forensics' / 'brave'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Brave profile location
        print(f"{Colors.BOLD}Brave Profile:{Colors.ENDC}")
        print("  1. Current user's default profile")
        print("  2. Specific Brave profile (enter path)")
        print()
        
        profile_choice = input(f"{Colors.CYAN}Choice (1-2, default: 1): {Colors.ENDC}").strip()
        if not profile_choice:
            profile_choice = "1"
        
        profile_path = None
        
        if profile_choice == "1":
            # Use default
            default_profile = Path.home() / 'Library/Application Support/BraveSoftware/Brave-Browser/Default'
            if default_profile.exists():
                profile_path = str(default_profile)
                print_info(f"Using: {profile_path}")
            else:
                print_error("Default Brave profile not found")
                print_info("Brave may not be installed on this system")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        elif profile_choice == "2":
            # Custom path
            print()
            custom_path = input(f"{Colors.CYAN}Enter Brave profile path: {Colors.ENDC}").strip()
            custom_path = custom_path.strip('"').strip("'")  # Remove quotes if pasted
            expanded_path = Path(custom_path).expanduser()
            
            if expanded_path.exists():
                profile_path = str(expanded_path)
                print_info(f"Using: {profile_path}")
            else:
                print_error(f"Profile not found: {custom_path}")
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
        
        else:
            print_error("Invalid choice")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Analysis focus
        print()
        print(f"{Colors.BOLD}Analysis Focus:{Colors.ENDC}")
        print_info("Suspicious URLs only = Faster, focused on threats")
        print_info("All URLs = Complete timeline, alibi verification, comprehensive review")
        print()
        
        suspicious_only = input(f"{Colors.CYAN}Show only suspicious URLs? (y/n, default: n): {Colors.ENDC}").strip().lower() == 'y'
        
        # Build command
        cmd = [
            './brave_history_analyzer.py',
            '-p', profile_path,
            '-o', str(output_dir),
            '--case-id', self.current_investigation.case_id
        ]
        
        # Add whitelist if configured
        whitelist_applied = False
        if self.current_investigation.whitelist_files:
            for w in self.current_investigation.whitelist_files:
                if Path(w).exists():
                    cmd.extend(['-w', w])
                    whitelist_applied = True
        
        # Check for default brave_whitelist.txt
        if not whitelist_applied and Path('brave_whitelist.txt').exists():
            cmd.extend(['-w', 'brave_whitelist.txt'])
            print()
            print_info("Using default brave_whitelist.txt for false positive filtering")
            whitelist_applied = True
        
        if not whitelist_applied:
            print()
            print_warning("No whitelist configured - may produce many false positives")
            print_info("Consider adding brave_whitelist.txt to reduce noise")
        
        # Add suspicious-only flag if enabled
        if suspicious_only:
            cmd.append('--suspicious-only')
        
        # Add verbose
        cmd.append('-v')
        
        print()
        print_section("Running Brave History Analyzer")
        print(f"{Colors.DIM}Profile: {profile_path}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Whitelist: {'Applied' if whitelist_applied else 'Not applied'}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./brave_history_analyzer.py').exists():
                print_error("brave_history_analyzer.py not found in current directory")
                print()
                print_info("Installation required:")
                print_info("1. Download brave_history_analyzer.py")
                print_info("2. Place in Apple FORENSICS directory")
                print_info("3. chmod +x brave_history_analyzer.py")
                print()
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run analyzer
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Brave history analysis completed")
                print_info(f"Results saved to: {output_dir}")
                print()
                
                # List generated files
                json_files = list(output_dir.glob('brave_history_*.json'))
                csv_files = list(output_dir.glob('brave_history_*.csv'))
                md_files = list(output_dir.glob('brave_history_*.md'))
                sha_files = list(output_dir.glob('*.sha256'))
                
                print_section("Generated Reports")
                if json_files:
                    print(f"{Colors.GREEN}  JSON:{Colors.ENDC} {json_files[0].name}")
                if csv_files:
                    print(f"{Colors.GREEN}  CSV:{Colors.ENDC}  {csv_files[0].name}")
                if md_files:
                    print(f"{Colors.GREEN}  MD:{Colors.ENDC}   {md_files[0].name}")
                if sha_files:
                    print(f"{Colors.DIM}  Hash: {sha_files[0].name}{Colors.ENDC}")
                
                print()
                print_info(f"Review findings in: {md_files[0].name if md_files else 'Markdown report'}")
                
                # Record analysis run
                run_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'tool': 'brave_history_analyzer',
                    'version': '1.0',
                    'profile_path': profile_path,
                    'output_directory': str(output_dir),
                    'whitelist_applied': whitelist_applied,
                    'suspicious_only': suspicious_only
                }
                self.current_investigation.add_analysis_run(run_info)
                self.current_investigation.save(inv_dir)
                
                print()
                print_success("Analysis run recorded in investigation metadata")
            else:
                print()
                print_error("Analysis failed - check error messages above")
        
        except FileNotFoundError as e:
            print_error(f"Error: {e}")
            print_info("Make sure brave_history_analyzer.py is executable")
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def search_date_range(self):
        """Search investigation artifacts by date range - Option 42"""
        print_header("SEARCH ANALYSIS BY DATE RANGE")
        
        print_info("Search all JSON artifacts in this investigation for events within a date range")
        print_info("Searches: Browser history, logs, processes, network, and all other timestamped data")
        print()
        
        inv_dir = self.investigations_dir / self.current_investigation.case_id
        output_dir = inv_dir / 'searches'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Date range input
        print(f"{Colors.BOLD}Date Range:{Colors.ENDC}")
        print_info("Supported formats:")
        print_info("  - Date only: 2025-12-30 (assumes 00:00:00 UTC)")
        print_info("  - ISO format: 2025-12-30T15:30:00Z")
        print()
        
        # Start date
        start_date = input(f"{Colors.CYAN}Start date/time (UTC): {Colors.ENDC}").strip()
        if not start_date:
            print_error("Start date required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # End date
        end_date = input(f"{Colors.CYAN}End date/time (UTC): {Colors.ENDC}").strip()
        if not end_date:
            print_error("End date required")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Validate dates
        try:
            # Quick validation by trying to parse
            from datetime import datetime
            if start_date.endswith('Z'):
                datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            elif 'T' in start_date:
                datetime.fromisoformat(start_date)
            else:
                datetime.strptime(start_date, '%Y-%m-%d')
            
            if end_date.endswith('Z'):
                datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            elif 'T' in end_date:
                datetime.fromisoformat(end_date)
            else:
                datetime.strptime(end_date, '%Y-%m-%d')
        
        except Exception as e:
            print_error(f"Invalid date format: {e}")
            print_info("Use YYYY-MM-DD or ISO format (YYYY-MM-DDTHH:MM:SSZ)")
            input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
            return
        
        # Build command
        cmd = [
            './date_range_search.py',
            '-i', str(inv_dir),
            '-s', start_date,
            '-e', end_date,
            '--case-id', self.current_investigation.case_id,
            '-o', str(output_dir)
        ]
        
        print()
        print_section("Running Date Range Search")
        print(f"{Colors.DIM}Investigation: {inv_dir}{Colors.ENDC}")
        print(f"{Colors.DIM}Date Range: {start_date} to {end_date}{Colors.ENDC}")
        print(f"{Colors.DIM}Output: {output_dir}{Colors.ENDC}")
        print()
        
        try:
            # Check if script exists
            if not Path('./date_range_search.py').exists():
                print_error("date_range_search.py not found in current directory")
                print()
                print_info("Installation required:")
                print_info("1. Download date_range_search.py")
                print_info("2. Place in Apple FORENSICS directory")
                print_info("3. chmod +x date_range_search.py")
                print()
                input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
                return
            
            # Run search
            result = subprocess.run(cmd)
            
            if result.returncode == 0:
                print()
                print_success("Date range search completed")
                print_info(f"Results saved to: {output_dir}")
                print()
                
                # List generated files
                json_files = list(output_dir.glob('daterange_search_*.json'))
                md_files = list(output_dir.glob('daterange_search_*.md'))
                
                print_section("Generated Reports")
                if json_files:
                    print(f"{Colors.GREEN}  JSON:{Colors.ENDC} {json_files[0].name}")
                if md_files:
                    print(f"{Colors.GREEN}  MD:{Colors.ENDC}   {md_files[0].name}")
                
                print()
                print_info(f"Review timeline in: {md_files[0].name if md_files else 'Markdown report'}")
                
                # Record search run
                search_info = {
                    'timestamp': datetime.utcnow().isoformat() + 'Z',
                    'tool': 'date_range_search',
                    'version': '1.0',
                    'date_range': {
                        'start': start_date,
                        'end': end_date
                    },
                    'output_directory': str(output_dir)
                }
                
                # Add to investigation metadata
                if not hasattr(self.current_investigation, 'searches'):
                    self.current_investigation.searches = []
                self.current_investigation.searches.append(search_info)
                self.current_investigation.save(inv_dir)
                
                print()
                print_success("Search recorded in investigation metadata")
            else:
                print()
                print_error("Search failed - check error messages above")
        
        except FileNotFoundError as e:
            print_error(f"Error: {e}")
            print_info("Make sure date_range_search.py is executable")
        except Exception as e:
            print_error(f"Unexpected error: {e}")
            import traceback
            traceback.print_exc()
        
        input(f"\n{Colors.BLUE}Press Enter to continue...{Colors.ENDC}")
    
    def exit_dashboard(self):
        """Exit the dashboard"""
        print_header("EXIT APPLE FORENSICS")
        
        if self.current_investigation:
            print(f"{Colors.CYAN}Active investigation: {self.current_investigation.case_id}{Colors.ENDC}")
            
            # Save investigation
            inv_dir = self.investigations_dir / self.current_investigation.case_id
            self.current_investigation.save(inv_dir)
            print_success("Investigation saved")
        
        print(f"\n{Colors.CYAN}Thank you for using Apple FORENSICS!{Colors.ENDC}")
        print(f"{Colors.DIM}Part of Backwater Forensics • Victim Investigator Approach{Colors.ENDC}\n")
    
    def run(self):
        """Start the dashboard"""
        try:
            self.show_banner()
            self.main_menu()
        except KeyboardInterrupt:
            print(f"\n\n{Colors.CYAN}Dashboard interrupted by user{Colors.ENDC}")
            self.exit_dashboard()
        except Exception as e:
            print_error(f"Dashboard error: {e}")
            import traceback
            traceback.print_exc()


def main():
    """Main entry point"""
    dashboard = Dashboard()
    dashboard.run()


if __name__ == "__main__":
    main()
