#!/bin/bash
# Apple FORENSICS - Dependency Installation Script
# Installs required Python libraries for full functionality

echo ""
echo "🔧 Apple FORENSICS - Installing Dependencies"
echo "============================================="
echo ""

# Check Python
echo "Checking Python version..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found"
    echo ""
    echo "Please install Python 3.8+ from:"
    echo "  https://www.python.org/downloads/"
    echo ""
    echo "Or use Homebrew:"
    echo "  brew install python3"
    echo ""
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1)
echo "$PYTHON_VERSION"
echo "✅ Python 3 found"
echo ""

# Check if reportlab is already installed
echo "Checking for existing installations..."
if python3 -c "import reportlab" 2>/dev/null; then
    VERSION=$(python3 -c "import reportlab; print(reportlab.__version__)")
    echo "  ℹ️  reportlab already installed: $VERSION"
    echo ""
    echo "✅ All dependencies already installed!"
    echo ""
    exit 0
fi

echo ""
echo "Installing Python dependencies..."
echo ""

# Try to install reportlab
echo "📦 Installing reportlab (PDF generation)..."
if pip3 install reportlab --break-system-packages &>/dev/null; then
    echo "✅ reportlab installed successfully"
elif pip3 install reportlab &>/dev/null; then
    echo "✅ reportlab installed successfully"
else
    echo "⚠️  Automatic installation failed"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "MANUAL INSTALLATION REQUIRED"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "Please try one of these methods:"
    echo ""
    echo "Method 1 (recommended):"
    echo "  pip3 install reportlab --break-system-packages"
    echo ""
    echo "Method 2:"
    echo "  sudo pip3 install reportlab"
    echo ""
    echo "Method 3:"
    echo "  python3 -m pip install reportlab --break-system-packages"
    echo ""
    echo "After installing, verify with:"
    echo "  python3 -c \"import reportlab; print('OK')\""
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    exit 1
fi

echo ""
echo "Verifying installations..."

# Verify reportlab
if python3 -c "import reportlab" 2>/dev/null; then
    VERSION=$(python3 -c "import reportlab; print(reportlab.__version__)")
    echo "✅ reportlab: $VERSION"
else
    echo "❌ reportlab: Not installed"
    echo ""
    echo "PDF generation will not work without reportlab."
    echo "See manual installation instructions above."
    exit 1
fi

echo ""
echo "============================================="
echo "✅ Dependency Installation Complete!"
echo "============================================="
echo ""
