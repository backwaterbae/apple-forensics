#!/bin/bash
# Apple FORENSICS - Update Script
# For updating existing installations with bug fixes

echo "🔄 Apple FORENSICS - Update Script"
echo "==================================="
echo ""

# Determine installation directory
INSTALL_DIR=~/Desktop/Apple_FORENSICS
if [ ! -d "$INSTALL_DIR" ]; then
    INSTALL_DIR=~/Apple_FORENSICS_Package
fi

if [ ! -d "$INSTALL_DIR" ]; then
    echo "❌ Installation directory not found."
    echo "   Looked in:"
    echo "     • ~/Desktop/Apple_FORENSICS"
    echo "     • ~/Apple_FORENSICS_Package"
    echo ""
    echo "Please specify your installation directory:"
    read -p "Installation path: " INSTALL_DIR
    
    if [ ! -d "$INSTALL_DIR" ]; then
        echo "❌ Directory not found: $INSTALL_DIR"
        exit 1
    fi
fi

echo "📂 Installation found: $INSTALL_DIR"
echo ""

# Create backup
BACKUP_DIR="${INSTALL_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
echo "📦 Creating backup..."
echo "   Location: $BACKUP_DIR"

cp -r "$INSTALL_DIR" "$BACKUP_DIR"
echo "✅ Backup created"
echo ""

# Check for update files
UPDATE_DIR="$PWD"
echo "📥 Looking for update files in: $UPDATE_DIR"
echo ""

# Files to update
declare -A FILES=(
    ["apple_forensics_dashboard.py"]="."
    ["log_directory_analyzer.py"]="tools/log_analyzer"
    ["home_directory_analyzer.py"]="tools/home_analyzer"
    ["network_capture.py"]="tools/network_capture"
    ["system_network_capture.py"]="tools/network_capture"
)

# Track updates
UPDATED_COUNT=0
SKIPPED_COUNT=0

echo "Updating files..."
echo ""

for file in "${!FILES[@]}"; do
    target_dir="${FILES[$file]}"
    
    # Check if update file exists
    if [ -f "$UPDATE_DIR/$file" ]; then
        # Determine full target path
        if [ "$target_dir" = "." ]; then
            target_path="$INSTALL_DIR/$file"
        else
            target_path="$INSTALL_DIR/$target_dir/$file"
        fi
        
        # Create target directory if needed
        mkdir -p "$(dirname "$target_path")"
        
        # Copy file
        cp "$UPDATE_DIR/$file" "$target_path"
        
        # Set executable if .py file
        if [[ "$file" == *.py ]]; then
            chmod +x "$target_path"
        fi
        
        echo "✅ Updated: $file"
        UPDATED_COUNT=$((UPDATED_COUNT + 1))
    else
        echo "⏭️  Skipped: $file (not found in update directory)"
        SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
    fi
done

echo ""

# Check for new dependencies
echo "Checking dependencies..."
if [ -f "$UPDATE_DIR/install_dependencies.sh" ]; then
    echo "📦 New dependency installer found"
    echo ""
    read -p "Install/update dependencies? (y/n): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        bash "$UPDATE_DIR/install_dependencies.sh"
    fi
fi

echo ""
echo "═══════════════════════════════════════════════════════"
echo "✅ Update Complete!"
echo ""
echo "📊 Update Summary:"
echo "   • Files updated: $UPDATED_COUNT"
echo "   • Files skipped: $SKIPPED_COUNT"
echo "   • Backup location: $BACKUP_DIR"
echo ""
echo "🎯 Notes:"
echo "   • Your old files are backed up in case of issues"
echo "   • Run install_dependencies.sh if new features require new libraries"
echo "   • Restart any running tools to use updated versions"
echo ""
echo "📖 See UPDATE_NOTES.md for details on what changed"
echo ""
