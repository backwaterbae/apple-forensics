#!/usr/bin/env python3
"""
Network Indicators Extractor for Apple FORENSICS
Extracts IP addresses, MAC addresses, and network artifacts from log analysis results

Part of the Apple FORENSICS toolkit - Deep Dive Investigation Phase
"""

import sys
import json
import csv
import argparse
import re
from datetime import datetime, timedelta
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Dict, Set, Tuple, Any
import ipaddress

class NetworkIndicatorExtractor:
    """Extract and analyze network indicators from forensic logs"""
    
    # Regex patterns for network indicators
    IPV4_PATTERN = re.compile(
        r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
    )
    
    IPV6_PATTERN = re.compile(
        r'\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|'
        r'\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|'
        r'\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b|'
        r'\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b|'
        r'\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b'
    )
    
    MAC_PATTERN = re.compile(
        r'\b(?:[0-9A-Fa-f]{2}[:-]){5}(?:[0-9A-Fa-f]{2})\b'
    )
    
    # Enhanced patterns for network artifacts
    DOMAIN_PATTERN = re.compile(
        r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b'
    )
    
    URL_PATTERN = re.compile(
        r'https?://(?:[\w\-]+\.)+[\w\-]+(?:/[^\s]*)?'
    )
    
    PORT_PATTERN = re.compile(
        r':(\d{1,5})\b'
    )
    
    # Private/Reserved IP ranges to flag
    PRIVATE_RANGES = [
        ipaddress.ip_network('10.0.0.0/8'),
        ipaddress.ip_network('172.16.0.0/12'),
        ipaddress.ip_network('192.168.0.0/16'),
        ipaddress.ip_network('127.0.0.0/8'),
        ipaddress.ip_network('169.254.0.0/16'),
        ipaddress.ip_network('fc00::/7'),  # IPv6 private
        ipaddress.ip_network('::1/128'),   # IPv6 loopback
    ]
    
    def __init__(self, results_file: Path):
        self.results_file = results_file
        self.findings = []
        
        # Extracted indicators
        self.ipv4_addresses = defaultdict(list)  # IP -> [contexts]
        self.ipv6_addresses = defaultdict(list)
        self.mac_addresses = defaultdict(list)
        self.domains = defaultdict(list)
        self.urls = defaultdict(list)
        self.ports = Counter()
        
        # Metadata
        self.indicator_metadata = {}  # Store severity, timestamp, category per indicator
        
    def load_results(self) -> bool:
        """Load log analysis results"""
        try:
            if self.results_file.suffix == '.json':
                with open(self.results_file, 'r') as f:
                    data = json.load(f)
                    self.findings = data.get('findings', [])
            elif self.results_file.suffix == '.csv':
                with open(self.results_file, 'r') as f:
                    reader = csv.DictReader(f)
                    self.findings = list(reader)
            else:
                print(f"❌ Unsupported format: {self.results_file.suffix}")
                return False
            
            print(f"✅ Loaded {len(self.findings)} findings")
            return len(self.findings) > 0
        except Exception as e:
            print(f"❌ Error loading results: {e}")
            return False
    
    def extract_all_indicators(self, severity_filter: List[str] = None,
                               category_filter: List[str] = None,
                               timeframe: Tuple[datetime, datetime] = None):
        """Extract all network indicators from findings"""
        
        print("\n🔍 Extracting network indicators...")
        
        filtered_findings = self._filter_findings(severity_filter, category_filter, timeframe)
        
        print(f"📊 Analyzing {len(filtered_findings)} findings...")
        
        for finding in filtered_findings:
            context = finding.get('context', '')
            severity = finding.get('severity', 'UNKNOWN')
            category = finding.get('category', 'UNKNOWN')
            timestamp = finding.get('timestamp', '')
            log_file = finding.get('log_file', '')
            
            # Extract all indicator types
            self._extract_ipv4(context, severity, category, timestamp, log_file)
            self._extract_ipv6(context, severity, category, timestamp, log_file)
            self._extract_mac(context, severity, category, timestamp, log_file)
            self._extract_domains(context, severity, category, timestamp, log_file)
            self._extract_urls(context, severity, category, timestamp, log_file)
            self._extract_ports(context)
        
        self._print_extraction_summary()
    
    def _filter_findings(self, severity_filter, category_filter, timeframe):
        """Filter findings based on criteria"""
        
        filtered = self.findings
        
        if severity_filter:
            filtered = [f for f in filtered 
                       if f.get('severity', '').upper() in [s.upper() for s in severity_filter]]
            print(f"  📌 Filtered to {len(filtered)} findings by severity: {severity_filter}")
        
        if category_filter:
            filtered = [f for f in filtered 
                       if f.get('category', '') in category_filter]
            print(f"  📌 Filtered to {len(filtered)} findings by category: {category_filter}")
        
        if timeframe:
            start, end = timeframe
            filtered = [f for f in filtered 
                       if self._in_timeframe(f.get('timestamp', ''), start, end)]
            print(f"  📌 Filtered to {len(filtered)} findings in timeframe")
        
        return filtered
    
    def _in_timeframe(self, timestamp_str: str, start: datetime, end: datetime) -> bool:
        """Check if timestamp is within timeframe"""
        try:
            ts = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
            return start <= ts <= end
        except:
            return False
    
    def _extract_ipv4(self, text: str, severity: str, category: str, timestamp: str, source: str):
        """Extract IPv4 addresses"""
        matches = self.IPV4_PATTERN.findall(text)
        for ip in matches:
            # Store context
            context_snippet = self._get_context_snippet(text, ip)
            self.ipv4_addresses[ip].append({
                'context': context_snippet,
                'severity': severity,
                'category': category,
                'timestamp': timestamp,
                'source': source
            })
    
    def _extract_ipv6(self, text: str, severity: str, category: str, timestamp: str, source: str):
        """Extract IPv6 addresses"""
        matches = self.IPV6_PATTERN.findall(text)
        for ip in matches:
            context_snippet = self._get_context_snippet(text, ip)
            self.ipv6_addresses[ip].append({
                'context': context_snippet,
                'severity': severity,
                'category': category,
                'timestamp': timestamp,
                'source': source
            })
    
    def _extract_mac(self, text: str, severity: str, category: str, timestamp: str, source: str):
        """Extract MAC addresses"""
        matches = self.MAC_PATTERN.findall(text)
        for mac in matches:
            # Normalize MAC format
            mac_normalized = mac.upper().replace('-', ':')
            context_snippet = self._get_context_snippet(text, mac)
            self.mac_addresses[mac_normalized].append({
                'context': context_snippet,
                'severity': severity,
                'category': category,
                'timestamp': timestamp,
                'source': source
            })
    
    def _extract_domains(self, text: str, severity: str, category: str, timestamp: str, source: str):
        """Extract domain names"""
        matches = self.DOMAIN_PATTERN.findall(text)
        for domain in matches:
            # Filter out common false positives
            if self._is_valid_domain(domain):
                context_snippet = self._get_context_snippet(text, domain)
                self.domains[domain.lower()].append({
                    'context': context_snippet,
                    'severity': severity,
                    'category': category,
                    'timestamp': timestamp,
                    'source': source
                })
    
    def _extract_urls(self, text: str, severity: str, category: str, timestamp: str, source: str):
        """Extract URLs"""
        matches = self.URL_PATTERN.findall(text)
        for url in matches:
            context_snippet = self._get_context_snippet(text, url)
            self.urls[url].append({
                'context': context_snippet,
                'severity': severity,
                'category': category,
                'timestamp': timestamp,
                'source': source
            })
    
    def _extract_ports(self, text: str):
        """Extract port numbers"""
        matches = self.PORT_PATTERN.findall(text)
        for port in matches:
            port_num = int(port)
            if 1 <= port_num <= 65535:  # Valid port range
                self.ports[port_num] += 1
    
    def _get_context_snippet(self, text: str, indicator: str, window: int = 50) -> str:
        """Get context around an indicator"""
        try:
            pos = text.find(indicator)
            if pos == -1:
                return text[:100]
            start = max(0, pos - window)
            end = min(len(text), pos + len(indicator) + window)
            return text[start:end]
        except:
            return text[:100]
    
    def _is_valid_domain(self, domain: str) -> bool:
        """Filter out false positive domains"""
        # Skip very short or suspicious patterns
        if len(domain) < 4:
            return False
        
        # Skip common file extensions
        extensions = ['.txt', '.log', '.py', '.sh', '.md', '.json', '.csv']
        if any(domain.endswith(ext) for ext in extensions):
            return False
        
        # Skip localhost-like patterns
        if domain.startswith('localhost'):
            return False
        
        return True
    
    def _print_extraction_summary(self):
        """Print summary of extraction"""
        print("\n📊 Extraction Summary:")
        print(f"  • IPv4 addresses: {len(self.ipv4_addresses)}")
        print(f"  • IPv6 addresses: {len(self.ipv6_addresses)}")
        print(f"  • MAC addresses: {len(self.mac_addresses)}")
        print(f"  • Domains: {len(self.domains)}")
        print(f"  • URLs: {len(self.urls)}")
        print(f"  • Unique ports: {len(self.ports)}")
    
    def classify_ip(self, ip_str: str) -> Dict[str, Any]:
        """Classify an IP address (private, public, special use)"""
        try:
            ip = ipaddress.ip_address(ip_str)
            
            classification = {
                'ip': ip_str,
                'version': f'IPv{ip.version}',
                'private': ip.is_private,
                'loopback': ip.is_loopback,
                'multicast': ip.is_multicast,
                'link_local': ip.is_link_local,
                'reserved': ip.is_reserved,
                'public': not (ip.is_private or ip.is_loopback or ip.is_reserved),
                'priority': 'LOW'  # Default
            }
            
            # Determine priority for investigation
            if classification['public']:
                classification['priority'] = 'HIGH'  # Public IPs are interesting
            elif classification['private']:
                classification['priority'] = 'MEDIUM'  # Private IPs may indicate lateral movement
            else:
                classification['priority'] = 'LOW'  # Loopback, multicast, etc.
            
            return classification
        except:
            return {'ip': ip_str, 'version': 'INVALID', 'priority': 'LOW'}
    
    def get_oui_vendor(self, mac: str) -> str:
        """Get vendor from MAC OUI (first 3 octets)"""
        # Simplified - in production, use OUI database
        oui = mac[:8]  # First 3 octets (XX:XX:XX)
        
        # Common Apple OUIs
        apple_ouis = ['00:03:93', '00:05:02', '00:0A:27', '00:0A:95', '00:0D:93',
                     '00:10:FA', '00:11:24', '00:13:E3', '00:14:51', '00:16:CB',
                     '00:17:F2', '00:19:E3', '00:1B:63', '00:1C:B3', '00:1D:4F']
        
        if oui.upper() in apple_ouis:
            return 'Apple Inc.'
        
        return 'Unknown'
    
    def prioritize_indicators(self) -> Dict[str, List[Tuple[str, int, str]]]:
        """Prioritize indicators based on frequency and severity"""
        
        prioritized = {
            'high_priority_ips': [],
            'suspicious_ips': [],
            'common_ips': [],
            'suspicious_macs': [],
            'suspicious_domains': [],
            'suspicious_urls': []
        }
        
        # Prioritize IPv4 addresses
        for ip, contexts in self.ipv4_addresses.items():
            classification = self.classify_ip(ip)
            occurrences = len(contexts)
            high_severity_count = sum(1 for c in contexts if c['severity'] == 'HIGH')
            
            priority_score = 0
            reason = []
            
            if classification['public']:
                priority_score += 10
                reason.append("public IP")
            
            if high_severity_count > 0:
                priority_score += high_severity_count * 5
                reason.append(f"{high_severity_count} HIGH severity")
            
            if occurrences > 3:
                priority_score += 3
                reason.append(f"{occurrences} occurrences")
            
            if priority_score >= 10:
                prioritized['high_priority_ips'].append((ip, priority_score, ', '.join(reason)))
            elif priority_score >= 5:
                prioritized['suspicious_ips'].append((ip, priority_score, ', '.join(reason)))
            else:
                prioritized['common_ips'].append((ip, priority_score, ', '.join(reason)))
        
        # Sort by priority score
        for key in ['high_priority_ips', 'suspicious_ips', 'common_ips']:
            prioritized[key].sort(key=lambda x: x[1], reverse=True)
        
        # Prioritize MACs based on frequency and severity
        for mac, contexts in self.mac_addresses.items():
            occurrences = len(contexts)
            high_severity_count = sum(1 for c in contexts if c['severity'] == 'HIGH')
            
            if high_severity_count > 0 or occurrences > 2:
                vendor = self.get_oui_vendor(mac)
                reason = f"{occurrences} occurrences, {high_severity_count} HIGH severity, vendor: {vendor}"
                prioritized['suspicious_macs'].append((mac, occurrences, reason))
        
        prioritized['suspicious_macs'].sort(key=lambda x: x[1], reverse=True)
        
        # Prioritize domains (public domains in high severity contexts)
        for domain, contexts in self.domains.items():
            high_severity_count = sum(1 for c in contexts if c['severity'] == 'HIGH')
            occurrences = len(contexts)
            
            if high_severity_count > 0:
                reason = f"{occurrences} occurrences, {high_severity_count} HIGH severity"
                prioritized['suspicious_domains'].append((domain, occurrences, reason))
        
        prioritized['suspicious_domains'].sort(key=lambda x: x[1], reverse=True)
        
        # Prioritize URLs
        for url, contexts in self.urls.items():
            high_severity_count = sum(1 for c in contexts if c['severity'] == 'HIGH')
            if high_severity_count > 0:
                prioritized['suspicious_urls'].append((url, len(contexts), f"{high_severity_count} HIGH severity"))
        
        return prioritized
    
    def generate_report(self, output_format: str = 'markdown') -> str:
        """Generate network indicators report"""
        
        if output_format == 'markdown':
            return self._generate_markdown_report()
        elif output_format == 'json':
            return self._generate_json_report()
        elif output_format == 'csv':
            return self._generate_csv_report()
        else:
            return "Unsupported format"
    
    def _generate_markdown_report(self) -> str:
        """Generate markdown report"""
        
        report = "# Network Indicators Analysis Report\n\n"
        report += f"**Analysis Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"**Source:** {self.results_file.name}\n\n"
        report += "---\n\n"
        
        # Get prioritized indicators
        prioritized = self.prioritize_indicators()
        
        # Executive Summary
        report += "## 🎯 Executive Summary\n\n"
        report += f"- **High Priority IPs:** {len(prioritized['high_priority_ips'])}\n"
        report += f"- **Suspicious IPs:** {len(prioritized['suspicious_ips'])}\n"
        report += f"- **Common IPs:** {len(prioritized['common_ips'])}\n"
        report += f"- **Suspicious MACs:** {len(prioritized['suspicious_macs'])}\n"
        report += f"- **Suspicious Domains:** {len(prioritized['suspicious_domains'])}\n"
        report += f"- **Suspicious URLs:** {len(prioritized['suspicious_urls'])}\n\n"
        
        # High Priority IPs
        if prioritized['high_priority_ips']:
            report += "## 🚨 High Priority IP Addresses\n\n"
            report += "These IPs require immediate investigation:\n\n"
            
            for ip, score, reason in prioritized['high_priority_ips'][:20]:  # Top 20
                classification = self.classify_ip(ip)
                contexts = self.ipv4_addresses.get(ip, []) or self.ipv6_addresses.get(ip, [])
                
                report += f"### {ip}\n"
                report += f"- **Priority Score:** {score}\n"
                report += f"- **Reason:** {reason}\n"
                report += f"- **Type:** {classification['version']}, "
                report += f"{'Public' if classification['public'] else 'Private'}\n"
                report += f"- **Occurrences:** {len(contexts)}\n"
                
                # Show contexts
                report += "- **Contexts:**\n"
                for ctx in contexts[:3]:  # First 3 contexts
                    report += f"  - [{ctx['severity']}] {ctx['category']}: `{ctx['context'][:80]}...`\n"
                
                report += "\n"
        
        # Suspicious IPs
        if prioritized['suspicious_ips']:
            report += "## ⚠️ Suspicious IP Addresses\n\n"
            for ip, score, reason in prioritized['suspicious_ips'][:10]:
                report += f"- **{ip}** (Score: {score}) - {reason}\n"
            report += "\n"
        
        # Suspicious MACs
        if prioritized['suspicious_macs']:
            report += "## 🔧 Suspicious MAC Addresses\n\n"
            for mac, count, reason in prioritized['suspicious_macs'][:10]:
                vendor = self.get_oui_vendor(mac)
                report += f"- **{mac}** (Vendor: {vendor}) - {reason}\n"
            report += "\n"
        
        # Suspicious Domains
        if prioritized['suspicious_domains']:
            report += "## 🌐 Suspicious Domains\n\n"
            for domain, count, reason in prioritized['suspicious_domains'][:15]:
                report += f"- **{domain}** - {reason}\n"
            report += "\n"
        
        # Suspicious URLs
        if prioritized['suspicious_urls']:
            report += "## 🔗 Suspicious URLs\n\n"
            for url, count, reason in prioritized['suspicious_urls'][:10]:
                report += f"- `{url}` - {reason}\n"
            report += "\n"
        
        # Port Analysis
        if self.ports:
            report += "## 🔌 Port Analysis\n\n"
            report += "Most frequently observed ports:\n\n"
            for port, count in self.ports.most_common(15):
                port_name = self._get_port_service(port)
                report += f"- **Port {port}** ({port_name}): {count} occurrences\n"
            report += "\n"
        
        # All IPs Reference
        report += "## 📊 Complete IP Address List\n\n"
        all_ips = list(self.ipv4_addresses.keys()) + list(self.ipv6_addresses.keys())
        report += f"Total unique IPs: {len(all_ips)}\n\n"
        
        for ip in sorted(all_ips)[:50]:  # First 50
            classification = self.classify_ip(ip)
            contexts = self.ipv4_addresses.get(ip, []) or self.ipv6_addresses.get(ip, [])
            report += f"- `{ip}` ({classification['version']}, "
            report += f"{'Public' if classification['public'] else 'Private'}) - {len(contexts)} occurrences\n"
        
        return report
    
    def _generate_json_report(self) -> str:
        """Generate JSON report"""
        
        prioritized = self.prioritize_indicators()
        
        data = {
            'analysis_date': datetime.now().isoformat(),
            'source_file': str(self.results_file),
            'summary': {
                'ipv4_count': len(self.ipv4_addresses),
                'ipv6_count': len(self.ipv6_addresses),
                'mac_count': len(self.mac_addresses),
                'domain_count': len(self.domains),
                'url_count': len(self.urls),
                'port_count': len(self.ports)
            },
            'prioritized_indicators': prioritized,
            'all_ipv4': {ip: len(contexts) for ip, contexts in self.ipv4_addresses.items()},
            'all_ipv6': {ip: len(contexts) for ip, contexts in self.ipv6_addresses.items()},
            'all_macs': {mac: len(contexts) for mac, contexts in self.mac_addresses.items()},
            'all_domains': {domain: len(contexts) for domain, contexts in self.domains.items()},
            'top_ports': [{'port': p, 'count': c, 'service': self._get_port_service(p)} 
                         for p, c in self.ports.most_common(20)]
        }
        
        return json.dumps(data, indent=2)
    
    def _generate_csv_report(self) -> str:
        """Generate CSV report of high-priority indicators"""
        
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Header
        writer.writerow(['Type', 'Indicator', 'Priority', 'Occurrences', 'Reason', 'First_Seen'])
        
        prioritized = self.prioritize_indicators()
        
        # High priority IPs
        for ip, score, reason in prioritized['high_priority_ips']:
            contexts = self.ipv4_addresses.get(ip, []) or self.ipv6_addresses.get(ip, [])
            first_seen = contexts[0]['timestamp'] if contexts else 'N/A'
            writer.writerow(['IPv4', ip, score, len(contexts), reason, first_seen])
        
        # Suspicious MACs
        for mac, count, reason in prioritized['suspicious_macs']:
            contexts = self.mac_addresses[mac]
            first_seen = contexts[0]['timestamp'] if contexts else 'N/A'
            writer.writerow(['MAC', mac, 'HIGH', count, reason, first_seen])
        
        # Suspicious domains
        for domain, count, reason in prioritized['suspicious_domains']:
            contexts = self.domains[domain]
            first_seen = contexts[0]['timestamp'] if contexts else 'N/A'
            writer.writerow(['Domain', domain, 'HIGH', count, reason, first_seen])
        
        return output.getvalue()
    
    def _get_port_service(self, port: int) -> str:
        """Get common service name for port"""
        
        common_ports = {
            20: 'FTP-DATA', 21: 'FTP', 22: 'SSH', 23: 'Telnet',
            25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3',
            143: 'IMAP', 443: 'HTTPS', 445: 'SMB', 3389: 'RDP',
            5900: 'VNC', 8080: 'HTTP-ALT', 8443: 'HTTPS-ALT',
            9050: 'Tor', 9051: 'Tor-Control'
        }
        
        return common_ports.get(port, 'Unknown')


def main():
    parser = argparse.ArgumentParser(
        description='Extract network indicators from log analysis results',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract all network indicators
  %(prog)s -r log_analysis.json
  
  # Only HIGH severity findings
  %(prog)s -r log_analysis.json --severity HIGH
  
  # Specific category (Security, Malware, etc.)
  %(prog)s -r log_analysis.json --category Security Malware
  
  # Specific timeframe
  %(prog)s -r log_analysis.json --start "2023-12-19 15:00:00" --end "2023-12-19 16:00:00"
  
  # Output as JSON for automation
  %(prog)s -r log_analysis.json --format json
  
  # Save to specific location
  %(prog)s -r log_analysis.json -o /cases/pavel/network_indicators.md
        """
    )
    
    parser.add_argument('-r', '--results', required=True, type=Path,
                       help='Log analysis results file (JSON or CSV)')
    parser.add_argument('--severity', nargs='+', choices=['HIGH', 'MEDIUM', 'LOW'],
                       help='Filter by severity level(s)')
    parser.add_argument('--category', nargs='+',
                       help='Filter by category (Security, Malware, etc.)')
    parser.add_argument('--start', type=str,
                       help='Start time (YYYY-MM-DD HH:MM:SS)')
    parser.add_argument('--end', type=str,
                       help='End time (YYYY-MM-DD HH:MM:SS)')
    parser.add_argument('--format', choices=['markdown', 'json', 'csv'], default='markdown',
                       help='Output format (default: markdown)')
    parser.add_argument('-o', '--output', type=Path,
                       help='Output file (default: network_indicators_TIMESTAMP.md)')
    
    args = parser.parse_args()
    
    # Parse timeframe if provided
    timeframe = None
    if args.start and args.end:
        try:
            start = datetime.strptime(args.start, '%Y-%m-%d %H:%M:%S')
            end = datetime.strptime(args.end, '%Y-%m-%d %H:%M:%S')
            timeframe = (start, end)
        except ValueError as e:
            print(f"❌ Invalid datetime format: {e}")
            return 1
    
    # Initialize extractor
    extractor = NetworkIndicatorExtractor(args.results)
    
    if not extractor.load_results():
        return 1
    
    # Extract indicators
    extractor.extract_all_indicators(
        severity_filter=args.severity,
        category_filter=args.category,
        timeframe=timeframe
    )
    
    # Generate report
    print("\n📝 Generating report...")
    report = extractor.generate_report(args.format)
    
    # Determine output file
    if args.output:
        output_file = args.output
    else:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        ext = 'md' if args.format == 'markdown' else args.format
        output_file = Path(f'network_indicators_{timestamp}.{ext}')
    
    # Write output
    with open(output_file, 'w') as f:
        f.write(report)
    
    print(f"✅ Network indicators report saved to: {output_file}")
    
    return 0


if __name__ == '__main__':
    try:
        exit(main())
    except Exception as e:
        print(f"❌ FATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        exit(1)
