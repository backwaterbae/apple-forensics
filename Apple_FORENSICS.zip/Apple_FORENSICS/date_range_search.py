#!/usr/bin/env python3
"""
Date Range Search - Investigation Timeline Query
=================================================
Search all JSON artifacts within an investigation for events/findings within a specific date range.

Searches across:
- Browser histories (Chrome, Safari, Firefox, Brave)
- Log analyses
- Process snapshots
- Network captures
- Home directory scans
- Any other JSON artifacts with timestamps

Part of: Backwater Forensics • Apple FORENSICS • Victim Investigator Approach
Phase: 3 Final
Version: 1.0
"""

import sys
import os
import json
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Optional, Any
from collections import defaultdict
import re


# Terminal colors
class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    ORANGE = '\033[38;5;208m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'


class DateRangeSearch:
    """Search investigation artifacts by date range"""
    
    def __init__(self, investigation_dir: str, start_date: str, end_date: str, case_id: str = "UNKNOWN"):
        """
        Initialize date range search
        
        Args:
            investigation_dir: Path to investigation directory
            start_date: Start date/time in ISO format (UTC)
            end_date: End date/time in ISO format (UTC)
            case_id: Case ID for tracking
        """
        self.investigation_dir = Path(investigation_dir)
        self.case_id = case_id
        self.start_date = self._parse_datetime(start_date)
        self.end_date = self._parse_datetime(end_date)
        self.analysis_timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # Results storage
        self.results = []
        self.source_files = []
        
        # Statistics
        self.stats = {
            'files_scanned': 0,
            'events_found': 0,
            'sources': defaultdict(int)
        }
    
    def _parse_datetime(self, dt_string: str) -> datetime:
        """
        Parse datetime string to datetime object
        
        Supports formats:
        - ISO: 2025-12-30T15:30:00Z
        - ISO without Z: 2025-12-30T15:30:00
        - Date only: 2025-12-30 (assumes 00:00:00)
        """
        dt_string = dt_string.strip()
        
        # Try ISO format with Z
        if dt_string.endswith('Z'):
            return datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
        
        # Try ISO format without timezone
        try:
            dt = datetime.fromisoformat(dt_string)
            # If no timezone, assume UTC
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            pass
        
        # Try date only (YYYY-MM-DD)
        try:
            dt = datetime.strptime(dt_string, '%Y-%m-%d')
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
        
        raise ValueError(f"Could not parse datetime: {dt_string}")
    
    def _is_in_range(self, timestamp_str: Optional[str]) -> bool:
        """Check if timestamp is within date range"""
        if not timestamp_str:
            return False
        
        try:
            # Handle various timestamp formats
            ts_str = timestamp_str.strip()
            
            # Parse timestamp
            if ts_str.endswith('Z'):
                ts = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
            else:
                ts = datetime.fromisoformat(ts_str)
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
            
            # Check range
            return self.start_date <= ts <= self.end_date
        
        except Exception:
            return False
    
    def _extract_timestamp_field(self, obj: Any, depth: int = 0, max_depth: int = 5) -> Optional[str]:
        """
        Recursively find timestamp fields in object
        
        Looks for common timestamp field names:
        - timestamp, timestamp_utc, analysis_timestamp_utc
        - last_visit_time, download_time, event_time
        - time, datetime, date
        """
        if depth > max_depth or obj is None:
            return None
        
        timestamp_fields = [
            'timestamp_utc', 'timestamp', 'analysis_timestamp_utc',
            'last_visit_time', 'download_time', 'event_time',
            'time', 'datetime', 'date', 'created', 'modified',
            'last_used', 'first_used'
        ]
        
        if isinstance(obj, dict):
            # Check for timestamp fields
            for field in timestamp_fields:
                if field in obj and isinstance(obj[field], str):
                    return obj[field]
            
            # Recurse into nested objects
            for value in obj.values():
                ts = self._extract_timestamp_field(value, depth + 1, max_depth)
                if ts:
                    return ts
        
        return None
    
    def _search_json_file(self, json_file: Path):
        """Search a single JSON file for events in date range"""
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            self.stats['files_scanned'] += 1
            self.source_files.append(str(json_file))
            
            # Determine source type from filename
            source_type = self._identify_source_type(json_file.name)
            
            # Search different data structures
            events = []
            
            # Browser history format
            if 'findings' in data:
                events.extend(self._extract_from_list(data['findings'], source_type, json_file))
            
            if 'all_urls' in data:
                events.extend(self._extract_from_list(data['all_urls'], source_type, json_file))
            
            if 'downloads' in data:
                events.extend(self._extract_from_list(data['downloads'], source_type, json_file))
            
            if 'search_queries' in data:
                events.extend(self._extract_from_list(data['search_queries'], source_type, json_file))
            
            # Timeline format
            if 'timeline' in data and isinstance(data['timeline'], dict):
                if 'events' in data['timeline']:
                    events.extend(self._extract_from_list(data['timeline']['events'], source_type, json_file))
            
            # Generic findings/results list
            if 'results' in data:
                events.extend(self._extract_from_list(data['results'], source_type, json_file))
            
            # Process snapshot format
            if 'processes' in data:
                events.extend(self._extract_from_list(data['processes'], source_type, json_file))
            
            # Network capture format
            if 'connections' in data:
                events.extend(self._extract_from_list(data['connections'], source_type, json_file))
            
            # Add events to results
            self.results.extend(events)
            
        except Exception as e:
            print(f"{Colors.YELLOW}Warning: Could not parse {json_file.name}: {e}{Colors.ENDC}")
    
    def _identify_source_type(self, filename: str) -> str:
        """Identify source type from filename"""
        if 'chrome_history' in filename:
            return 'Chrome Browser'
        elif 'safari_history' in filename:
            return 'Safari Browser'
        elif 'firefox_history' in filename:
            return 'Firefox Browser'
        elif 'brave_history' in filename:
            return 'Brave Browser'
        elif 'log_analysis' in filename:
            return 'Log Analysis'
        elif 'process_memory' in filename or 'process_snapshot' in filename:
            return 'Process Snapshot'
        elif 'network_capture' in filename:
            return 'Network Capture'
        elif 'home_analysis' in filename:
            return 'Home Directory'
        elif 'system_state' in filename:
            return 'System State'
        else:
            return 'Unknown Source'
    
    def _extract_from_list(self, items: List[Dict], source_type: str, source_file: Path) -> List[Dict]:
        """Extract events from a list of items"""
        events = []
        
        for item in items:
            if not isinstance(item, dict):
                continue
            
            # Find timestamp
            timestamp = self._extract_timestamp_field(item)
            
            if timestamp and self._is_in_range(timestamp):
                event = {
                    'timestamp_utc': timestamp,
                    'source_type': source_type,
                    'source_file': source_file.name,
                    'data': item
                }
                events.append(event)
                self.stats['events_found'] += 1
                self.stats['sources'][source_type] += 1
        
        return events
    
    def search(self):
        """Search all JSON files in investigation directory"""
        print(f"\n{Colors.CYAN}{'=' * 70}{Colors.ENDC}")
        print(f"{Colors.CYAN}{Colors.BOLD}{'Date Range Search'.center(70)}{Colors.ENDC}")
        print(f"{Colors.CYAN}{'=' * 70}{Colors.ENDC}\n")
        
        print(f"{Colors.BOLD}Investigation:{Colors.ENDC} {self.investigation_dir}")
        print(f"{Colors.BOLD}Date Range:{Colors.ENDC} {self.start_date.isoformat()} to {self.end_date.isoformat()}")
        print()
        
        # Find all JSON files in artifacts directory
        artifacts_dir = self.investigation_dir / 'artifacts'
        
        if not artifacts_dir.exists():
            print(f"{Colors.RED}Error: Artifacts directory not found: {artifacts_dir}{Colors.ENDC}")
            return
        
        # Recursively find all JSON files
        json_files = list(artifacts_dir.rglob('*.json'))
        
        if not json_files:
            print(f"{Colors.YELLOW}Warning: No JSON files found in {artifacts_dir}{Colors.ENDC}")
            return
        
        print(f"{Colors.CYAN}Searching {len(json_files)} JSON files...{Colors.ENDC}\n")
        
        # Search each file
        for json_file in json_files:
            self._search_json_file(json_file)
        
        # Sort results by timestamp
        self.results.sort(key=lambda x: x['timestamp_utc'])
        
        # Print summary
        print(f"{Colors.BOLD}Search Complete:{Colors.ENDC}")
        print(f"  Files scanned: {self.stats['files_scanned']}")
        print(f"  Events found: {self.stats['events_found']}")
        print()
        
        if self.stats['sources']:
            print(f"{Colors.BOLD}Events by Source:{Colors.ENDC}")
            for source, count in sorted(self.stats['sources'].items(), key=lambda x: x[1], reverse=True):
                print(f"  {source}: {count}")
    
    def save_json(self, output_dir: Path):
        """Save results as JSON"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'daterange_search_{self.case_id}_{timestamp}.json'
        output_file = output_dir / filename
        
        output_data = {
            'search_metadata': {
                'tool': 'date_range_search',
                'version': '1.0',
                'search_timestamp_utc': self.analysis_timestamp,
                'case_id': self.case_id,
                'investigation_dir': str(self.investigation_dir),
                'date_range': {
                    'start': self.start_date.isoformat(),
                    'end': self.end_date.isoformat()
                }
            },
            'statistics': {
                'files_scanned': self.stats['files_scanned'],
                'events_found': self.stats['events_found'],
                'sources': dict(self.stats['sources'])
            },
            'source_files': self.source_files,
            'results': self.results
        }
        
        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2)
        
        print(f"\n{Colors.GREEN}✓ JSON saved: {output_file}{Colors.ENDC}")
        return output_file
    
    def save_markdown(self, output_dir: Path):
        """Save results as Markdown report"""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f'daterange_search_{self.case_id}_{timestamp}.md'
        output_file = output_dir / filename
        
        with open(output_file, 'w') as f:
            # Header
            f.write(f"# Date Range Search Report\n\n")
            f.write(f"**Case ID:** {self.case_id}  \n")
            f.write(f"**Search Timestamp:** {self.analysis_timestamp}  \n")
            f.write(f"**Investigation:** {self.investigation_dir}  \n")
            f.write(f"**Date Range:** {self.start_date.isoformat()} to {self.end_date.isoformat()}  \n\n")
            
            f.write("---\n\n")
            
            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Files Scanned:** {self.stats['files_scanned']}\n")
            f.write(f"- **Events Found:** {self.stats['events_found']}\n\n")
            
            if self.stats['sources']:
                f.write("**Events by Source:**\n")
                for source, count in sorted(self.stats['sources'].items(), key=lambda x: x[1], reverse=True):
                    f.write(f"- {source}: {count}\n")
                f.write("\n")
            
            f.write("---\n\n")
            
            # Events organized by source type
            if self.results:
                # Group by source type
                by_source = defaultdict(list)
                for result in self.results:
                    by_source[result['source_type']].append(result)
                
                for source_type, events in sorted(by_source.items()):
                    f.write(f"## {source_type} ({len(events)} events)\n\n")
                    
                    for event in events:
                        f.write(f"### {event['timestamp_utc']}\n\n")
                        f.write(f"**Source File:** {event['source_file']}  \n\n")
                        
                        # Display relevant fields from data
                        data = event['data']
                        
                        # URLs
                        if 'url' in data:
                            f.write(f"**URL:** {data['url']}  \n")
                        if 'title' in data and data['title']:
                            f.write(f"**Title:** {data['title']}  \n")
                        
                        # Process info
                        if 'name' in data:
                            f.write(f"**Name:** {data['name']}  \n")
                        if 'pid' in data:
                            f.write(f"**PID:** {data['pid']}  \n")
                        
                        # Log info
                        if 'severity' in data:
                            f.write(f"**Severity:** {data['severity']}  \n")
                        if 'category' in data:
                            f.write(f"**Category:** {data['category']}  \n")
                        if 'pattern' in data:
                            f.write(f"**Pattern:** {data['pattern']}  \n")
                        if 'context' in data:
                            f.write(f"**Context:** {data['context']}  \n")
                        
                        # Generic fields
                        if 'reason' in data:
                            f.write(f"**Reason:** {data['reason']}  \n")
                        if 'details' in data and isinstance(data['details'], dict):
                            f.write(f"**Details:**\n")
                            for key, value in data['details'].items():
                                f.write(f"  - {key}: {value}\n")
                        
                        f.write("\n")
                    
                    f.write("---\n\n")
            
            else:
                f.write("## No Events Found\n\n")
                f.write("No events were found in the specified date range.\n\n")
            
            f.write("*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*\n")
        
        print(f"{Colors.GREEN}✓ Markdown saved: {output_file}{Colors.ENDC}")
        return output_file


def main():
    parser = argparse.ArgumentParser(
        description='Date Range Search - Query investigation artifacts by timestamp',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Search for events on a specific date
  %(prog)s -i Investigations/CASE-001 -s 2025-12-30 -e 2025-12-30
  
  # Search for events in a specific time window
  %(prog)s -i Investigations/CASE-001 -s "2025-12-30T14:00:00Z" -e "2025-12-30T16:00:00Z"
  
  # Search with case ID and output directory
  %(prog)s -i Investigations/CASE-001 -s 2025-12-30 -e 2025-12-31 --case-id CASE-001 -o /evidence/

Date formats supported:
  - ISO with timezone: 2025-12-30T15:30:00Z
  - ISO without timezone: 2025-12-30T15:30:00 (assumes UTC)
  - Date only: 2025-12-30 (assumes 00:00:00 UTC)

Part of: Apple FORENSICS • Backwater Forensics
        """
    )
    
    parser.add_argument('-i', '--investigation', required=True, help='Investigation directory path')
    parser.add_argument('-s', '--start', required=True, help='Start date/time (UTC, ISO format or YYYY-MM-DD)')
    parser.add_argument('-e', '--end', required=True, help='End date/time (UTC, ISO format or YYYY-MM-DD)')
    parser.add_argument('--case-id', default='UNKNOWN', help='Case ID for tracking')
    parser.add_argument('-o', '--output', default='.', help='Output directory (default: current)')
    
    args = parser.parse_args()
    
    try:
        # Initialize searcher
        searcher = DateRangeSearch(
            investigation_dir=args.investigation,
            start_date=args.start,
            end_date=args.end,
            case_id=args.case_id
        )
        
        # Run search
        searcher.search()
        
        # Save results
        output_dir = Path(args.output).expanduser()
        output_dir.mkdir(parents=True, exist_ok=True)
        
        searcher.save_json(output_dir)
        searcher.save_markdown(output_dir)
        
        print(f"\n{Colors.GREEN}✓ Search complete!{Colors.ENDC}\n")
        
        return 0
    
    except Exception as e:
        print(f"{Colors.RED}Error: {e}{Colors.ENDC}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
