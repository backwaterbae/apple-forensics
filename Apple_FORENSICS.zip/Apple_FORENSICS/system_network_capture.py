#!/usr/bin/env python3
"""
System Triage + Network Capture Tool
Captures complete system state (all processes) + network activity simultaneously

Perfect for:
- Incident response - what was running during the event?
- Malware investigation - what else started during infection?
- Performance analysis - system-wide changes over time
- Pre-spindump triage - complete system state before crash

Usage:
    sudo ./system_network_capture.py [duration] [interface]
    
Examples:
    sudo ./system_network_capture.py              # 60s capture, en0
    sudo ./system_network_capture.py 30           # 30s capture, en0
    sudo ./system_network_capture.py 60 en0       # 60s on en0
"""

import psutil
import subprocess
import threading
import time
import json
import csv
import datetime
import sys
import os
import hashlib

def get_process_info(proc):
    """Get top-level process information for triage"""
    try:
        info = proc.as_dict(attrs=[
            'pid', 'name', 'username', 'status', 
            'create_time', 'exe', 'cmdline'
        ])
        
        mem_info = proc.memory_info()
        info['memory_rss_mb'] = round(mem_info.rss / 1024 / 1024, 2)
        info['memory_vms_mb'] = round(mem_info.vms / 1024 / 1024, 2)
        info['memory_percent'] = round(proc.memory_percent(), 2)
        
        info['cpu_percent'] = proc.cpu_percent(interval=0)
        info['num_threads'] = proc.num_threads()
        
        try:
            info['num_connections'] = len(proc.connections())
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            info['num_connections'] = -1
        
        try:
            info['num_files'] = len(proc.open_files())
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            info['num_files'] = -1
        
        try:
            info['ppid'] = proc.ppid()
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            info['ppid'] = 0
        
        if info['cmdline']:
            info['cmdline_short'] = ' '.join(info['cmdline'])[:100]
        else:
            info['cmdline_short'] = ''
        
        if info['create_time']:
            info['create_time_utc'] = datetime.datetime.utcfromtimestamp(
                info['create_time']
            ).isoformat() + 'Z'
        else:
            info['create_time_utc'] = ''
        
        return info
        
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return None

def capture_all_processes():
    """Capture all running processes (quick triage snapshot)"""
    processes = []
    for proc in psutil.process_iter():
        info = get_process_info(proc)
        if info:
            processes.append(info)
    
    # Sort by memory
    processes.sort(key=lambda x: x['memory_rss_mb'], reverse=True)
    return processes

def network_capture_thread(duration, interface, output_file, status_dict):
    """Run network capture in background thread"""
    try:
        process = subprocess.Popen(
            ['tcpdump', '-i', interface, '-w', output_file, '-n', '-v'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        time.sleep(duration)
        
        process.terminate()
        try:
            process.wait(timeout=5)
            status_dict['network_status'] = 'completed'
        except subprocess.TimeoutExpired:
            process.kill()
            status_dict['network_status'] = 'killed'
            
    except Exception as e:
        status_dict['network_status'] = f'error: {str(e)}'

def calculate_file_hash(filepath):
    """Calculate SHA-256 hash of file for integrity"""
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def system_network_capture(duration=60, interface="en0", output_dir="system_network_captures"):
    """Capture complete system state + network activity"""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate filenames
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    pcap_file = f"{output_dir}/network_{timestamp}.pcap"
    json_file = f"{output_dir}/system_analysis_{timestamp}.json"
    csv_file = f"{output_dir}/system_analysis_{timestamp}.csv"
    
    # Capture metadata
    capture_metadata = {
        "capture_start_utc": datetime.datetime.utcnow().isoformat() + 'Z',
        "duration_seconds": duration,
        "interface": interface,
        "snapshot_interval": 10,  # seconds between snapshots
        "pcap_file": pcap_file,
        "tool": "system_network_capture.py v1.1",
        "tool_version": "1.1",
        "user": os.getenv('USER', 'unknown'),
        "host": os.uname().nodename,
        "timestamp_format": "ISO 8601 UTC",
        "timezone": "UTC"
    }
    
    print(f"\n{'='*100}")
    print(f"SYSTEM TRIAGE + NETWORK CAPTURE")
    print(f"{'='*100}")
    print(f"Duration:   {duration} seconds")
    print(f"Interface:  {interface}")
    print(f"Snapshots:  Every 10 seconds (all processes)")
    print(f"Started:    {capture_metadata['capture_start_utc']}")
    print(f"Timezone:   UTC (ISO 8601)")
    print(f"{'='*100}\n")
    
    # Capture initial system state (ALL PROCESSES)
    print("[1/4] Capturing initial system state (all processes)...", flush=True)
    initial_snapshot = capture_all_processes()
    initial_count = len(initial_snapshot)
    initial_memory = sum(p['memory_rss_mb'] for p in initial_snapshot)
    print(f"      ✓ Captured {initial_count} processes using {initial_memory:.1f} MB")
    
    # Start network capture in background
    print("[2/4] Starting network capture...", flush=True)
    status_dict = {'network_status': 'running'}
    network_thread = threading.Thread(
        target=network_capture_thread,
        args=(duration, interface, pcap_file, status_dict)
    )
    network_thread.start()
    
    # Monitor system over time (ALL PROCESSES every 10 seconds)
    print(f"[3/4] Monitoring system for {duration} seconds...", flush=True)
    print(f"      Progress: [", end='', flush=True)
    
    snapshots = []
    snapshot_count = duration // 10  # Every 10 seconds
    
    for i in range(snapshot_count):
        time.sleep(10)
        snapshot = {
            'timestamp_utc': datetime.datetime.utcnow().isoformat() + 'Z',
            'second': (i + 1) * 10,
            'processes': capture_all_processes(),
            'summary': {}
        }
        # Add summary stats
        snapshot['summary'] = {
            'total_processes': len(snapshot['processes']),
            'total_memory_mb': sum(p['memory_rss_mb'] for p in snapshot['processes']),
            'total_threads': sum(p['num_threads'] for p in snapshot['processes']),
            'processes_with_connections': len([p for p in snapshot['processes'] if p['num_connections'] > 0])
        }
        snapshots.append(snapshot)
        print('█', end='', flush=True)
    
    # Sleep remaining time
    remaining = duration % 10
    if remaining > 0:
        time.sleep(remaining)
    
    print('] Done!\n')
    
    # Wait for network capture to complete
    print("[4/4] Finalizing network capture...", flush=True)
    network_thread.join(timeout=10)
    
    # Capture final system state (ALL PROCESSES)
    final_snapshot = capture_all_processes()
    final_count = len(final_snapshot)
    final_memory = sum(p['memory_rss_mb'] for p in final_snapshot)
    print(f"      ✓ Captured {final_count} processes using {final_memory:.1f} MB")
    
    # Calculate network file info
    network_info = {}
    if os.path.exists(pcap_file):
        file_size = os.path.getsize(pcap_file)
        network_info = {
            "file_size_bytes": file_size,
            "file_size_mb": round(file_size / 1024 / 1024, 2),
            "status": status_dict['network_status']
        }
        
        # Get packet count
        try:
            result = subprocess.run(
                ['tcpdump', '-r', pcap_file, '-n', '-q'],
                capture_output=True,
                text=True,
                timeout=10
            )
            network_info["packet_count"] = len(result.stdout.strip().split('\n'))
        except:
            network_info["packet_count"] = "unknown"
        
        # Calculate hash
        print("      Calculating integrity hash...", flush=True)
        network_info["file_hash_sha256"] = calculate_file_hash(pcap_file)
    
    # Analyze changes
    print("\nAnalyzing system changes...", flush=True)
    
    # Find new processes
    initial_pids = {p['pid'] for p in initial_snapshot}
    final_pids = {p['pid'] for p in final_snapshot}
    new_pids = final_pids - initial_pids
    stopped_pids = initial_pids - final_pids
    
    new_processes = [p for p in final_snapshot if p['pid'] in new_pids]
    stopped_processes = [p for p in initial_snapshot if p['pid'] in stopped_pids]
    
    # Find processes with significant memory changes (>10MB)
    memory_changes = []
    initial_by_pid = {p['pid']: p for p in initial_snapshot}
    for final_proc in final_snapshot:
        pid = final_proc['pid']
        if pid in initial_by_pid:
            initial_mem = initial_by_pid[pid]['memory_rss_mb']
            final_mem = final_proc['memory_rss_mb']
            delta = final_mem - initial_mem
            if abs(delta) > 10:  # Changed by more than 10MB
                memory_changes.append({
                    'pid': pid,
                    'name': final_proc['name'],
                    'initial_mb': initial_mem,
                    'final_mb': final_mem,
                    'delta_mb': round(delta, 2)
                })
    
    memory_changes.sort(key=lambda x: abs(x['delta_mb']), reverse=True)
    
    # Build complete report
    report = {
        "metadata": capture_metadata,
        "capture_end_utc": datetime.datetime.utcnow().isoformat() + 'Z',
        "network_capture": network_info,
        
        "initial_state": {
            "timestamp_utc": capture_metadata["capture_start_utc"],
            "total_processes": len(initial_snapshot),
            "total_memory_mb": round(initial_memory, 2),
            "total_threads": sum(p['num_threads'] for p in initial_snapshot),
            "processes": initial_snapshot
        },
        
        "monitoring_snapshots": snapshots,
        
        "final_state": {
            "timestamp_utc": datetime.datetime.utcnow().isoformat() + 'Z',
            "total_processes": len(final_snapshot),
            "total_memory_mb": round(final_memory, 2),
            "total_threads": sum(p['num_threads'] for p in final_snapshot),
            "processes": final_snapshot
        },
        
        "changes_analysis": {
            "new_processes": new_processes,
            "stopped_processes": stopped_processes,
            "significant_memory_changes": memory_changes,
            "process_count_delta": final_count - initial_count,
            "memory_delta_mb": round(final_memory - initial_memory, 2),
            "snapshots_captured": len(snapshots)
        }
    }
    
    # Save JSON report
    print(f"Saving analysis files...", flush=True)
    with open(json_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Save CSV (final state for easy analysis)
    columns = [
        'pid', 'name', 'username', 'status',
        'memory_rss_mb', 'memory_vms_mb', 'memory_percent',
        'cpu_percent', 'num_threads', 'num_connections', 'num_files',
        'ppid', 'cmdline_short', 'create_time_utc'
    ]
    
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(final_snapshot)
    
    # Print summary
    print(f"\n{'='*100}")
    print(f"CAPTURE COMPLETE")
    print(f"{'='*100}")
    print(f"✓ Network capture:  {pcap_file}")
    print(f"✓ System analysis:  {json_file}")
    print(f"✓ Process CSV:      {csv_file}")
    
    if network_info:
        print(f"\n{'Network Activity':-^100}")
        print(f"  Captured:  {network_info.get('file_size_mb', 0):.2f} MB")
        print(f"  Packets:   {network_info.get('packet_count', 'unknown')}")
        print(f"  Status:    {network_info.get('status', 'unknown')}")
        print(f"  Hash:      {network_info.get('file_hash_sha256', 'N/A')[:32]}...")
    
    print(f"\n{'System State (Initial → Final)':-^100}")
    print(f"  Processes: {initial_count} → {final_count} ({final_count - initial_count:+d})")
    print(f"  Memory:    {initial_memory:.1f} MB → {final_memory:.1f} MB ({final_memory - initial_memory:+.1f} MB)")
    print(f"  Snapshots: {len(snapshots)} captured every 10 seconds")
    
    if new_processes:
        print(f"\n{'New Processes Started During Capture':-^100}")
        for p in new_processes[:10]:  # Show first 10
            print(f"  PID {p['pid']:<6} {p['name']:<30} {p['memory_rss_mb']:>8.1f} MB  ({p['username']})")
        if len(new_processes) > 10:
            print(f"  ... and {len(new_processes) - 10} more")
    
    if stopped_processes:
        print(f"\n{'Processes Stopped During Capture':-^100}")
        for p in stopped_processes[:10]:
            print(f"  PID {p['pid']:<6} {p['name']:<30} {p['memory_rss_mb']:>8.1f} MB  ({p['username']})")
        if len(stopped_processes) > 10:
            print(f"  ... and {len(stopped_processes) - 10} more")
    
    if memory_changes:
        print(f"\n{'Significant Memory Changes (>10 MB)':-^100}")
        for change in memory_changes[:10]:
            print(f"  PID {change['pid']:<6} {change['name']:<30} {change['initial_mb']:>8.1f} MB → {change['final_mb']:>8.1f} MB ({change['delta_mb']:+.1f} MB)")
        if len(memory_changes) > 10:
            print(f"  ... and {len(memory_changes) - 10} more")
    
    print(f"\n{'Forensic Notes':-^100}")
    print(f"  - Complete system state captured at start, during, and end")
    print(f"  - All timestamps in ISO format for correlation")
    print(f"  - Network capture includes integrity hash")
    print(f"  - Use CSV for spreadsheet analysis of final state")
    print(f"  - Use JSON for complete timeline and changes analysis")
    print(f"  - Can correlate with spindump if system hang occurs")
    
    print(f"\n{'Quick Analysis':-^100}")
    print(f"  # View network in Wireshark")
    print(f"  open -a Wireshark {pcap_file}")
    print(f"\n  # View final process list")
    print(f"  cat {csv_file} | head -20")
    print(f"\n  # Check what changed")
    print(f"  cat {json_file} | jq '.changes_analysis'")
    print(f"\n{'='*100}\n")
    
    return json_file, pcap_file, csv_file

def main():
    if os.geteuid() != 0:
        print("⚠️  Warning: Not running as root")
        print("   Network capture requires sudo privileges")
        print("   Usage: sudo ./system_network_capture.py [duration] [interface]\n")
    
    if len(sys.argv) > 1 and sys.argv[1] in ['-h', '--help']:
        print("System Triage + Network Capture Tool")
        print("\nCaptures complete system state (all processes) + network activity")
        print("\nUsage:")
        print("  sudo ./system_network_capture.py [duration] [interface]")
        print("\nExamples:")
        print("  sudo ./system_network_capture.py              # 60s capture, en0")
        print("  sudo ./system_network_capture.py 30           # 30s capture, en0")
        print("  sudo ./system_network_capture.py 60 en0       # 60s on en0")
        print("\nForensic Applications:")
        print("  - Incident response - what was running during event?")
        print("  - Malware investigation - what started during infection?")
        print("  - Pre-spindump triage - system state before crash")
        print("  - Performance analysis - system-wide changes over time")
        sys.exit(0)
    
    duration = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    interface = sys.argv[2] if len(sys.argv) > 2 else "en0"
    
    system_network_capture(duration, interface)

if __name__ == "__main__":
    main()
