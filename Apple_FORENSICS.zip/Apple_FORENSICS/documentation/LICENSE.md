MIT License

Copyright (c) 2025 Backwater Forensics

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

ADDITIONAL TERMS AND CONDITIONS FOR USE

1. INTENDED USE
   This software is designed for legitimate forensic investigation, incident
   response, malware analysis, and security research. Users must comply with
   all applicable laws and regulations in their jurisdiction.

2. PROHIBITED USE
   This software SHALL NOT be used for:
   - Unauthorized access to computer systems
   - Privacy violations or illegal surveillance
   - Stalking, harassment, or other harmful activities
   - Evidence tampering or destruction
   - Any illegal or unethical purposes

3. ETHICAL GUIDELINES
   This software follows the "Victim Investigator Approach" - designed to
   empower victims and legitimate investigators. Users are expected to:
   - Respect privacy and legal boundaries
   - Maintain proper chain of custody for evidence
   - Use the software only for lawful purposes
   - Document all investigative activities properly
   - Seek appropriate legal authorization when required

4. EVIDENCE INTEGRITY
   Users are responsible for:
   - Maintaining forensic standards and best practices
   - Verifying evidence integrity (SHA-256 hashes provided)
   - Proper documentation and chain of custody
   - Compliance with legal requirements for evidence handling
   - Not modifying or tampering with original evidence

5. NO WARRANTY FOR LEGAL COMPLIANCE
   While this software is designed to produce court-admissible evidence,
   users are solely responsible for:
   - Ensuring compliance with local laws and regulations
   - Obtaining proper legal authorization for investigations
   - Meeting evidentiary standards in their jurisdiction
   - Professional and ethical use of the software

6. LIMITATION OF LIABILITY
   The authors and copyright holders of this software:
   - Make no warranties about fitness for any particular purpose
   - Are not responsible for how the software is used
   - Are not liable for any misuse or illegal use
   - Are not responsible for any legal consequences of use
   - Provide the software "as is" without any guarantees

7. EDUCATIONAL AND RESEARCH USE
   This software may be used for:
   - Educational purposes in academic settings
   - Security research and malware analysis
   - Incident response training
   - Digital forensics education
   - Lawful security testing with proper authorization

8. COMMERCIAL USE
   Commercial use is permitted under the MIT License terms, provided:
   - All legal and ethical guidelines are followed
   - Proper attribution is maintained
   - The software is not used to facilitate illegal activities
   - Users comply with all applicable laws and regulations

9. MODIFICATIONS AND DERIVATIVES
   Modified versions of this software:
   - Must maintain these ethical guidelines
   - Should clearly indicate modifications
   - Cannot be used to circumvent legal requirements
   - Must include appropriate copyright notices
   - Should maintain the Victim Investigator Approach philosophy

10. DISCLAIMER
    The authors are not law enforcement and do not provide:
    - Legal advice or legal services
    - Law enforcement capabilities
    - Guaranteed admissibility in court
    - Professional forensic certification
    - Legal or investigative authorization

11. USER RESPONSIBILITY
    By using this software, users acknowledge that they:
    - Are responsible for legal compliance
    - Understand applicable laws in their jurisdiction
    - Will use the software ethically and legally
    - Accept full responsibility for their actions
    - Will not hold the authors liable for their use of the software

12. REPORTING MISUSE
    If you become aware of misuse of this software:
    - Report it to appropriate authorities
    - Contact the project maintainers if appropriate
    - Do not participate in or enable illegal activities

---

BACKWATER FORENSICS
Apple FORENSICS - Professional macOS Forensic Analysis Toolkit
Version 1.0 - December 2025

Victim Investigator Approach:
This software is designed to empower victims seeking justice and legitimate
investigators conducting lawful inquiries. It is built on principles of
transparency, integrity, and ethical use.

For questions about licensing or appropriate use:
See README.md and documentation files included with the software.

---

By downloading, installing, or using this software, you agree to:
1. The MIT License terms above
2. The Additional Terms and Conditions
3. All applicable laws and regulations
4. Ethical and responsible use of forensic tools

If you do not agree to these terms, do not use this software.

---

END OF LICENSE
