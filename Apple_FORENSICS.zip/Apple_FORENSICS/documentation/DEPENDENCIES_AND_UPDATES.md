# Apple FORENSICS - Dependencies & Updates Guide
## Installation, Updates, and Maintenance

**Date:** December 30, 2025  
**Version:** 1.1  
**Status:** Complete Documentation

---

## 📦 Table of Contents

1. [Dependencies Overview](#dependencies-overview)
2. [Initial Installation](#initial-installation)
3. [Updating Existing Installation](#updating-existing-installation)
4. [Troubleshooting](#troubleshooting)
5. [Manual Installation](#manual-installation)

---

## 📚 Dependencies Overview

### Required Python Libraries

| Library | Purpose | Required For | Install Priority |
|---------|---------|--------------|------------------|
| `reportlab` | PDF generation | Status Reports (Option 12) | HIGH |

### Future Dependencies

As new features are added, additional dependencies may be required:
- Image processing libraries (for future image forensics)
- Database libraries (for future case management)
- Network analysis libraries (for future packet analysis)

---

## 🚀 Initial Installation

### Step 1: Basic Setup

```bash
# Navigate to your toolkit location
cd ~/Desktop/Apple_FORENSICS  # or ~/Apple_FORENSICS_Package

# Make scripts executable
chmod +x install_dependencies.sh
chmod +x update_toolkit.sh
```

---

### Step 2: Install Dependencies

**Recommended Method:**
```bash
./install_dependencies.sh
```

**What It Does:**
```
🔧 Apple FORENSICS - Installing Dependencies
=============================================

Checking Python version...
Python 3.11.5
✅ Python 3 found

Checking pip...
✅ pip found

Installing Python dependencies...

📦 Installing reportlab (PDF generation)...
✅ reportlab installed

Verifying installations...
✅ reportlab: 4.0.7

═══════════════════════════════════════════════════════
✅ Dependency Installation Complete!

📋 Installed Dependencies:
   • reportlab - PDF report generation

🎯 You're ready to use Apple FORENSICS!
```

---

### Step 3: Verify Installation

```bash
# Test reportlab
python3 -c "import reportlab; print('reportlab:', reportlab.__version__)"

# Should output:
# reportlab: 4.0.7
```

---

## 🔄 Updating Existing Installation

### When to Update

Update your installation when:
- 🐛 **Bug fixes** are released
- ✨ **New features** are added
- 📚 **New dependencies** are required
- 🔧 **Performance improvements** are available

---

### Update Process

**Step 1: Download Update Files**

Get the latest versions:
- `apple_forensics_dashboard.py`
- `log_directory_analyzer.py`
- `home_directory_analyzer.py`
- `network_capture.py`
- `system_network_capture.py`
- `install_dependencies.sh` (if updated)
- `UPDATE_NOTES.md` (describes changes)

---

**Step 2: Place Update Files**

```bash
# Create update directory
mkdir ~/Desktop/apple_forensics_update
cd ~/Desktop/apple_forensics_update

# Place all downloaded update files here
# (apple_forensics_dashboard.py, install_dependencies.sh, etc.)
```

---

**Step 3: Run Update Script**

```bash
# Copy update script to update directory
cp update_toolkit.sh ~/Desktop/apple_forensics_update/

# Make it executable
chmod +x update_toolkit.sh

# Run update
./update_toolkit.sh
```

**Interactive Update Process:**
```
🔄 Apple FORENSICS - Update Script
===================================

📂 Installation found: /Users/you/Desktop/Apple_FORENSICS

📦 Creating backup...
   Location: /Users/you/Desktop/Apple_FORENSICS_backup_20251230_153000
✅ Backup created

📥 Looking for update files in: /Users/you/Desktop/apple_forensics_update

Updating files...

✅ Updated: apple_forensics_dashboard.py
✅ Updated: log_directory_analyzer.py
✅ Updated: home_directory_analyzer.py
⏭️  Skipped: network_capture.py (not found in update directory)
⏭️  Skipped: system_network_capture.py (not found in update directory)

Checking dependencies...
📦 New dependency installer found

Install/update dependencies? (y/n): y

🔧 Apple FORENSICS - Installing Dependencies
...

═══════════════════════════════════════════════════════
✅ Update Complete!

📊 Update Summary:
   • Files updated: 3
   • Files skipped: 2
   • Backup location: /Users/you/Desktop/Apple_FORENSICS_backup_20251230_153000

🎯 Notes:
   • Your old files are backed up in case of issues
   • Run install_dependencies.sh if new features require new libraries
   • Restart any running tools to use updated versions

📖 See UPDATE_NOTES.md for details on what changed
```

---

## 🐛 Troubleshooting

### Issue 1: "reportlab not found" When Generating PDF

**Symptom:**
```
❌ reportlab library not found!
```

**Solution 1 - Use Install Script:**
```bash
cd ~/Desktop/Apple_FORENSICS
./install_dependencies.sh
```

**Solution 2 - Manual Install:**
```bash
pip3 install reportlab --break-system-packages
```

**Solution 3 - Try with sudo (if above fails):**
```bash
sudo pip3 install reportlab
```

**After Installation:**
```bash
# Restart dashboard
./apple_forensics_dashboard.py

# Try generating PDF report again
→ Option 12: Generate Investigation Status Report
→ Choice: 5 (PDF only)
```

---

### Issue 2: Installation Doesn't Persist

**Symptom:**
reportlab installs successfully but isn't available when dashboard runs.

**Cause:**
Multiple Python installations or virtual environments.

**Solution:**
```bash
# Find which Python the dashboard uses
head -1 apple_forensics_dashboard.py
# Output: #!/usr/bin/env python3

# Check which Python that is
which python3
# Output: /usr/local/bin/python3

# Install to that specific Python
/usr/local/bin/python3 -m pip install reportlab --break-system-packages

# Or update shebang to use specific Python
# Edit first line of dashboard to:
#!/usr/local/bin/python3
```

---

### Issue 3: Permission Denied During Installation

**Symptom:**
```
❌ Permission denied while installing reportlab
```

**Solution:**
```bash
# Option 1: Use --user flag
pip3 install reportlab --user --break-system-packages

# Option 2: Use sudo (macOS/Linux)
sudo pip3 install reportlab --break-system-packages

# Option 3: Fix permissions
sudo chown -R $(whoami) /usr/local/lib/python3.*/site-packages
```

---

### Issue 4: Update Script Can't Find Installation

**Symptom:**
```
❌ Installation directory not found.
```

**Solution:**
```bash
# Update script will prompt for location
Installation path: ~/Apple_FORENSICS_Package

# Or manually specify:
INSTALL_DIR=~/Apple_FORENSICS_Package ./update_toolkit.sh
```

---

## 🛠️ Manual Installation

### When to Use Manual Installation

- Install script fails
- Custom installation location
- Corporate environment with restrictions
- Troubleshooting

---

### Manual Dependency Installation

**reportlab (PDF Generation):**
```bash
# Standard installation
pip3 install reportlab --break-system-packages

# With sudo
sudo pip3 install reportlab

# User installation
pip3 install reportlab --user

# Specific version
pip3 install reportlab==4.0.7 --break-system-packages

# Verify
python3 -c "import reportlab; print(reportlab.__version__)"
```

---

### Manual File Updates

```bash
# Backup current installation
cp ~/Desktop/Apple_FORENSICS ~/Desktop/Apple_FORENSICS_backup_$(date +%Y%m%d)

# Update dashboard
cp apple_forensics_dashboard.py ~/Desktop/Apple_FORENSICS/

# Update analyzers
cp log_directory_analyzer.py ~/Desktop/Apple_FORENSICS/tools/log_analyzer/
cp home_directory_analyzer.py ~/Desktop/Apple_FORENSICS/tools/home_analyzer/

# Update network tools
cp network_capture.py ~/Desktop/Apple_FORENSICS/tools/network_capture/
cp system_network_capture.py ~/Desktop/Apple_FORENSICS/tools/network_capture/

# Set executable
chmod +x ~/Desktop/Apple_FORENSICS/*.py
chmod +x ~/Desktop/Apple_FORENSICS/tools/*/*.py
```

---

## 📋 Dependency Checklist

Use this checklist when installing or updating:

### Initial Installation
- [ ] Python 3.8+ installed
- [ ] pip3 available
- [ ] reportlab installed
- [ ] reportlab verified (can import)
- [ ] Dashboard runs without errors
- [ ] PDF generation works (Option 12)

### After Each Update
- [ ] Backup created
- [ ] New files copied
- [ ] Dependencies updated (if needed)
- [ ] Executable permissions set
- [ ] Dashboard launches
- [ ] Updated features work
- [ ] No regression (old features still work)

---

## 🎯 Best Practices

### 1. Always Backup Before Updates

```bash
# Automatic backup (update script does this)
# Manual backup:
cp -r ~/Desktop/Apple_FORENSICS ~/Desktop/Apple_FORENSICS_backup_$(date +%Y%m%d)
```

---

### 2. Test After Installation

```bash
# Launch dashboard
./apple_forensics_dashboard.py

# Test PDF generation
→ Load investigation
→ Option 12: Generate Status Report
→ Choice: 5 (PDF only)
→ Should succeed without errors
```

---

### 3. Document Custom Installations

If you customize your installation:
```bash
# Create notes
cat > CUSTOM_INSTALLATION.txt << EOF
Installation Location: ~/Custom/Path/Apple_FORENSICS
Python Version: 3.11.5
Python Location: /usr/local/bin/python3
reportlab Version: 4.0.7
Installation Date: $(date)
Custom Settings: [describe any changes]
EOF
```

---

### 4. Keep Dependencies Updated

```bash
# Check for reportlab updates
pip3 list --outdated | grep reportlab

# Update if needed
pip3 install --upgrade reportlab --break-system-packages
```

---

## 📖 Update Notes Template

When you release an update, include `UPDATE_NOTES.md`:

```markdown
# Apple FORENSICS Update - Version 1.1
## Date: December 30, 2025

### 🐛 Bug Fixes
- Fixed status report PDF generation field names
- Fixed whitelist configuration persistence
- Fixed UTC timestamp handling

### ✨ New Features
- Added whitelist configuration (Option 7b)
- Added timeline tracking in status reports
- Added category breakdown in all report formats

### 📦 Dependencies
- No new dependencies required
- Existing: reportlab (for PDF generation)

### 🔄 Update Instructions
1. Run: ./update_toolkit.sh
2. No dependency updates needed
3. Restart dashboard

### ⚠️ Breaking Changes
- None

### 📝 Notes
- All investigations automatically migrate to new format
- Old reports remain compatible
```

---

## ✅ Quick Reference

### Install Dependencies
```bash
./install_dependencies.sh
```

### Update Installation
```bash
./update_toolkit.sh
```

### Verify Installation
```bash
python3 -c "import reportlab; print('✅ reportlab installed')"
```

### Manual Install reportlab
```bash
pip3 install reportlab --break-system-packages
```

---

## 🎯 Summary

### Remember:

1. **New installations:** Run `install_dependencies.sh` first
2. **Updates:** Use `update_toolkit.sh` for bug fixes
3. **New dependencies:** Update script will prompt you
4. **PDF errors:** Check reportlab installation
5. **Always backup:** Update script does this automatically

### Files to Keep Track Of:

- `install_dependencies.sh` - Installs Python libraries
- `update_toolkit.sh` - Updates toolkit files
- `UPDATE_NOTES.md` - Describes what changed
- `DEPENDENCIES.md` - This file!

---

**Keep your toolkit updated and dependencies installed!** 🎯

---

*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*  
*Dependencies & Updates Guide - Complete*
