# Apple FORENSICS Quick Start Guide
**Professional macOS Forensic Analysis Toolkit**

Version 1.0 | December 2025 | Backwater Forensics

---

## 🚀 **Getting Started in 5 Minutes**

### Prerequisites
- macOS 10.15 (Catalina) or later
- Python 3.8+
- Terminal access
- Administrator privileges (for some features)

### Installation

**1. Download Apple FORENSICS**
```bash
# Clone or download to your preferred directory
cd ~/Documents
mkdir apple-forensics
cd apple-forensics

# Copy all files here
```

**2. Make Scripts Executable**
```bash
chmod +x apple_forensics_dashboard.py
chmod +x *.py
```

**3. Verify Installation**
```bash
./apple_forensics_dashboard.py
```

You should see the Apple FORENSICS banner! 🎉

---

## 📋 **Your First Investigation (3 Steps)**

### Step 1: Create Investigation
```bash
./apple_forensics_dashboard.py
# Select: 1. Create New Investigation
# Enter: Case ID (e.g., CASE-2025-001)
# Enter: Your name
# Enter: Case description
```

### Step 2: Run Analysis
```bash
# From the dashboard menu:
# 8. Run Log Analysis       ← Analyze system logs
# 38. Chrome History        ← Browser forensics
# 20. Process Memory        ← Capture running processes
```

### Step 3: Search & Report
```bash
# 42. Search Analysis by Date Range  ← Find events in time window
# 43. Generate Status Report         ← Create comprehensive report
```

**Done!** Your investigation folder contains all evidence with SHA-256 hashes.

---

## 🎯 **Common Tasks**

### Browser Forensics (Most Popular)
```bash
# Analyze all 4 browsers
38. Chrome History Analysis
39. Safari History Analysis
40. Firefox History Analysis
41. Brave History Analysis

# Each produces:
# - JSON (machine-readable)
# - CSV (spreadsheet import)
# - Markdown (human-readable)
# - SHA-256 hash (integrity)
```

**Pro Tip:** Use suspicious-only mode to reduce false positives by 80%!

### Timeline Investigation
```bash
# 1. Run multiple analyses (browsers, logs, processes)
# 2. Use date range search:
42. Search Analysis by Date Range
   Start: 2025-12-30T14:00:00Z
   End:   2025-12-30T16:00:00Z
# 3. Get unified timeline across ALL sources!
```

### Log Analysis
```bash
# Configure once:
13. Configure Log Directories  ← Point to system logs
14. Configure Pattern Files    ← Select what to detect
15. Configure Whitelist Files  ← Reduce false positives

# Then analyze:
8. Run Log Analysis           ← Scan for threats
9. View Analysis Results      ← Review findings
```

---

## 📂 **Understanding Your Investigation Folder**

```
Investigations/CASE-2025-001/
├── investigation.json              ← Case metadata
├── notes/                         
│   └── note_TIMESTAMP.md          ← Your investigation notes
├── artifacts/                     
│   ├── logs/                      ← Log analysis results
│   ├── browser_forensics/
│   │   ├── chrome/                ← Chrome history
│   │   ├── safari/                ← Safari history
│   │   ├── firefox/               ← Firefox history
│   │   └── brave/                 ← Brave history
│   ├── runtime_monitoring/        ← Process snapshots
│   └── home_directory/            ← File analysis
├── searches/                      
│   └── daterange_search_*.json    ← Timeline searches
└── reports/                       
    └── status_report_*.md         ← Investigation reports
```

**Everything timestamped, hashed, and ready for court!**

---

## 🔍 **Essential Menu Sections**

### INVESTIGATION (1-3)
Start here! Create, load, or list investigations.

### CURRENT INVESTIGATION (4-5, 10-11)
Manage active case - view details, add notes, close case.

### TOOLS (13-19, 16)
Configure analysis settings:
- **13-15:** Configure logs, patterns, whitelists
- **16:** Cleanup false positives
- **17-19:** Pattern file utilities

### LOG ANALYSIS (8-9)
Run and review log analysis - detect malware, crashes, security events.

### RUNTIME MONITORING (20-24)
Capture live system state:
- Process snapshots
- Network connections
- Memory dumps

### ARTIFACT COLLECTION (25)
Analyze file systems and directories.

### BROWSER FORENSICS (38-41)
Extract browsing history from all major browsers.

### SEARCH & REPORTING (42-43)
Find events by date and generate professional reports.

---

## 💡 **Pro Tips**

### 1. Use Whitelists!
```bash
# Reduces false positives by ~80%
15. Configure Whitelist Files
# Select: chrome_whitelist.txt, safari_whitelist.txt, etc.
```

### 2. Document Everything
```bash
# Add notes throughout investigation
10. Add Investigator Note
# Include: what you found, why it matters, next steps
```

### 3. Date Range Search is Powerful
```bash
# Search ALL artifacts at once
42. Search Analysis by Date Range
# Returns: browser visits, log events, processes, network
# All in one timeline!
```

### 4. Generate Reports Early and Often
```bash
# Track progress with status reports
43. Generate Investigation Status Report
# Shows: all analyses run, findings count, timeline
```

### 5. Suspicious-Only Mode
```bash
# When analyzing browsers:
"Show only suspicious URLs? (y/n)"
# Yes = Fast, focused on threats
# No  = Complete timeline (for alibis, patterns)
```

---

## 🎓 **Common Workflows**

### Malware Investigation
```
1. Create Investigation
2. Run Log Analysis (8)           ← Detect malware traces
3. System Process Triage (21)     ← Find suspicious processes
4. Network Capture (22)           ← Identify C2 servers
5. Browser Analysis (38-41)       ← Check for malware downloads
6. Date Range Search (42)         ← Build infection timeline
7. Generate Report (43)
```

### Incident Response
```
1. Create Investigation
2. System + Network Capture (24)  ← Full system state
3. Browser Analysis (38-41)       ← What user was doing
4. Log Analysis (8)               ← System events
5. Date Range Search (42)         ← Focus on incident window
6. Generate Report (43)
```

### Employee Monitoring
```
1. Create Investigation
2. Browser Analysis (38-41)       ← Browsing activity
3. Home Directory (25)            ← Downloaded files
4. Process Triage (21)            ← Running applications
5. Date Range Search (42)         ← Activity during work hours
6. Generate Report (43)
```

### Data Theft Investigation
```
1. Create Investigation
2. Browser Analysis (38-41)       ← Cloud uploads, email
3. Home Directory (25)            ← File access, USB drives
4. Network Capture (22)           ← File transfers
5. Date Range Search (42)         ← Timeline of data access
6. Generate Report (43)
```

---

## 🔧 **Troubleshooting**

### "Permission denied"
```bash
# For system logs:
sudo ./apple_forensics_dashboard.py

# Or copy logs first:
cp -r /var/log ~/evidence/
# Then analyze the copy
```

### "No patterns loaded"
```bash
# Make sure pattern files are in same directory:
ls -la *_patterns.txt
# Should see: macos_security_patterns.txt, crash_patterns.txt, etc.
```

### "Browser not found"
```bash
# Browser not installed? That's OK!
# Just skip that browser option
# Analyze the browsers that ARE installed
```

### Too many false positives
```bash
# Use whitelists:
15. Configure Whitelist Files
# Select appropriate whitelists for your environment
```

---

## 📚 **Next Steps**

### Learn More
- Read `TOOL_REFERENCE.md` for complete feature documentation
- Check `README.md` for philosophy and approach
- Review `LICENSE.md` for usage terms

### Advanced Features
- Custom pattern files (17)
- Pattern file creation (18)
- Analysis cleanup (16)
- Quick scan mode (19)

### Get Help
- GitHub Issues: Report bugs, request features
- Documentation: Complete tool reference available
- Community: Share tips and techniques

---

## ⚡ **Quick Reference**

### Most Used Options
```
1  → Create Investigation
2  → Load Investigation
8  → Run Log Analysis
38 → Chrome History
39 → Safari History
40 → Firefox History
41 → Brave History
42 → Date Range Search
43 → Generate Report
```

### Keyboard Shortcuts
- Just type the number and press Enter
- No need for leading zeros
- `0` to exit anytime

### File Formats
- **JSON:** Machine-readable, complete data
- **CSV:** Import to Excel/spreadsheet
- **Markdown:** Human-readable reports
- **SHA-256:** Integrity verification

---

## 🎯 **Success Criteria**

You're using Apple FORENSICS effectively when:
- ✅ Each investigation has its own folder
- ✅ All findings have SHA-256 hashes
- ✅ Timestamps are in UTC with 'Z' suffix
- ✅ You're using whitelists to reduce noise
- ✅ Notes document your investigative process
- ✅ Reports are comprehensive and professional
- ✅ Evidence is organized and court-ready

---

## 🔒 **Forensic Best Practices**

### Chain of Custody
```
1. Document: Who, what, when, where
2. Hash: Every file gets SHA-256
3. Timestamp: UTC timestamps throughout
4. Notes: Document every step
5. Reports: Professional presentation
```

### Evidence Integrity
```
- Never modify original files
- Work from copies when possible
- Verify hashes before and after
- Keep investigation folders intact
- Generate reports for stakeholders
```

### Professional Standards
```
- Use consistent case IDs
- Add investigator notes liberally
- Generate status reports regularly
- Maintain proper folder structure
- Document methodology
```

---

## 🚀 **Ready to Investigate!**

You now have everything you need to conduct professional macOS forensic investigations.

**Start your first case:**
```bash
./apple_forensics_dashboard.py
# Press 1 for Create New Investigation
# Let's go! 🔍
```

---

**Backwater Forensics • Apple FORENSICS**  
*Victim Investigator Approach*  
*Professional macOS Forensic Analysis*

Version 1.0 • December 2025  
For support: See README.md and TOOL_REFERENCE.md
