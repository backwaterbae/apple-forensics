# Apple FORENSICS - Complete Tool Reference
**Professional macOS Forensic Analysis Toolkit**

Version 1.0 | December 2025 | Backwater Forensics

---

## 📚 **Table of Contents**

1. [Dashboard Overview](#dashboard-overview)
2. [Investigation Management](#investigation-management)
3. [Tools & Configuration](#tools--configuration)
4. [Log Analysis](#log-analysis)
5. [Runtime Monitoring](#runtime-monitoring)
6. [Artifact Collection](#artifact-collection)
7. [Browser Forensics](#browser-forensics)
8. [Search & Reporting](#search--reporting)
9. [Standalone Tools](#standalone-tools)
10. [Output Formats](#output-formats)
11. [Pattern Files](#pattern-files)
12. [Whitelist System](#whitelist-system)

---

## 🎛️ **Dashboard Overview**

### Menu Structure

Apple FORENSICS uses a comprehensive dashboard with 9 organized sections:

```
INVESTIGATION (1-3)           → Setup and management
CURRENT INVESTIGATION (4-5,   → Active case operations
  10-11)
TOOLS (13-19, 16)            → Configuration and utilities
LOG ANALYSIS (8-9)           → System log examination
RUNTIME MONITORING (20-24)   → Live system capture
ARTIFACT COLLECTION (25)     → File and directory analysis
BROWSER FORENSICS (38-41)    → Web history extraction
SEARCH & REPORTING (42-43)   → Timeline search and reports
SYSTEM (0)                   → Exit
```

### Navigation
- Type option number and press Enter
- No leading zeros needed
- Green = Available, Gray = Requires active investigation
- Type `0` to exit anytime

---

## 📁 **Investigation Management**

### Option 1: Create New Investigation

**Purpose:** Initialize a new forensic investigation case

**Required Information:**
- Case ID (e.g., CASE-2025-001, 2025-001, or any identifier)
- Investigator name
- Case description

**What It Creates:**
```
Investigations/CASE-2025-001/
├── investigation.json       ← Case metadata
├── notes/                   ← Empty, ready for notes
├── artifacts/               ← Empty, ready for evidence
├── searches/                ← Empty, ready for searches
└── reports/                 ← Empty, ready for reports
```

**Metadata Tracked:**
- Creation timestamp (UTC)
- Investigator name
- Case status (active/closed)
- All analysis runs
- All investigator notes

**Best Practices:**
- Use consistent case ID format
- Include case year for organization
- Be descriptive in case description
- Start investigating immediately

---

### Option 2: Load Existing Investigation

**Purpose:** Resume work on a previously created investigation

**How It Works:**
1. Lists all investigations in `Investigations/` directory
2. Shows: Case ID, investigator, description, status
3. Prompts for case number or ID
4. Loads investigation metadata

**Features:**
- Supports case number (e.g., `1`) or Case ID (e.g., `CASE-001`)
- Shows active vs. closed status
- Displays all previous analyses
- Ready to resume work immediately

**Use Cases:**
- Resume multi-day investigation
- Review past cases
- Add new evidence to existing case
- Generate updated reports

---

### Option 3: List All Investigations

**Purpose:** View all investigations without loading

**What It Shows:**
```
╔════════════════════════════════════════╗
║        ALL INVESTIGATIONS              ║
╚════════════════════════════════════════╝

1. CASE-2025-001 [ACTIVE]
   Investigator: Alice Smith
   Created: 2025-12-30T15:30:00Z
   Description: Employee data theft investigation

2. CASE-2025-002 [CLOSED]
   Investigator: Bob Jones
   Created: 2025-12-28T10:00:00Z
   Description: Malware incident response
```

**Use Cases:**
- Quick case overview
- Find case ID you forgot
- Check investigation status
- Audit trail review

---

### Option 4: View Investigation Details

**Purpose:** Display complete investigation metadata

**What It Shows:**
- Case ID and description
- Investigator name
- Creation and closure timestamps
- Victim information (if provided)
- Incident date (if provided)
- Case type (if provided)
- All configured directories and files
- Complete analysis history
- All investigator notes

**Use Cases:**
- Verify case details before proceeding
- Review investigation progress
- Check what analyses have been run
- Audit investigation history

---

### Option 5: Edit Investigation Details

**Purpose:** Modify case metadata

**Editable Fields:**
- Description
- Victim information
- Incident date
- Case type

**Non-Editable:**
- Case ID (permanent identifier)
- Creation timestamp
- Investigator name

**Use Cases:**
- Add victim details later
- Update description as case evolves
- Correct incident date
- Specify case type

---

### Option 10: Add Investigator Note

**Purpose:** Document investigative findings and decisions

**Features:**
- Timestamped automatically (UTC)
- Saved as individual Markdown files
- Preserved in investigation folder
- Included in status reports

**What to Document:**
- Findings and observations
- Decisions and reasoning
- Next steps
- Important timestamps
- Evidence locations

**File Format:**
```markdown
# Investigator Note
**Timestamp:** 2025-12-30T15:45:00Z
**Case ID:** CASE-2025-001
**Investigator:** Alice Smith

## Note
Found suspicious Chrome download at 14:23 UTC.
File hash matches known malware signature.
Next: Analyze process memory from that timeframe.
```

**Best Practices:**
- Add notes throughout investigation
- Be specific and detailed
- Include timestamps when relevant
- Reference evidence file names
- Explain your reasoning

---

### Option 11: Close Investigation

**Purpose:** Mark investigation as complete

**What Happens:**
- Sets status to "CLOSED"
- Records closure timestamp
- Preserves all evidence and notes
- Prevents accidental modification

**Confirmation Required:** Yes

**Can Be Reopened:** Yes (via Load Investigation)

**Use Cases:**
- Investigation complete
- Case going to prosecution
- Archiving old cases
- Finalizing documentation

---

## 🛠️ **Tools & Configuration**

### Option 13: Configure Log Directories

**Purpose:** Specify which macOS log directories to analyze

**Default Directories:**
```
~/Library/Logs                    ← User logs
/Library/Logs                     ← System logs
/var/log                          ← System daemon logs
```

**Common Additional Directories:**
```
~/Library/Logs/DiagnosticReports ← Crash reports
~/Library/Logs/CrashReporter     ← Application crashes
/Library/Logs/DiagnosticReports  ← System crashes
```

**How It Works:**
1. Shows current configured directories
2. Prompts to add more directories
3. Validates each path exists
4. Saves to investigation metadata

**Best Practices:**
- Start with defaults
- Add DiagnosticReports for crash analysis
- Use sudo for /var/log access
- Verify paths before adding

---

### Option 14: Configure Pattern Files

**Purpose:** Select which detection patterns to use

**Available Pattern Files:**
```
macos_security_patterns.txt    - 60+ security event patterns
crash_patterns.txt             - 50+ crash detection patterns
malware_patterns.txt           - 100+ malware signatures
custom_patterns.txt            - User-defined patterns
```

**Pattern Types:**
- `PARTIAL:` - Substring matching
- `REGEX:` - Regular expression matching
- Categories: Security, Malware, Crash, Error, Warning

**How It Works:**
1. Lists available pattern files
2. Shows number of patterns in each
3. Allows multiple selection
4. Saves to investigation metadata

**Best Practices:**
- Use all three default pattern files
- Create custom patterns for specific cases
- Review pattern files before use
- Update patterns regularly

---

### Option 15: Configure Whitelist Files

**Purpose:** Filter false positives from analysis results

**Available Whitelists:**
```
chrome_whitelist.txt    - 100+ domains for Chrome
safari_whitelist.txt    - 100+ domains for Safari  
firefox_whitelist.txt   - 100+ domains for Firefox
brave_whitelist.txt     - 120+ domains for Brave
```

**What Gets Whitelisted:**
- Legitimate domains (apple.com, google.com)
- Common file extensions (.pdf, .jpg)
- CDN infrastructure
- Standard web services

**Effectiveness:** ~80% false positive reduction

**How It Works:**
1. Lists available whitelist files
2. Shows entry counts
3. Allows multiple selection
4. Applied automatically in analyses

**Best Practices:**
- Always use whitelists
- Select browser-specific whitelists
- Review whitelists for your environment
- Create custom whitelists if needed

---

### Option 16: Analysis Cleanup Tool

**Purpose:** Filter false positives from existing analysis results

**What It Does:**
- Scans all JSON artifacts
- Applies whitelist retroactively
- Creates cleaned versions
- Preserves originals

**Use Cases:**
- Too many false positives in results
- Whitelist added after analysis
- Need cleaner reports
- Focusing on real threats

**Output:**
```
Original: chrome_history_CASE-001_20251230.json
Cleaned:  chrome_history_CASE-001_20251230_cleaned.json
```

**Best Practices:**
- Run after adding whitelists
- Compare before/after counts
- Review cleaned results
- Keep originals for reference

---

### Option 17: Create Custom Pattern File

**Purpose:** Build your own detection patterns

**Pattern Format:**
```
# Comment
PARTIAL:search_string|CATEGORY:Type|SEVERITY:Level
REGEX:regex_pattern|CATEGORY:Type|SEVERITY:Level
```

**Example:**
```
# Custom malware detection
PARTIAL:evil.exe|CATEGORY:Malware|SEVERITY:HIGH
REGEX:192\.168\.\d+\.\d+|CATEGORY:Network|SEVERITY:MEDIUM
```

**Supported Categories:**
- Security
- Malware
- Crash
- Error
- Warning
- Network
- Custom

**Severity Levels:**
- HIGH - Immediate attention required
- MEDIUM - Suspicious, investigate
- LOW - Note for context

**Use Cases:**
- Organization-specific threats
- Known malware signatures
- Custom application errors
- Environment-specific patterns

---

### Option 18: List Available Patterns

**Purpose:** View all pattern files and their contents

**What It Shows:**
```
Pattern Files:
══════════════

File: macos_security_patterns.txt
Patterns: 62
Categories: Security (45), Malware (10), Network (7)
```

**Use Cases:**
- Review detection capabilities
- Check pattern coverage
- Identify gaps
- Audit detection rules

---

### Option 19: Quick Scan (No Investigation)

**Purpose:** Run log analysis without creating investigation

**Features:**
- Fast triage scan
- No investigation folder created
- Results in current directory
- Uses default patterns

**When to Use:**
- Quick check for obvious issues
- Initial triage
- Testing pattern files
- One-off analysis

**Output:**
```
Current Directory:
├── log_analysis_TIMESTAMP.json
├── log_analysis_TIMESTAMP.csv
└── log_analysis_TIMESTAMP.md
```

**Best Practices:**
- Use for quick checks only
- Create investigation for serious cases
- Save results if findings detected
- Follow up with full investigation

---

## 📊 **Log Analysis**

### Option 8: Run Log Analysis

**Purpose:** Scan macOS logs for security events, malware, crashes

**Requirements:**
- Active investigation
- Configured log directories (Option 13)
- Configured pattern files (Option 14)

**What It Analyzes:**
```
System Logs:
• /var/log/system.log
• /var/log/install.log
• /var/log/wifi.log

User Logs:
• ~/Library/Logs/
• Application logs
• Crash reports

Diagnostic Reports:
• ~/Library/Logs/DiagnosticReports/
• /Library/Logs/DiagnosticReports/
```

**Detection Capabilities:**
- **Security Events (60+):**
  - Authentication failures
  - Authorization violations
  - sudo usage
  - Firewall blocks
  - Unauthorized access attempts

- **Malware Signatures (100+):**
  - Known malware names
  - Suspicious processes
  - Malware indicators
  - Behavioral patterns

- **Crash Patterns (50+):**
  - Segmentation faults
  - Memory errors
  - Exception types
  - Panic patterns

**Process:**
1. Scans all configured directories
2. Applies pattern matching
3. Filters with whitelists
4. Classifies by severity
5. Generates multi-format output

**Output:**
```
Investigations/CASE-001/artifacts/logs/
├── log_analysis_CASE-001_TIMESTAMP.json
├── log_analysis_CASE-001_TIMESTAMP.json.sha256
├── log_analysis_CASE-001_TIMESTAMP.csv
└── log_analysis_CASE-001_TIMESTAMP.md
```

**Performance:**
- Typical scan: 30-120 seconds
- Depends on: log volume, pattern count
- Progress indicators shown
- Verbose mode available

**Best Practices:**
- Configure whitelists before scanning
- Use multiple pattern files
- Review HIGH severity first
- Cross-reference with other evidence

---

### Option 9: View Analysis Results

**Purpose:** Review log analysis findings

**What It Shows:**
```
╔════════════════════════════════════╗
║     LOG ANALYSIS RESULTS           ║
╚════════════════════════════════════╝

Analysis Run: 2025-12-30T15:30:00Z

SUMMARY
• Total Files Scanned: 245
• Total Lines Analyzed: 1,247,382
• Findings: 127
  - HIGH: 15
  - MEDIUM: 45
  - LOW: 67

TOP FINDINGS
[HIGH] Authentication failure (15 occurrences)
[HIGH] Malware signature detected (3 occurrences)
[MEDIUM] sudo usage (28 occurrences)
```

**Features:**
- Sorted by severity
- Shows counts and patterns
- Links to full reports
- Easy navigation

**Best Practices:**
- Review immediately after analysis
- Investigate HIGH findings first
- Look for patterns in counts
- Cross-reference timestamps

---

## 💻 **Runtime Monitoring**

### Option 20: Process Memory Snapshot (Single PID)

**Purpose:** Deep analysis of a single running process

**What It Captures:**
```
Process Information:
• PID, name, path
• Command line arguments
• Open files and network connections
• Memory usage and threads
• Parent process relationship
```

**Use Cases:**
- Suspicious process detected
- Malware analysis
- Memory forensics
- Process behavior analysis

**Output:**
```
runtime_monitoring/process/
└── process_memory_PID_TIMESTAMP.json
```

**Best Practices:**
- Use Activity Monitor to find PID
- Capture immediately when suspicious
- Multiple snapshots for comparison
- Analyze open files and connections

---

### Option 21: System Process Triage (All Processes)

**Purpose:** Snapshot of ALL running processes

**What It Captures:**
```
For Each Process:
• PID, name, executable path
• User ownership
• CPU and memory usage
• Start time
• Parent-child relationships
```

**Use Cases:**
- System baseline
- Before/after comparison
- Malware detection
- Incident response

**Output:**
```
runtime_monitoring/system/
└── system_processes_TIMESTAMP.json
```

**Typical Results:**
- 100-300 processes captured
- Complete system state
- JSON format for parsing
- Timestamp for correlation

**Best Practices:**
- Capture baseline when system clean
- Compare with suspect snapshots
- Look for unusual processes
- Check parent-child relationships

---

### Option 22: Network Capture

**Purpose:** Capture network connections for 30-60 seconds

**What It Captures:**
```
Network Connections:
• Local/remote IP addresses
• Local/remote ports
• Protocol (TCP/UDP)
• Process name and PID
• Connection state
```

**Duration:** Configurable (default 30s, recommended 30-60s)

**Why 30-60 Seconds:**
- Catches malware beaconing (15-30s intervals)
- Completes connection lifecycles
- Captures DNS lookups
- Shows persistent connections

**Output:**
```
runtime_monitoring/network/
└── network_capture_TIMESTAMP.json
```

**Use Cases:**
- Detect C2 communications
- Identify data exfiltration
- Map network activity
- Correlate with malware

**Best Practices:**
- Use 30-60 second duration
- Multiple captures for patterns
- Look for unusual IPs/ports
- Cross-reference with processes

---

### Option 23: Combined Process + Network (Single PID)

**Purpose:** Deep dive on specific process with network context

**What It Captures:**
- Process memory snapshot
- Network connections for that process
- Associated files and resources
- Complete behavioral picture

**Use Cases:**
- Suspected malware investigation
- Data theft analysis
- Network abuse investigation

**Output:**
```
runtime_monitoring/combined/
├── process_PID_TIMESTAMP.json
└── network_PID_TIMESTAMP.json
```

**Best Practices:**
- Use when process identified as suspicious
- Capture before terminating
- Analyze network patterns
- Document for correlation

---

### Option 24: System + Network Capture (Complete State)

**Purpose:** Full system snapshot with network activity

**What It Captures:**
- All running processes
- All network connections
- Complete system state
- Network activity over time

**Duration:** Process snapshot + 60s network capture

**Use Cases:**
- Incident response
- System compromise
- Complete forensic capture
- Baseline establishment

**Output:**
```
runtime_monitoring/system_state/
├── system_processes_TIMESTAMP.json
├── network_capture_TIMESTAMP.json
└── system_state_TIMESTAMP.json (combined)
```

**File Size:** Typically 500KB - 2MB

**Best Practices:**
- Use immediately upon incident detection
- Create baseline for comparison
- Capture multiple times during incident
- Preserve for timeline correlation

---

## 📂 **Artifact Collection**

### Option 25: Home Directory Analysis

**Purpose:** Analyze user home directory for evidence

**What It Analyzes:**
```
Shell History:
• ~/.bash_history
• ~/.zsh_history
• Command execution timeline

Downloads:
• ~/Downloads/
• File listings with timestamps
• Suspicious file detection

Configuration Files:
• ~/.ssh/ (SSH keys, known_hosts)
• ~/.aws/ (AWS credentials)
• Application configs
```

**What It Detects:**
- Suspicious commands
- File downloads
- Configuration changes
- Credential files

**Output:**
```
artifacts/home_directory/
├── home_analysis_TIMESTAMP.json
├── home_analysis_TIMESTAMP.csv
└── home_analysis_TIMESTAMP.md
```

**Privacy Note:**
- Captures metadata only
- No file content read
- Respects user privacy
- Court-admissible format

**Best Practices:**
- Review Downloads carefully
- Check shell history for suspicious commands
- Look for credential files
- Note configuration changes

---

## 🌐 **Browser Forensics**

### Overview
All four major macOS browsers supported with consistent interface:
- Chrome (Option 38)
- Safari (Option 39)
- Firefox (Option 40)
- Brave (Option 41)

### Common Features
✓ URL history extraction  
✓ Download history  
✓ Suspicious URL detection  
✓ Whitelist filtering  
✓ Suspicious-only mode  
✓ Timeline JSON format  
✓ Multi-format output (JSON/CSV/MD)  
✓ SHA-256 hashing  

---

### Option 38: Chrome History Analysis

**Database:** `~/Library/Application Support/Google/Chrome/Default/History`

**What It Extracts:**
```
URL History:
• Complete browsing history
• Visit counts and timestamps
• Page titles

Downloads:
• Downloaded files
• Source URLs
• File paths and sizes

Search Queries:
• Search terms entered
• Search engine used
• Timestamps

Extensions:
• Installed extensions
• Extension IDs
• Versions
```

**Unique Chrome Features:**
- Incognito mode detection (can detect sessions occurred)
- Chrome sync artifact detection
- Extension manifest analysis

**Timestamp Format:** Microseconds since 1601-01-01 (WebKit epoch)

**Output:**
```
browser_forensics/chrome/
├── chrome_history_CASE-001_TIMESTAMP.json
├── chrome_history_CASE-001_TIMESTAMP.json.sha256
├── chrome_history_CASE-001_TIMESTAMP.csv
└── chrome_history_CASE-001_TIMESTAMP.md
```

**Typical Results:**
- 5,000 - 100,000 URLs
- Processing: 5-30 seconds
- Output: 1-10 MB

**Suspicious-Only Mode:**
- **Yes:** Only suspicious URLs in output (~15-50 findings)
- **No:** Complete timeline (all URLs + suspicious flagged)

**Best Practices:**
- Use whitelist to reduce false positives
- Suspicious-only for quick triage
- Complete timeline for alibi verification
- Review downloads carefully

---

### Option 39: Safari History Analysis

**Database:** `~/Library/Safari/History.db`

**What It Extracts:**
```
URL History:
• Complete browsing history
• Visit counts and timestamps
• Page titles

Downloads:
• Downloads.plist (binary plist format)
• File paths and URLs
• Download timestamps
```

**Unique Safari Features:**
- Native macOS integration
- iCloud sync artifacts
- Reading list extraction
- Cocoa epoch timestamps

**Timestamp Format:** Seconds since 2001-01-01 (Cocoa/Apple epoch)

**Output:**
```
browser_forensics/safari/
├── safari_history_CASE-001_TIMESTAMP.json
├── safari_history_CASE-001_TIMESTAMP.json.sha256
├── safari_history_CASE-001_TIMESTAMP.csv
└── safari_history_CASE-001_TIMESTAMP.md
```

**Safari Users:**
- Typically 5,000 - 30,000 URLs
- Cleaner browsing patterns
- iOS device sync data

**Limitations:**
- No cookie content extraction (yet)
- No extension detection
- Private browsing leaves no traces

**Best Practices:**
- Check Downloads.plist separately
- Look for iCloud sync artifacts
- Cross-reference with iOS devices
- Consider reading list entries

---

### Option 40: Firefox History Analysis

**Database:** `~/Library/Application Support/Firefox/Profiles/*/places.sqlite`

**What It Extracts:**
```
URL History:
• Complete browsing history
• Visit counts and timestamps
• Page titles

Downloads:
• Download history from annotations
• File URLs and paths

Search Queries:
• keyword_search_terms table
• Search timestamps

Form History (Unique!):
• formhistory.sqlite database
• Autofill data (usernames, emails)
• Usage counts and timestamps
```

**Unique Firefox Features:**
- **Form history extraction** (unique to Firefox!)
- Auto-profile detection
- Privacy tool awareness
- Open source forensics

**Timestamp Format:** Microseconds since 1970-01-01 (Unix epoch)

**Form History Example:**
```json
{
  "fieldname": "username",
  "value": "alice@example.com",
  "times_used": 5,
  "first_used": "2025-12-01T10:00:00Z",
  "last_used": "2025-12-30T15:00:00Z"
}
```

**Output:**
```
browser_forensics/firefox/
├── firefox_history_CASE-001_TIMESTAMP.json
├── firefox_history_CASE-001_TIMESTAMP.json.sha256
├── firefox_history_CASE-001_TIMESTAMP.csv
└── firefox_history_CASE-001_TIMESTAMP.md
```

**Firefox Users:**
- Privacy-conscious demographics
- Smaller profiles (frequent clearing)
- Developer/tech-savvy users

**Best Practices:**
- Review form history for usernames/emails
- Look for privacy tool usage
- Check for frequent history clearing
- Cross-reference with developer sites

---

### Option 41: Brave History Analysis

**Database:** `~/Library/Application Support/BraveSoftware/Brave-Browser/Default/History`

**What It Extracts:**
```
URL History:
• Complete browsing history
• Visit counts and timestamps
• Page titles

Downloads:
• Downloaded files
• Source URLs and paths

Search Queries:
• Search terms
• Timestamps

Extensions:
• Installed Brave extensions
• Extension details
```

**Unique Brave Features:**
- Chromium-based (same structure as Chrome)
- Crypto-aware whitelist (exchanges, wallets)
- Privacy-focused user base
- BAT rewards tracking

**Timestamp Format:** Microseconds since 1601-01-01 (WebKit epoch)

**Brave User Demographics:**
- Privacy-conscious
- Cryptocurrency interested
- Tech-savvy
- Security-aware

**Brave Whitelist Includes:**
- Crypto exchanges (Coinbase, Binance, Kraken)
- Crypto wallets (MetaMask, Ledger)
- Blockchain tools (Etherscan, OpenSea)
- Privacy tools (Tor, ProtonMail, DuckDuckGo)

**Output:**
```
browser_forensics/brave/
├── brave_history_CASE-001_TIMESTAMP.json
├── brave_history_CASE-001_TIMESTAMP.json.sha256
├── brave_history_CASE-001_TIMESTAMP.csv
└── brave_history_CASE-001_TIMESTAMP.md
```

**Best Practices:**
- Review crypto-related activity
- Check privacy tool usage
- Look for VPN/Tor usage
- Cross-reference with blockchain explorers

---

### Browser Comparison

| Browser | Users | Profile Size | Special Features |
|---------|-------|--------------|------------------|
| Chrome | Most common | Largest | Extensions, sync, incognito detection |
| Safari | macOS default | Medium | iCloud sync, iOS integration |
| Firefox | Privacy users | Smaller | Form history, open source |
| Brave | Crypto/privacy | Small-medium | Crypto wallets, privacy tools |

---

## 🔍 **Search & Reporting**

### Option 42: Search Analysis by Date Range

**Purpose:** Query ALL investigation artifacts for events in a specific time window

**What It Searches:**
```
✓ Browser histories (Chrome, Safari, Firefox, Brave)
✓ Log analyses
✓ Process snapshots
✓ Network captures
✓ Home directory scans
✓ System state captures
✓ ANY JSON artifact with timestamps
```

**How It Works:**
1. Recursively finds all JSON files in `artifacts/`
2. Parses timestamps from various formats
3. Filters events within date range
4. Aggregates results by source type
5. Outputs unified timeline

**Supported Date Formats:**
```
Date only:     2025-12-30
               (assumes 00:00:00 UTC)

ISO with Z:    2025-12-30T15:30:00Z

ISO without Z: 2025-12-30T15:30:00
               (assumes UTC)
```

**Use Cases:**
```
Incident Timeline:
"What happened between 2:00 PM - 4:00 PM on Dec 30?"
→ Browser visits + log events + process changes + network

Alibi Verification:
"Show all activity during alleged incident"
→ Complete timeline proves/disproves claims

Pattern Analysis:
"Compare business hours vs. after-hours activity"
→ Behavioral analysis across timeframes

Correlation:
"What was happening around malware execution?"
→ Build complete narrative
```

**Output:**
```
searches/
├── daterange_search_CASE-001_TIMESTAMP.json
└── daterange_search_CASE-001_TIMESTAMP.md
```

**JSON Output Structure:**
```json
{
  "search_metadata": {
    "date_range": {
      "start": "2025-12-30T14:00:00Z",
      "end": "2025-12-30T16:00:00Z"
    }
  },
  "statistics": {
    "files_scanned": 12,
    "events_found": 127,
    "sources": {
      "Chrome Browser": 58,
      "Log Analysis": 42,
      "Process Snapshot": 22,
      "Network Capture": 5
    }
  },
  "results": [...]
}
```

**Markdown Report:**
- Organized by source type
- Chronological within each source
- Relevant fields extracted
- Easy to read and share

**Performance:**
- Typical: 5-15 seconds
- Depends on artifact count
- Scales well to large investigations

**Best Practices:**
- Run multiple analyses first
- Be specific with time windows
- Review by source type
- Cross-reference findings
- Generate report after search

---

### Option 43: Generate Investigation Status Report

**Purpose:** Create comprehensive investigation summary

**What It Includes:**
```
Investigation Overview:
• Case ID and description
• Investigator and dates
• Current status

Analysis Summary:
• All analyses run with timestamps
• Result counts and severity
• Files generated

Key Findings:
• HIGH severity findings (top 20)
• Pattern distribution
• Timeline highlights

Investigator Notes:
• All notes chronologically
• Timestamped entries
• Investigation narrative

Evidence Inventory:
• All artifacts collected
• File counts and sizes
• SHA-256 hashes
```

**Output:**
```
reports/
├── status_report_CASE-001_TIMESTAMP.md
└── status_report_CASE-001_TIMESTAMP.json
```

**Report Sections:**
```markdown
# Investigation Status Report

## Case Information
- Case ID: CASE-2025-001
- Status: ACTIVE
- Created: 2025-12-30T10:00:00Z

## Analysis Summary
- Analyses Run: 8
- Total Findings: 245
  - HIGH: 23
  - MEDIUM: 89
  - LOW: 133

## Key Findings
[HIGH] Malware detected: evil.exe
[HIGH] Unauthorized access attempt
[HIGH] Data exfiltration to 192.168.1.100

## Timeline
2025-12-30T14:00:00Z - Malware downloaded
2025-12-30T14:05:00Z - Process executed
2025-12-30T14:10:00Z - Network connection to C2

## Investigator Notes
[All chronological notes included]

## Evidence Files
[Complete inventory with hashes]
```

**When to Generate:**
- After major analysis runs
- Before stakeholder updates
- Daily for active investigations
- At case closure

**Use Cases:**
- Stakeholder updates
- Court documentation
- Investigation audit
- Progress tracking
- Handoff to other investigators

**Best Practices:**
- Generate regularly
- Review before distribution
- Include in case file
- Update as investigation progresses
- Professional presentation

---

## 🔧 **Standalone Tools**

All dashboard features are also available as standalone command-line tools:

### Log Directory Analyzer
```bash
./log_directory_analyzer.py \
  -d ~/Library/Logs /Library/Logs \
  -p macos_security_patterns.txt \
  -o log_analysis/ \
  --case-id CASE-001
```

### Browser History Analyzers
```bash
# Chrome
./chrome_history_analyzer.py -w chrome_whitelist.txt --case-id CASE-001

# Safari  
./safari_history_analyzer.py -w safari_whitelist.txt --case-id CASE-001

# Firefox
./firefox_history_analyzer.py -w firefox_whitelist.txt --case-id CASE-001

# Brave
./brave_history_analyzer.py -w brave_whitelist.txt --case-id CASE-001
```

### Date Range Search
```bash
./date_range_search.py \
  -i Investigations/CASE-001 \
  -s "2025-12-30T14:00:00Z" \
  -e "2025-12-30T16:00:00Z" \
  --case-id CASE-001
```

### Process Snapshot
```bash
./process_memory_snapshot.py -p 1234 -o snapshots/ --case-id CASE-001
```

### Network Capture
```bash
./network_capture.py -d 60 -o captures/ --case-id CASE-001
```

### Home Directory Analysis
```bash
./home_directory_analyzer.py -o analysis/ --case-id CASE-001
```

**All tools support:**
- `-h` for help
- `-v` for verbose output
- `--case-id` for tracking
- `-o` for output directory

---

## 📄 **Output Formats**

### JSON Format
**Purpose:** Machine-readable, complete data

**Structure:**
```json
{
  "analysis_metadata": {
    "tool": "chrome_history_analyzer",
    "version": "1.0",
    "analysis_timestamp_utc": "2025-12-30T15:30:00Z",
    "case_id": "CASE-001"
  },
  "summary": {
    "total_urls": 45234,
    "suspicious_urls": 15
  },
  "findings": [...],
  "timeline": {
    "events": [...]
  }
}
```

**Uses:**
- SIEM integration
- Data analysis
- Timeline correlation
- Programmatic processing

---

### CSV Format
**Purpose:** Spreadsheet import, database loading

**Structure:**
```csv
url,title,visit_count,last_visit_time,suspicious,severity,category,reason
https://example.com,Example,5,2025-12-30T15:00:00Z,Yes,HIGH,Malware,Malware signature
```

**Uses:**
- Excel analysis
- Database import
- Quick filtering
- Pivot tables

---

### Markdown Format
**Purpose:** Human-readable reports

**Structure:**
```markdown
# Chrome History Analysis Report

**Case ID:** CASE-001
**Analysis Timestamp:** 2025-12-30T15:30:00Z

## Summary
- Total URLs: 45,234
- Suspicious URLs: 15

## HIGH Severity (5)
**Malicious Download**
- URL: https://evil.com/malware.exe
- Last Visit: 2025-12-30T14:23:00Z
```

**Uses:**
- Investigation reports
- Stakeholder updates
- Court documentation
- Human review

---

### SHA-256 Format
**Purpose:** Evidence integrity verification

**Structure:**
```
a1b2c3d4e5f6... chrome_history_CASE-001_20251230.json
```

**Uses:**
- Verify file integrity
- Court admissibility
- Chain of custody
- Tampering detection

**Verification:**
```bash
shasum -a 256 -c chrome_history_CASE-001_20251230.json.sha256
```

---

## 📝 **Pattern Files**

### Format
```
# Comment
PATTERN_TYPE:pattern|CATEGORY:category|SEVERITY:level

# Examples
PARTIAL:malware.exe|CATEGORY:Malware|SEVERITY:HIGH
REGEX:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|CATEGORY:Network|SEVERITY:MEDIUM
```

### Pattern Types

**PARTIAL:** Substring matching
```
PARTIAL:authentication failure
→ Matches any line containing "authentication failure"
```

**REGEX:** Regular expression
```
REGEX:error\s+\d+
→ Matches "error" followed by number
```

### Categories
- Security - Authentication, authorization, access
- Malware - Known malware, suspicious processes
- Crash - Segfaults, exceptions, panics
- Error - System errors, failures
- Warning - Warnings, alerts
- Network - Network events, connections
- Custom - User-defined categories

### Severity Levels
- **HIGH** - Immediate attention, critical findings
- **MEDIUM** - Investigate further, suspicious
- **LOW** - Note for context, informational

### Best Practices
```
✓ One pattern per line
✓ Use comments for organization
✓ Test patterns before deployment
✓ Start with PARTIAL, use REGEX when needed
✓ Be specific to reduce false positives
✓ Group related patterns
✓ Document pattern purpose
```

---

## 🎯 **Whitelist System**

### Format
```
DOMAIN:domain.com|CATEGORY:Whitelisted|REASON:Description
EXTENSION:.ext|CATEGORY:Whitelisted|REASON:Description
```

### Examples
```
DOMAIN:apple.com|CATEGORY:Whitelisted|REASON:Apple services
EXTENSION:.pdf|CATEGORY:Whitelisted|REASON:PDF document
```

### How It Works
1. During analysis, each finding is checked
2. If domain/extension matches whitelist, filtered out
3. Reduces false positives by ~80%
4. Original data preserved, filtering on output

### Browser-Specific Whitelists

**Chrome (100+ entries):**
- Google services
- Chrome infrastructure
- Common web services
- Extensions (.crx)

**Safari (100+ entries):**
- Apple infrastructure
- iCloud services
- macOS-specific domains
- Native formats (.heic, .m4v)

**Firefox (100+ entries):**
- Mozilla infrastructure
- Privacy tools
- Open source formats
- Add-ons (.xpi)

**Brave (120+ entries):**
- Brave infrastructure
- Cryptocurrency exchanges
- Blockchain tools
- Privacy services
- Decentralized web

### Best Practices
```
✓ Always use whitelists
✓ Select browser-specific lists
✓ Review whitelists for your environment
✓ Create custom whitelists if needed
✓ Update regularly
✓ Document whitelist decisions
```

---

## 💡 **Tips & Best Practices**

### Investigation Workflow
1. Create investigation (Option 1)
2. Configure tools (Options 13-15)
3. Run analyses (Options 8, 20-25, 38-41)
4. Search timelines (Option 42)
5. Add notes (Option 10)
6. Generate report (Option 43)
7. Close investigation (Option 11)

### Evidence Collection
- Work from copies when possible
- Verify SHA-256 hashes
- Document everything
- Preserve timestamps
- Maintain chain of custody

### Analysis Strategy
- Start with log analysis
- Add browser forensics
- Capture runtime state
- Search by date range
- Cross-reference findings

### Reporting
- Generate reports early and often
- Review before distribution
- Include investigator notes
- Attach evidence inventory
- Professional presentation

---

## 🆘 **Getting Help**

**Documentation:**
- Quick Start: `QUICKSTART.md`
- This Reference: `TOOL_REFERENCE.md`
- Project Info: `README.md`

**Each Tool:**
```bash
./tool_name.py -h
→ Shows help and examples
```

**Dashboard:**
- Type option number
- Read on-screen prompts
- Check investigation folder for outputs

**Common Issues:**
- See QUICKSTART.md "Troubleshooting"
- Check file permissions
- Verify Python version (3.8+)
- Review logs for errors

---

**Backwater Forensics • Apple FORENSICS**  
*Victim Investigator Approach*  
*Professional macOS Forensic Analysis*

Version 1.0 • December 2025  
Complete Tool Reference

For quick start: See QUICKSTART.md  
For project info: See README.md  
For license: See LICENSE.md
