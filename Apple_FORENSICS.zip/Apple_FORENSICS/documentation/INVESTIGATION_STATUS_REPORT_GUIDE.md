# Investigation Status Report - Feature Documentation
## Aggregate Analysis & Multi-Format Reporting

**Date:** December 30, 2025  
**Feature:** Investigation Status Report (Option 12)  
**Status:** ✅ FULLY FUNCTIONAL with PDF Support  
**Location:** Main Menu → Option 12 (when investigation loaded)

---

## 🎯 Feature Overview

The **Investigation Status Report** automatically aggregates ALL analysis data from an investigation and generates comprehensive reports in multiple formats including **PDF**.

### What It Does

Scans the entire investigation directory and:
- ✅ Aggregates findings from all tools run
- ✅ Compiles severity statistics
- ✅ Summarizes category breakdown
- ✅ Tracks timeline of collection activities
- ✅ Provides actionable recommendations
- ✅ Generates reports in JSON, CSV, Markdown, and **PDF**

---

## 📊 What Gets Aggregated

### Tools Scanned:

1. **Log Directory Analyzer**
   - Location: `investigations/CASE-ID/log_analysis/`
   - Aggregates: Findings, severities, categories
   - Tracks: Analysis timestamps, artifact timestamps

2. **Home Directory Analyzer**
   - Location: `investigations/CASE-ID/artifacts/home_directory/`
   - Aggregates: Shell history findings, suspicious files
   - Tracks: Tool versions, timestamp sources

3. **Network Capture**
   - Location: `investigations/CASE-ID/network_captures/`
   - Aggregates: PCAP metadata, packet counts
   - Tracks: Capture duration, file sizes

4. **System + Network Capture**
   - Location: `investigations/CASE-ID/system_network_captures/`
   - Aggregates: Process snapshots, system changes
   - Tracks: New/stopped processes, memory changes

---

## 📋 Report Contents

### Case Information Section

```
Case ID:             CASE-20251230-001
Investigator:        John Smith
Description:         Suspected malware infection
Status:              Active
Subject Name:        Jane Doe
Subject Device:      MacBook-Pro-2024
Report Generated:    2025-12-30T17:30:00Z
```

### Analysis Summary

```
Tools Run:           4
Total Findings:      127
HIGH Severity:       15
MEDIUM Severity:     42
LOW Severity:        70
```

### Severity Breakdown

Shows count of findings by severity level:
- HIGH
- MEDIUM
- LOW

### Category Breakdown

Top 10 most common finding categories:
- Security Events
- Crash Reports
- Anti-Forensics
- Malware Indicators
- Network Activity
- Authentication Failures
- etc.

### Tools Executed

For each tool run:
- Tool name
- Timestamp (UTC) when executed
- Findings count
- Data file location
- Tool version
- Additional details (packet counts, process changes, etc.)

### Recommendations

Intelligent suggestions based on what's been analyzed:
- "Run Log Analysis to check for security events..."
- "Run Home Directory Analysis to check shell history..."
- "PRIORITY: Investigate 15 HIGH severity findings immediately"

---

## 📑 Output Formats

### 1. JSON Format

**Structure:**
```json
{
  "case_id": "CASE-20251230-001",
  "investigator": "John Smith",
  "timestamp_utc": "2025-12-30T17:30:00Z",
  "timezone": "UTC",
  "tools_run_count": 4,
  "total_findings": 127,
  "severity_summary": {
    "HIGH": 15,
    "MEDIUM": 42,
    "LOW": 70
  },
  "category_summary": {
    "Security": 25,
    "Crash": 18,
    ...
  },
  "tools_run": [
    {
      "tool": "Log Directory Analyzer",
      "timestamp": "2025-12-30T15:00:00Z",
      "findings_count": 85,
      "file": "log_analysis/log_analysis_20251230_150000.json",
      "tool_version": "1.1"
    },
    ...
  ],
  "analysis_timestamps": [
    {
      "tool": "Log Directory Analyzer",
      "timestamp": "2025-12-20T14:30:00Z",
      "timestamp_source": "log_entry",
      "severity": "HIGH",
      "category": "Authentication"
    },
    ...
  ],
  "recommendations": [
    "Run Network Capture to monitor active connections",
    "PRIORITY: Investigate 15 HIGH severity findings immediately"
  ]
}
```

**Use Case:** Import into SIEM, programmatic analysis, database storage

---

### 2. CSV Format

**Structure:**
```csv
Investigation Status Report

Case ID,CASE-20251230-001
Investigator,John Smith
Description,Suspected malware infection
Status,Active
Report Generated (UTC),2025-12-30T17:30:00Z

Tools Run,4
Total Findings,127

Severity Summary
Severity,Count
HIGH,15
MEDIUM,42
LOW,70

Tools Executed
Tool,Timestamp (UTC),Findings,File
Log Directory Analyzer,2025-12-30T15:00:00Z,85,log_analysis/...
Home Directory Analyzer,2025-12-30T16:00:00Z,42,artifacts/home_directory/...
```

**Use Case:** Excel analysis, spreadsheet processing, quick review

---

### 3. Markdown Format

**Structure:**
```markdown
# Investigation Status Report

## Case Information

- **Case ID:** CASE-20251230-001
- **Investigator:** John Smith
- **Description:** Suspected malware infection
- **Status:** Active
- **Subject Name:** Jane Doe
- **Subject Device:** MacBook-Pro-2024
- **Report Generated (UTC):** 2025-12-30T17:30:00Z

## Analysis Summary

- **Tools Run:** 4
- **Total Findings:** 127

### Severity Breakdown

- **HIGH:** 15
- **MEDIUM:** 42
- **LOW:** 70

### Top Categories

- **Security:** 25
- **Crash:** 18
- **Anti-Forensics:** 12

## Tools Executed

### Log Directory Analyzer

- **Timestamp (UTC):** 2025-12-30T15:00:00Z
- **Findings:** 85
- **Data File:** `log_analysis/log_analysis_20251230_150000.json`

[... more tools ...]

## Recommendations

1. Run Network Capture to monitor active connections
2. PRIORITY: Investigate 15 HIGH severity findings immediately

---

*Generated by Apple FORENSICS Dashboard*
```

**Use Case:** Human-readable reports, documentation, case files

---

### 4. PDF Format ⭐

**Professional Layout:**
- Professional forensic report formatting
- Color-coded headers
- Organized tables with proper styling
- Multi-page support
- Ready for court documentation

**Contents:**
- Cover page with case information
- Analysis summary tables
- Severity breakdown (styled table)
- Category breakdown (top 10, styled table)
- Tools executed (detailed breakdown)
- Recommendations section
- Professional footer

**Use Case:** Court submission, stakeholder reports, case documentation

---

## 🚀 How to Use

### Step 1: Load Investigation

```
Main Menu → Option 2: Load Existing Investigation
Select your case: CASE-20251230-001
```

### Step 2: Generate Status Report

```
Main Menu → Option 12: Generate Investigation Status Report
```

### Step 3: Choose Format

```
Select Report Format:
  1. All Formats (JSON + CSV + Markdown + PDF)
  2. JSON only
  3. CSV only
  4. Markdown only
  5. PDF only

Choice (1-5): 1
```

### Step 4: View Results

Reports saved to:
```
~/Apple_FORENSICS/investigations/CASE-20251230-001/reports/
  - status_report_20251230_173000.json
  - status_report_20251230_173000.csv
  - status_report_20251230_173000.md
  - status_report_20251230_173000.pdf
```

---

## 📊 Example Output

### Console Display

```
INVESTIGATION STATUS REPORT
═══════════════════════════════════════════════════════════════════

Analyzing investigation: CASE-20251230-001

Select Report Format:
  1. All Formats (JSON + CSV + Markdown + PDF)
  2. JSON only
  3. CSV only
  4. Markdown only
  5. PDF only

Choice (1-5): 1

Scanning investigation directory...

✓ JSON: status_report_20251230_173000.json
✓ CSV: status_report_20251230_173000.csv
✓ Markdown: status_report_20251230_173000.md
✓ PDF: status_report_20251230_173000.pdf

Status report generated: 4 file(s)
Location: investigations/CASE-20251230-001/reports

Investigation Summary:
  Tools Run: 4
  Total Findings: 127
  HIGH Severity: 15
  MEDIUM Severity: 42
  LOW Severity: 70

Top Categories:
  Security: 25
  Crash: 18
  Anti-Forensics: 12
  Malware: 8
  Network: 6

Press Enter to continue...
```

---

## 🔍 What Gets Tracked

### Per Tool Analysis

**Log Directory Analyzer:**
- Analysis timestamp (UTC)
- Findings count
- Severity breakdown
- Category distribution
- Artifact timestamps (timeline)
- Timestamp sources (confidence)
- Tool version

**Home Directory Analyzer:**
- Analysis timestamp (UTC)
- Findings count (commands, files, SSH keys)
- Severity breakdown
- Category distribution
- Artifact timestamps
- Timestamp sources
- Tool version

**Network Capture:**
- Capture start/end (UTC)
- Duration (seconds)
- Packet count
- File size (MB)
- PCAP file location
- SHA-256 hash

**System + Network Capture:**
- Capture start/end (UTC)
- Duration (seconds)
- New processes detected
- Stopped processes
- Memory changes >10MB
- Snapshot count
- Process state changes

---

## 💡 Use Cases

### 1. Daily Investigation Review

```bash
# Quick status check
./apple_forensics_dashboard.py
→ Load investigation
→ Option 12 → Format 4 (Markdown)
→ Review findings summary
```

### 2. Stakeholder Updates

```bash
# Professional report
./apple_forensics_dashboard.py
→ Load investigation
→ Option 12 → Format 5 (PDF)
→ Email PDF to stakeholders
```

### 3. Court Documentation

```bash
# Complete package
./apple_forensics_dashboard.py
→ Load investigation
→ Option 12 → Format 1 (All formats)
→ Submit PDF + JSON to court
```

### 4. SIEM Integration

```bash
# Machine-readable data
./apple_forensics_dashboard.py
→ Load investigation
→ Option 12 → Format 2 (JSON)
→ Import to Splunk/ELK
```

### 5. Timeline Analysis

```bash
# Extract event timeline
cat status_report_*.json | \
  jq '.analysis_timestamps[] | {time, tool, severity, category}' | \
  sort -k 'time'
```

---

## 🎯 Smart Recommendations Engine

The report includes intelligent recommendations based on:

### What's Missing

- ❌ "Run Log Analysis to check for security events..."
- ❌ "Run Home Directory Analysis to check shell history..."
- ❌ "Run Network Capture to monitor active connections..."

### What's Critical

- 🚨 "PRIORITY: Investigate 15 HIGH severity findings immediately"

### What's Next

Based on findings, suggests logical next steps in investigation workflow.

---

## 🔧 Technical Details

### Dependencies

**Python Libraries:**
```python
reportlab       # PDF generation
pathlib         # File operations
json            # JSON parsing
csv             # CSV generation
datetime        # UTC timestamps
collections     # Data aggregation
```

**Installation (if needed):**
```bash
pip3 install reportlab --break-system-packages
```

### File Locations

**Investigation Directory Structure:**
```
investigations/CASE-ID/
├── log_analysis/              # Log analyzer outputs
├── artifacts/
│   └── home_directory/        # Home dir analyzer outputs
├── network_captures/          # Network PCAP + metadata
├── system_network_captures/   # System state snapshots
└── reports/                   # ← Status reports go here
    ├── status_report_*.json
    ├── status_report_*.csv
    ├── status_report_*.md
    └── status_report_*.pdf
```

### UTC Timestamps

All timestamps in reports are **UTC** with 'Z' suffix:
```
2025-12-30T17:30:00Z  ← Unambiguous, globally synchronized
```

Compatible with updated timestamp fixes in:
- log_directory_analyzer.py v1.1
- home_directory_analyzer.py v1.1
- network_capture.py v1.1
- system_network_capture.py v1.1

---

## ✅ Quality Assurance

### Backward Compatibility

Handles both old and new field names:
```python
# Works with v1.0 tools
timestamp = data.get('analysis_timestamp')

# Works with v1.1 tools
timestamp = data.get('analysis_timestamp_utc')

# Always gets a timestamp
timestamp = timestamp or 'unknown'
```

### Error Handling

```python
try:
    # Parse JSON
    with open(json_file) as f:
        data = json.load(f)
except Exception as e:
    print(f"Warning: Could not parse {json_file.name}: {e}")
    # Continues with other files
```

Reports never fail due to one corrupted file.

---

## 📈 Enhancement Summary

### What Was Enhanced:

1. ✅ **New Timestamp Field Support**
   - Handles `analysis_timestamp_utc`
   - Handles `artifact_timestamp`
   - Handles `timestamp_source`
   - Backward compatible with v1.0

2. ✅ **Timeline Tracking**
   - Extracts artifact timestamps
   - Records timestamp sources
   - Builds chronological timeline
   - Tracks confidence levels

3. ✅ **Category Breakdown**
   - Added to PDF report (top 10)
   - Added to console output (top 5)
   - Already in JSON/CSV/Markdown

4. ✅ **Tool Version Tracking**
   - Records tool version from metadata
   - Helps with compatibility
   - Documents analysis provenance

---

## 🎉 Ready to Use!

The Investigation Status Report feature is **fully functional** and includes:

✅ **4 output formats** (JSON, CSV, Markdown, PDF)  
✅ **Aggregates all tools** (Log, Home, Network, System)  
✅ **Professional PDF reports** (court-ready)  
✅ **Smart recommendations** (what to do next)  
✅ **UTC timestamps** (globally synchronized)  
✅ **Backward compatible** (works with v1.0 and v1.1 tools)  
✅ **Error resilient** (handles corrupted files gracefully)  

**Just load an investigation and press Option 12!**

---

*Backwater Forensics • Apple FORENSICS • Victim Investigator Approach*  
*Investigation Status Report - Feature Complete*
