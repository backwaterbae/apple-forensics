# Apple FORENSICS
**Professional macOS Forensic Analysis Toolkit**

![Version](https://img.shields.io/badge/version-1.0-blue)
![Platform](https://img.shields.io/badge/platform-macOS-lightgrey)
![Python](https://img.shields.io/badge/python-3.8%2B-green)
![License](https://img.shields.io/badge/license-MIT-green)

> *Victim Investigator Approach: Empowering victims and legitimate investigators with professional forensic tools*

---

## 📋 **Overview**

Apple FORENSICS is a comprehensive macOS forensic investigation toolkit designed with a "Victim Investigator Approach" - built to help victims document evidence and assist legitimate investigators in conducting professional, court-admissible digital forensic investigations.

### Key Features

- **🌐 Complete Browser Forensics** - Chrome, Safari, Firefox, Brave
- **📊 Log Analysis** - 400+ detection patterns for malware, crashes, security events
- **💻 Runtime Monitoring** - Process snapshots, network capture, memory analysis
- **🔍 Timeline Reconstruction** - Search across all artifacts by date range
- **📝 Investigation Management** - Professional case tracking and reporting
- **🎯 Whitelist System** - Reduce false positives by ~80%
- **⚖️ Court-Ready** - SHA-256 hashing, UTC timestamps, proper chain of custody

---

## 🎯 **Philosophy: Victim Investigator Approach**

### What Makes This Different

**For Victims:**
- Professional presentation builds trust
- Clear documentation for law enforcement
- Court-admissible evidence format
- Accessible to non-technical users
- Comprehensive but not overwhelming

**For Investigators:**
- Forensic-grade evidence preservation
- Standardized output formats (JSON/CSV/Markdown)
- SHA-256 integrity verification
- Proper timestamp formatting (UTC with 'Z' suffix)
- Investigation-centric workflow

**Core Principles:**
1. **Accuracy Over Speed** - Every finding is verified and documented
2. **Transparency** - All methods and patterns are visible
3. **Integrity** - Evidence preservation is paramount
4. **Accessibility** - Professional tools shouldn't require expert knowledge
5. **Ethics** - Designed for legitimate investigation, not exploitation

---

## ✨ **What's Included**

### Browser Forensics
```
✓ Chrome History Analyzer       - URL history, downloads, searches, extensions
✓ Safari History Analyzer       - URL history, downloads
✓ Firefox History Analyzer      - URL history, downloads, searches, form history
✓ Brave History Analyzer        - URL history, downloads, searches, extensions

Features:
• Suspicious URL detection
• Whitelist filtering
• Timeline JSON format
• Multi-format output (JSON/CSV/MD)
• SHA-256 hashing
```

### Log Analysis
```
✓ 400+ Detection Patterns
  - Security events (authentication, authorization)
  - Malware indicators (100+ signatures)
  - Crash patterns (50+ types)
  - System errors and warnings

✓ Whitelist System
  - 420+ legitimate domains/extensions
  - ~80% false positive reduction
  - Customizable patterns
```

### Runtime Monitoring
```
✓ Process Memory Snapshots      - Single process deep dive
✓ System Process Triage         - All running processes
✓ Network Capture              - 30-60 second captures
✓ Combined Capture             - Process + network together
✓ System State                 - Complete system snapshot
```

### Search & Reporting
```
✓ Date Range Search            - Query all artifacts by timestamp
✓ Investigation Reports        - Professional status reports
✓ Timeline Reconstruction      - Unified timeline across sources
✓ Evidence Documentation       - Proper chain of custody
```

### Additional Features
```
✓ Home Directory Analysis      - Downloads, shell history, configs
✓ Pattern File Creation        - Custom detection rules
✓ Analysis Cleanup             - False positive filtering
✓ Investigation Management     - Case tracking and notes
```

---

## 🚀 **Quick Start**

### Installation

```bash
# 1. Download Apple FORENSICS
cd ~/Documents
mkdir apple-forensics
cd apple-forensics
# Copy all files here

# 2. Make executable
chmod +x apple_forensics_dashboard.py
chmod +x *.py

# 3. Run
./apple_forensics_dashboard.py
```

### First Investigation

```bash
# Create investigation
./apple_forensics_dashboard.py
# Select: 1. Create New Investigation

# Run browser analysis
# Select: 38. Chrome History Analysis

# Generate report
# Select: 43. Generate Investigation Status Report
```

**See `QUICKSTART.md` for detailed walkthrough!**

---

## 📊 **Dashboard Menu**

### Investigation Setup
```
INVESTIGATION (1-3)
  1. Create New Investigation
  2. Load Existing Investigation
  3. List All Investigations

CURRENT INVESTIGATION (4-5, 10-11)
  4. View Investigation Details
  5. Edit Investigation Details
  10. Add Investigator Note
  11. Close Investigation
```

### Configuration & Tools
```
TOOLS (13-19, 16)
  13. Configure Log Directories
  14. Configure Pattern Files
  15. Configure Whitelist Files
  16. Analysis Cleanup Tool
  17. Create Custom Pattern File
  18. List Available Patterns
  19. Quick Scan (No Investigation)
```

### Analysis Operations
```
LOG ANALYSIS (8-9)
  8. Run Log Analysis
  9. View Analysis Results

RUNTIME MONITORING (20-24)
  20. Process Memory Snapshot
  21. System Process Triage
  22. Network Capture
  23. Combined Process + Network
  24. System + Network Capture

ARTIFACT COLLECTION (25)
  25. Home Directory Analysis

BROWSER FORENSICS (38-41)
  38. Chrome History Analysis
  39. Safari History Analysis
  40. Firefox History Analysis
  41. Brave History Analysis
```

### Search & Output
```
SEARCH & REPORTING (42-43)
  42. Search Analysis by Date Range
  43. Generate Investigation Status Report
```

---

## 📂 **Investigation Structure**

```
Investigations/CASE-2025-001/
├── investigation.json              ← Case metadata
├── notes/                          ← Investigation notes
├── artifacts/                      ← All evidence
│   ├── logs/                       ← Log analysis
│   ├── browser_forensics/
│   │   ├── chrome/
│   │   ├── safari/
│   │   ├── firefox/
│   │   └── brave/
│   ├── runtime_monitoring/         ← Process/network
│   └── home_directory/             ← File analysis
├── searches/                       ← Timeline queries
└── reports/                        ← Status reports
```

**Every file includes:**
- SHA-256 hash for integrity
- UTC timestamps with 'Z' suffix
- Metadata for chain of custody
- Multiple formats (JSON/CSV/Markdown)

---

## 🎯 **Use Cases**

### Malware Investigation
```
1. Log Analysis (8)           → Detect malware traces
2. Process Triage (21)        → Find suspicious processes  
3. Network Capture (22)       → Identify C2 servers
4. Browser Analysis (38-41)   → Check downloads
5. Date Range Search (42)     → Build infection timeline
```

### Incident Response
```
1. System State Capture (24)  → Preserve evidence
2. Browser Forensics (38-41)  → User activity
3. Log Analysis (8)           → System events
4. Timeline Search (42)       → Incident window
5. Generate Report (43)       → Documentation
```

### Employee Monitoring
```
1. Browser Analysis (38-41)   → Web activity
2. Home Directory (25)        → Downloaded files
3. Process Analysis (21)      → Applications used
4. Timeline Search (42)       → Work hours activity
```

### Data Theft Investigation
```
1. Browser History (38-41)    → Cloud uploads, email
2. Home Directory (25)        → File access patterns
3. Network Capture (22)       → File transfers
4. Timeline Search (42)       → Data access timeline
```

---

## 🔬 **Technical Details**

### Supported Browsers
- **Chrome:** History, downloads, searches, extensions, incognito detection
- **Safari:** History, downloads (binary plist support)
- **Firefox:** History, downloads, searches, form history
- **Brave:** History, downloads, searches, extensions, crypto-aware

### Timestamp Formats
```
Chrome/Brave:  Microseconds since 1601-01-01 (WebKit epoch)
Safari:        Seconds since 2001-01-01 (Cocoa epoch)
Firefox:       Microseconds since 1970-01-01 (Unix epoch)
Output:        ISO 8601 UTC with 'Z' suffix (standardized)
```

### Detection Patterns
```
Security:  60+ patterns (auth failures, unauthorized access, etc.)
Malware:   100+ signatures (known malware, suspicious behavior)
Crashes:   50+ patterns (segfaults, exceptions, panics)
Custom:    User-defined patterns supported
```

### Output Formats
```
JSON:      Machine-readable, complete data, timeline format
CSV:       Spreadsheet import, SIEM integration
Markdown:  Human-readable reports, organized by severity
SHA-256:   Evidence integrity verification
```

---

## 🔒 **Forensic Standards**

### Chain of Custody
- Case ID tracking
- Investigator attribution
- UTC timestamps throughout
- SHA-256 hashing
- Metadata preservation

### Evidence Integrity
- Read-only access to originals
- Temporary copies for analysis
- Hash verification
- No data modification
- Audit trail in investigation.json

### Professional Quality
- Multi-format outputs
- Severity classification (HIGH/MEDIUM/LOW)
- Context preservation
- Timeline reconstruction
- Court-ready presentation

---

## 🛠️ **System Requirements**

### Minimum Requirements
- macOS 10.15 (Catalina) or later
- Python 3.8 or later
- 100 MB free disk space
- Terminal access

### Recommended
- macOS 12 (Monterey) or later
- Python 3.10+
- 1 GB free disk space (for large investigations)
- Administrator privileges (for system log access)

### Dependencies
```
Standard Library Only:
- json, csv, sqlite3, pathlib, datetime
- subprocess, argparse, shutil, hashlib
- re (regex), os, sys

No external dependencies required!
```

---

## 📚 **Documentation**

- **QUICKSTART.md** - Get started in 5 minutes
- **TOOL_REFERENCE.md** - Complete feature documentation
- **LICENSE.md** - Usage terms and conditions
- **CHANGELOG.md** - Version history and updates

---

## 🤝 **Contributing**

### We Welcome
- Bug reports and fixes
- Feature requests
- Documentation improvements
- Pattern file contributions
- Use case examples

### Guidelines
- Maintain forensic standards
- Preserve evidence integrity
- Follow existing code style
- Document all changes
- Test thoroughly

### Not Accepted
- Features that compromise evidence
- Exploitative capabilities
- Privacy violations
- Malicious code
- Unlicensed content

---

## ⚖️ **Legal & Ethical Use**

### Intended Use
✅ Legitimate forensic investigation  
✅ Incident response  
✅ Malware analysis  
✅ Evidence documentation  
✅ Security research  
✅ Educational purposes  

### Prohibited Use
❌ Unauthorized access  
❌ Privacy violations  
❌ Stalking or harassment  
❌ Evidence tampering  
❌ Illegal surveillance  
❌ Malicious intent  

**Users are responsible for compliance with all applicable laws.**

---

## 🏆 **Credits**

### Development
**Backwater Forensics** - Digital forensic investigation tools  
**Victim Investigator Approach** - Ethical forensic philosophy

### Inspiration
- Digital forensics community
- Incident response practitioners
- Victims seeking justice
- macOS security researchers

### Special Thanks
- Open source forensic tools community
- Python forensics developers
- macOS security researchers
- Early adopters and testers

---

## 📞 **Support**

### Documentation
- Quick Start: `QUICKSTART.md`
- Full Reference: `TOOL_REFERENCE.md`
- This README: Project overview

### Community
- GitHub Issues: Bug reports and features
- Discussions: Share techniques
- Pull Requests: Contribute code

### Contact
- Project: Apple FORENSICS v1.0
- Organization: Backwater Forensics
- Approach: Victim Investigator
- License: MIT (see LICENSE.md)

---

## 📈 **Roadmap**

### Version 1.0 (Current)
✅ Complete browser forensics (4 browsers)  
✅ Log analysis with 400+ patterns  
✅ Runtime monitoring suite  
✅ Date range search  
✅ Investigation management  
✅ Professional reporting  

### Version 2.0 (Planned)
- Keychain analysis
- Time Machine inspection
- Image forensics (EXIF, OCR)
- Enhanced malware detection
- Timeline correlation engine
- Browser comparison tool

### Future Considerations
- iOS device support
- Network traffic analysis
- Email forensics
- Cloud storage analysis
- Machine learning detection
- API integration

---

## 📝 **Version Information**

**Current Version:** 1.0  
**Release Date:** December 2025  
**Status:** Production Ready  
**Platform:** macOS 10.15+  
**Language:** Python 3.8+  

**Phase 3 Complete:**
- Foundation tools
- Browser forensics module
- Search & reporting capabilities
- Investigation management

---

## 🎓 **Learn More**

### Getting Started
1. Read `QUICKSTART.md`
2. Run your first investigation
3. Review `TOOL_REFERENCE.md`
4. Join community discussions

### Advanced Topics
- Custom pattern creation
- Whitelist optimization
- Timeline correlation
- Multi-source investigation
- Report customization

### Best Practices
- Forensic methodology
- Evidence handling
- Chain of custody
- Professional documentation
- Court presentation

---

## 💡 **Key Differentiators**

**Why Apple FORENSICS?**

1. **Victim-Focused Design** - Built for accessibility, not just experts
2. **Forensic Standards** - Court-admissible evidence from day one
3. **Complete Coverage** - All major browsers, comprehensive logs
4. **No Dependencies** - Standard library only, easy deployment
5. **Professional Quality** - Production-ready, tested, documented
6. **Ethical Foundation** - Victim Investigator Approach philosophy
7. **Open Source** - Transparent, auditable, community-driven

---

## 🌟 **Success Stories**

*Apple FORENSICS is designed to help:*

- **Victims** document digital evidence for law enforcement
- **Investigators** conduct thorough, professional examinations
- **IT Teams** respond to security incidents efficiently
- **Researchers** analyze malware and attack patterns
- **Educators** teach digital forensics principles

---

**Ready to investigate?**

```bash
./apple_forensics_dashboard.py
```

---

**Backwater Forensics • Apple FORENSICS**  
*Victim Investigator Approach*  
*Professional macOS Forensic Analysis*

Version 1.0 • December 2025  
MIT License • Open Source • Community Driven

For support, documentation, and updates:  
See QUICKSTART.md, TOOL_REFERENCE.md, and LICENSE.md
