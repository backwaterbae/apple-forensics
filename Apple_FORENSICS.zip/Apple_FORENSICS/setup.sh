#!/bin/bash
# Apple FORENSICS - Setup Script
# Run this first after extracting the package

echo ""
echo "🔧 Apple FORENSICS - Setup"
echo "========================================"
echo ""

# Get the script's directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "📂 Setting file permissions..."
echo ""

# Make Python tools executable
if ls *.py 1> /dev/null 2>&1; then
    chmod +x *.py
    COUNT=$(ls *.py 2>/dev/null | wc -l)
    echo "  ✅ Made $COUNT Python tools executable"
else
    echo "  ⚠️  No Python files found"
fi

# Make scripts executable
if [ -d "scripts" ] && ls scripts/*.sh 1> /dev/null 2>&1; then
    chmod +x scripts/*.sh
    COUNT=$(ls scripts/*.sh 2>/dev/null | wc -l)
    echo "  ✅ Made $COUNT scripts executable"
else
    echo "  ⚠️  No scripts found"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Install dependencies:"
echo "     ./scripts/install_dependencies.sh"
echo ""
echo "  2. Launch dashboard:"
echo "     ./apple_forensics_dashboard.py"
echo ""
