#!/usr/bin/env python3
"""
Home Directory Forensic Analyzer
Apple FORENSICS Toolkit - Victim Investigator Series

Analyzes user home directory for forensic artifacts:
- Shell command history (.zsh_history, .bash_history)
- Downloads folder (suspicious files, metadata)
- SSH keys and config files
- Hidden configuration files
- Suspicious scripts and executables

Generates forensic-grade reports with chain of custody metadata.
"""

import os
import sys
import hashlib
import json
import argparse
import re
from datetime import datetime
from pathlib import Path
from collections import defaultdict

class HomeDirectoryAnalyzer:
    """Forensic analyzer for macOS user home directories"""
    
    def __init__(self, home_dir=None, output_dir=".", verbose=False, whitelist_file=None):
        self.home_dir = Path(home_dir) if home_dir else Path.home()
        self.output_dir = Path(output_dir)
        self.verbose = verbose
        # Support both single file (backward compat) and list of files
        if whitelist_file:
            self.whitelist_files = [whitelist_file] if isinstance(whitelist_file, str) else whitelist_file
        else:
            self.whitelist_files = []
        self.whitelist = set()
        self.findings = []
        self.stats = defaultdict(int)
        
        # Load whitelist if provided
        if self.whitelist_files:
            self.load_whitelists()
        
        # Detection patterns for suspicious commands
        self.suspicious_patterns = {
            # Network reconnaissance and exploitation
            'nmap': {'severity': 'HIGH', 'category': 'Reconnaissance', 'description': 'Network scanning'},
            'masscan': {'severity': 'HIGH', 'category': 'Reconnaissance', 'description': 'Port scanning'},
            'nc -l': {'severity': 'HIGH', 'category': 'Network', 'description': 'Listener setup'},
            'nc -e': {'severity': 'HIGH', 'category': 'Network', 'description': 'Reverse shell'},
            'ncat': {'severity': 'HIGH', 'category': 'Network', 'description': 'Network connection'},
            
            # Remote access and backdoors
            'ssh -R': {'severity': 'HIGH', 'category': 'Remote Access', 'description': 'SSH reverse tunnel'},
            'ssh -D': {'severity': 'MEDIUM', 'category': 'Remote Access', 'description': 'SSH SOCKS proxy'},
            'ngrok': {'severity': 'HIGH', 'category': 'Remote Access', 'description': 'Tunneling service'},
            'teamviewer': {'severity': 'MEDIUM', 'category': 'Remote Access', 'description': 'Remote desktop'},
            
            # Data exfiltration
            'curl.*upload': {'severity': 'HIGH', 'category': 'Data Exfiltration', 'description': 'File upload'},
            'wget.*-O': {'severity': 'MEDIUM', 'category': 'Data Exfiltration', 'description': 'File download'},
            'scp.*@': {'severity': 'MEDIUM', 'category': 'Data Transfer', 'description': 'Secure copy'},
            'rsync.*@': {'severity': 'MEDIUM', 'category': 'Data Transfer', 'description': 'Remote sync'},
            'base64': {'severity': 'LOW', 'category': 'Encoding', 'description': 'Base64 encoding/decoding'},
            
            # Credential access
            'sudo -i': {'severity': 'MEDIUM', 'category': 'Privilege Escalation', 'description': 'Root shell'},
            'sudo su': {'severity': 'MEDIUM', 'category': 'Privilege Escalation', 'description': 'Switch user'},
            'passwd': {'severity': 'MEDIUM', 'category': 'Credential', 'description': 'Password change'},
            'security dump-keychain': {'severity': 'HIGH', 'category': 'Credential', 'description': 'Keychain dump'},
            'security find-generic-password': {'severity': 'MEDIUM', 'category': 'Credential', 'description': 'Password retrieval'},
            
            # Persistence and execution
            'launchctl load': {'severity': 'MEDIUM', 'category': 'Persistence', 'description': 'Launch agent'},
            'crontab': {'severity': 'MEDIUM', 'category': 'Persistence', 'description': 'Scheduled task'},
            'at ': {'severity': 'LOW', 'category': 'Persistence', 'description': 'Delayed execution'},
            'chmod +x': {'severity': 'LOW', 'category': 'Execution', 'description': 'Make executable'},
            'sh -c': {'severity': 'MEDIUM', 'category': 'Execution', 'description': 'Shell execution'},
            'bash -c': {'severity': 'MEDIUM', 'category': 'Execution', 'description': 'Bash execution'},
            'python -c': {'severity': 'MEDIUM', 'category': 'Execution', 'description': 'Python execution'},
            
            # Anti-forensics and evasion
            'rm -rf': {'severity': 'MEDIUM', 'category': 'Anti-Forensics', 'description': 'Recursive deletion'},
            'shred': {'severity': 'HIGH', 'category': 'Anti-Forensics', 'description': 'Secure deletion'},
            'srm': {'severity': 'HIGH', 'category': 'Anti-Forensics', 'description': 'Secure removal'},
            'history -c': {'severity': 'HIGH', 'category': 'Anti-Forensics', 'description': 'Clear history'},
            'unset HISTFILE': {'severity': 'HIGH', 'category': 'Anti-Forensics', 'description': 'Disable history'},
            
            # Download and execution chains
            'curl.*|.*bash': {'severity': 'HIGH', 'category': 'Malware', 'description': 'Remote script execution'},
            'wget.*|.*sh': {'severity': 'HIGH', 'category': 'Malware', 'description': 'Remote script execution'},
            'curl.*|.*python': {'severity': 'HIGH', 'category': 'Malware', 'description': 'Remote Python execution'},
            
            # Tor and anonymization
            'tor': {'severity': 'MEDIUM', 'category': 'Anonymization', 'description': 'Tor usage'},
            'proxychains': {'severity': 'MEDIUM', 'category': 'Anonymization', 'description': 'Proxy chains'},
            'vpn': {'severity': 'LOW', 'category': 'Anonymization', 'description': 'VPN usage'},
            
            # Database access
            'sqlite3': {'severity': 'LOW', 'category': 'Database', 'description': 'SQLite access'},
            'mysql': {'severity': 'LOW', 'category': 'Database', 'description': 'MySQL access'},
            'psql': {'severity': 'LOW', 'category': 'Database', 'description': 'PostgreSQL access'},
        }
        
        # Suspicious file extensions in Downloads
        self.suspicious_extensions = {
            '.sh': {'severity': 'MEDIUM', 'type': 'Shell Script'},
            '.py': {'severity': 'LOW', 'type': 'Python Script'},
            '.rb': {'severity': 'LOW', 'type': 'Ruby Script'},
            '.pl': {'severity': 'LOW', 'type': 'Perl Script'},
            '.exe': {'severity': 'HIGH', 'type': 'Windows Executable'},
            '.dll': {'severity': 'HIGH', 'type': 'Windows Library'},
            '.bat': {'severity': 'MEDIUM', 'type': 'Batch Script'},
            '.ps1': {'severity': 'MEDIUM', 'type': 'PowerShell Script'},
            '.pkg': {'severity': 'MEDIUM', 'type': 'macOS Installer'},
            '.dmg': {'severity': 'LOW', 'type': 'macOS Disk Image'},
            '.zip': {'severity': 'LOW', 'type': 'Archive'},
            '.tar.gz': {'severity': 'LOW', 'type': 'Archive'},
            '.rar': {'severity': 'LOW', 'type': 'Archive'},
            '.7z': {'severity': 'LOW', 'type': 'Archive'},
        }
        
        # Suspicious filenames (partial matches)
        self.suspicious_filenames = [
            'payload', 'exploit', 'reverse', 'shell', 'backdoor',
            'keylog', 'stealer', 'mimikatz', 'metasploit', 'meterpreter',
            'ransomware', 'cryptor', 'rootkit', 'trojan', 'virus',
            'hack', 'crack', 'keygen', 'patch', 'loader'
        ]
        
    def log(self, message):
        """Print verbose messages"""
        if self.verbose:
            print(f"[*] {message}")
            
    def load_whitelists(self):
        """Load whitelists of legitimate scripts to exclude from detection"""
        total_entries = 0
        for whitelist_file in self.whitelist_files:
            try:
                whitelist_path = Path(whitelist_file)
                if not whitelist_path.exists():
                    self.log(f"Warning: Whitelist file not found: {whitelist_file}")
                    continue
                
                file_entries = 0
                with open(whitelist_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        # Skip comments and empty lines
                        if line and not line.startswith('#'):
                            self.whitelist.add(line.lower())
                            file_entries += 1
                
                self.log(f"Loaded {file_entries} entries from {whitelist_file}")
                total_entries += file_entries
                
            except Exception as e:
                self.log(f"Error loading whitelist {whitelist_file}: {e}")
        
        if total_entries > 0:
            self.log(f"Total whitelist entries: {total_entries}")
            self.stats['whitelist_entries'] = len(self.whitelist)
            
    def is_whitelisted_command(self, command):
        """Check if command references a whitelisted script"""
        if not self.whitelist:
            return False
            
        command_lower = command.lower()
        
        # Check if any whitelisted script name appears in the command
        for script in self.whitelist:
            if script in command_lower:
                return True
                
        return False
    
    def parse_zsh_history_line(self, line):
        """Parse zsh extended history format: ': <timestamp>:<elapsed>;<command>'
        
        Returns:
            tuple: (command, timestamp_iso, timestamp_source)
                   or (command, None, None) if not extended format
        """
        # Zsh extended history format: : 1234567890:0;command
        zsh_pattern = r'^:\s*(\d+):\d+;(.*)$'
        match = re.match(zsh_pattern, line)
        
        if match:
            timestamp_unix = int(match.group(1))
            command = match.group(2)
            timestamp_iso = datetime.fromtimestamp(timestamp_unix).isoformat() + 'Z'
            return (command, timestamp_iso, 'zsh_extended_history')
        
        # Not extended format - return original line
        return (line, None, None)
            
    def calculate_hash(self, filepath):
        """Calculate SHA-256 hash of a file"""
        try:
            sha256 = hashlib.sha256()
            with open(filepath, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except Exception as e:
            return f"ERROR: {str(e)}"
            
    def get_file_metadata(self, filepath):
        """Extract file metadata"""
        try:
            stat = filepath.stat()
            return {
                'size': stat.st_size,
                'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                'accessed': datetime.fromtimestamp(stat.st_atime).isoformat(),
                'permissions': oct(stat.st_mode)[-3:]
            }
        except Exception as e:
            return {'error': str(e)}
            
    def add_finding(self, category, severity, description, details, source_file, 
                    artifact_timestamp=None, timestamp_source=None):
        """Add a finding to the results
        
        Args:
            category: Finding category
            severity: HIGH/MEDIUM/LOW
            description: Finding description
            details: Dictionary of finding details
            source_file: Source file path
            artifact_timestamp: When the artifact/event occurred (ISO format)
            timestamp_source: How the timestamp was determined
        """
        finding = {
            'analysis_timestamp': datetime.utcnow().isoformat() + 'Z',
            'artifact_timestamp': artifact_timestamp or datetime.utcnow().isoformat() + 'Z',
            'timestamp_source': timestamp_source or 'analysis_runtime',
            'category': category,
            'severity': severity,
            'description': description,
            'details': details,
            'source_file': str(source_file),
            'home_directory': str(self.home_dir)
        }
        self.findings.append(finding)
        self.stats[f"{severity}_{category}"] += 1
        
    def analyze_shell_history(self, history_file):
        """Analyze shell command history for suspicious commands"""
        if not history_file.exists():
            return
            
        self.log(f"Analyzing: {history_file.name}")
        
        # Get file modification time as fallback timestamp
        try:
            file_mtime = datetime.fromtimestamp(history_file.stat().st_mtime).isoformat() + 'Z'
        except:
            file_mtime = None
        
        try:
            with open(history_file, 'r', errors='replace') as f:
                lines = f.readlines()
                
            for line_num, line in enumerate(lines, 1):
                original_line = line.strip()
                if not original_line or original_line.startswith('#'):
                    continue
                
                # Parse zsh extended history format if present
                command, artifact_ts, ts_source = self.parse_zsh_history_line(original_line)
                command = command.strip()
                
                # If no timestamp from zsh format, use file mtime
                if not artifact_ts:
                    artifact_ts = file_mtime
                    ts_source = 'file_mtime'
                
                # Skip whitelisted commands
                if self.is_whitelisted_command(command):
                    self.stats['commands_whitelisted'] += 1
                    continue
                    
                # Check for suspicious patterns
                for pattern, info in self.suspicious_patterns.items():
                    if re.search(pattern, command, re.IGNORECASE):
                        # Build details dict - only include context if different from command
                        details = {
                            'command': command,
                            'line_number': line_num,
                            'pattern_matched': pattern
                        }
                        
                        # Only add context if it would be different (truncated)
                        if len(command) > 200:
                            details['context'] = command[:200]
                        
                        self.add_finding(
                            category=info['category'],
                            severity=info['severity'],
                            description=info['description'],
                            details=details,
                            source_file=history_file,
                            artifact_timestamp=artifact_ts,
                            timestamp_source=ts_source
                        )
                        self.stats['commands_flagged'] += 1
                        
            self.stats['commands_analyzed'] += len(lines)
            
        except Exception as e:
            self.log(f"Error analyzing {history_file}: {e}")
            
    def analyze_downloads(self, downloads_dir):
        """Analyze Downloads folder for suspicious files"""
        if not downloads_dir.exists():
            return
            
        self.log(f"Analyzing Downloads folder...")
        
        try:
            for item in downloads_dir.iterdir():
                if not item.is_file():
                    continue
                    
                self.stats['downloads_scanned'] += 1
                
                # Check file extension
                suffix = item.suffix.lower()
                for ext, info in self.suspicious_extensions.items():
                    if suffix == ext or (ext.startswith('.tar') and str(item).endswith(ext)):
                        metadata = self.get_file_metadata(item)
                        file_hash = self.calculate_hash(item)
                        
                        # Use file modification time as artifact timestamp
                        try:
                            artifact_ts = datetime.fromtimestamp(item.stat().st_mtime).isoformat() + 'Z'
                            ts_source = 'file_mtime'
                        except:
                            artifact_ts = None
                            ts_source = None
                        
                        self.add_finding(
                            category='Suspicious Download',
                            severity=info['severity'],
                            description=f"{info['type']} in Downloads",
                            details={
                                'filename': item.name,
                                'extension': suffix,
                                'file_type': info['type'],
                                'sha256': file_hash,
                                'metadata': metadata
                            },
                            source_file=item,
                            artifact_timestamp=artifact_ts,
                            timestamp_source=ts_source
                        )
                        self.stats['suspicious_downloads'] += 1
                        
                # Check filename for suspicious keywords
                filename_lower = item.name.lower()
                for keyword in self.suspicious_filenames:
                    if keyword in filename_lower:
                        metadata = self.get_file_metadata(item)
                        file_hash = self.calculate_hash(item)
                        
                        # Use file modification time as artifact timestamp
                        try:
                            artifact_ts = datetime.fromtimestamp(item.stat().st_mtime).isoformat() + 'Z'
                            ts_source = 'file_mtime'
                        except:
                            artifact_ts = None
                            ts_source = None
                        
                        self.add_finding(
                            category='Suspicious Filename',
                            severity='HIGH',
                            description=f'Suspicious keyword in filename: {keyword}',
                            details={
                                'filename': item.name,
                                'keyword': keyword,
                                'sha256': file_hash,
                                'metadata': metadata
                            },
                            source_file=item,
                            artifact_timestamp=artifact_ts,
                            timestamp_source=ts_source
                        )
                        self.stats['suspicious_filenames'] += 1
                        break  # Only flag once per file
                        
        except Exception as e:
            self.log(f"Error analyzing Downloads: {e}")
            
    def analyze_ssh_config(self):
        """Analyze SSH configuration and keys"""
        ssh_dir = self.home_dir / '.ssh'
        if not ssh_dir.exists():
            return
            
        self.log("Analyzing SSH configuration...")
        
        try:
            # Check for SSH keys
            key_patterns = ['id_rsa', 'id_dsa', 'id_ecdsa', 'id_ed25519']
            for key_pattern in key_patterns:
                key_file = ssh_dir / key_pattern
                if key_file.exists():
                    metadata = self.get_file_metadata(key_file)
                    
                    # Use file modification time as artifact timestamp
                    try:
                        artifact_ts = datetime.fromtimestamp(key_file.stat().st_mtime).isoformat() + 'Z'
                        ts_source = 'file_mtime'
                    except:
                        artifact_ts = None
                        ts_source = None
                    
                    self.add_finding(
                        category='SSH Key',
                        severity='MEDIUM',
                        description='SSH private key found',
                        details={
                            'key_file': key_file.name,
                            'metadata': metadata
                        },
                        source_file=key_file,
                        artifact_timestamp=artifact_ts,
                        timestamp_source=ts_source
                    )
                    self.stats['ssh_keys_found'] += 1
                    
            # Check SSH config
            config_file = ssh_dir / 'config'
            if config_file.exists():
                # Get config file mtime
                try:
                    config_mtime = datetime.fromtimestamp(config_file.stat().st_mtime).isoformat() + 'Z'
                except:
                    config_mtime = None
                
                with open(config_file, 'r', errors='replace') as f:
                    config_lines = f.readlines()
                    
                for line_num, line in enumerate(config_lines, 1):
                    line = line.strip()
                    # Look for interesting configurations
                    if any(keyword in line.lower() for keyword in ['proxycommand', 'dynamicforward', 'remoteforward']):
                        self.add_finding(
                            category='SSH Configuration',
                            severity='MEDIUM',
                            description='Suspicious SSH config directive',
                            details={
                                'line_number': line_num,
                                'directive': line
                            },
                            source_file=config_file,
                            artifact_timestamp=config_mtime,
                            timestamp_source='file_mtime'
                        )
                        
            # Check known_hosts
            known_hosts = ssh_dir / 'known_hosts'
            if known_hosts.exists():
                with open(known_hosts, 'r', errors='replace') as f:
                    hosts = f.readlines()
                self.stats['ssh_known_hosts'] += len(hosts)
                
        except Exception as e:
            self.log(f"Error analyzing SSH config: {e}")
            
    def analyze_hidden_configs(self):
        """Analyze hidden configuration files"""
        self.log("Analyzing hidden configuration files...")
        
        suspicious_configs = [
            '.aws/credentials',
            '.docker/config.json', 
            '.kube/config',
            '.npmrc',
            '.pypirc',
            '.netrc',
            '.gitconfig'
        ]
        
        for config_path in suspicious_configs:
            config_file = self.home_dir / config_path
            if config_file.exists():
                metadata = self.get_file_metadata(config_file)
                
                # Use file modification time as artifact timestamp
                try:
                    artifact_ts = datetime.fromtimestamp(config_file.stat().st_mtime).isoformat() + 'Z'
                    ts_source = 'file_mtime'
                except:
                    artifact_ts = None
                    ts_source = None
                
                self.add_finding(
                    category='Configuration File',
                    severity='LOW',
                    description=f'Found configuration: {config_path}',
                    details={
                        'config_file': config_path,
                        'metadata': metadata
                    },
                    source_file=config_file,
                    artifact_timestamp=artifact_ts,
                    timestamp_source=ts_source
                )
                self.stats['config_files_found'] += 1
                
    def run_analysis(self):
        """Run complete home directory analysis"""
        print(f"\n{'='*70}")
        print("Home Directory Forensic Analyzer")
        print("Apple FORENSICS Toolkit")
        print(f"{'='*70}\n")
        
        print(f"Analyzing home directory: {self.home_dir}")
        print(f"Analysis started: {datetime.utcnow().isoformat()}Z\n")
        
        # Analyze shell history files
        self.analyze_shell_history(self.home_dir / '.zsh_history')
        self.analyze_shell_history(self.home_dir / '.bash_history')
        
        # Analyze Downloads folder
        self.analyze_downloads(self.home_dir / 'Downloads')
        
        # Analyze SSH configuration
        self.analyze_ssh_config()
        
        # Analyze hidden configuration files
        self.analyze_hidden_configs()
        
        print(f"\nAnalysis complete!")
        print(f"Total findings: {len(self.findings)}")
        print(f"  HIGH severity: {sum(1 for f in self.findings if f['severity'] == 'HIGH')}")
        print(f"  MEDIUM severity: {sum(1 for f in self.findings if f['severity'] == 'MEDIUM')}")
        print(f"  LOW severity: {sum(1 for f in self.findings if f['severity'] == 'LOW')}")
        
    def generate_reports(self):
        """Generate multi-format forensic reports"""
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        
        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate JSON report
        json_report = self.output_dir / f'home_analysis_{timestamp}.json'
        with open(json_report, 'w') as f:
            report_data = {
                'analysis_metadata': {
                    'tool': 'Home Directory Analyzer',
                    'version': '1.0',
                    'analyst': os.environ.get('USER', 'unknown'),
                    'analysis_timestamp': datetime.utcnow().isoformat() + 'Z',
                    'home_directory': str(self.home_dir),
                    'findings_count': len(self.findings)
                },
                'statistics': dict(self.stats),
                'findings': self.findings
            }
            json.dump(report_data, f, indent=2)
        print(f"\n✓ JSON report: {json_report}")
        
        # Generate CSV report
        csv_report = self.output_dir / f'home_analysis_{timestamp}.csv'
        with open(csv_report, 'w') as f:
            f.write('Artifact_Timestamp,Timestamp_Source,Analysis_Timestamp,Severity,Category,Description,Source_File,Details\n')
            for finding in sorted(self.findings, key=lambda x: x['severity'], reverse=True):
                details_str = json.dumps(finding['details']).replace('"', '""')
                f.write(f'"{finding["artifact_timestamp"]}","{finding["timestamp_source"]}","{finding["analysis_timestamp"]}","{finding["severity"]}","{finding["category"]}","{finding["description"]}","{finding["source_file"]}","{details_str}"\n')
        print(f"✓ CSV report: {csv_report}")
        
        # Generate Markdown report
        md_report = self.output_dir / f'home_analysis_{timestamp}.md'
        with open(md_report, 'w') as f:
            f.write('# Home Directory Forensic Analysis Report\n\n')
            f.write(f'**Analysis Timestamp:** {datetime.utcnow().isoformat()}Z\n\n')
            f.write(f'**Home Directory:** `{self.home_dir}`\n\n')
            f.write(f'**Analyst:** {os.environ.get("USER", "unknown")}\n\n')
            
            f.write('## Analysis Statistics\n\n')
            f.write(f'- **Total Findings:** {len(self.findings)}\n')
            f.write(f'- **HIGH Severity:** {sum(1 for x in self.findings if x["severity"] == "HIGH")}\n')
            f.write(f'- **MEDIUM Severity:** {sum(1 for x in self.findings if x["severity"] == "MEDIUM")}\n')
            f.write(f'- **LOW Severity:** {sum(1 for x in self.findings if x["severity"] == "LOW")}\n\n')
            
            if self.stats:
                f.write('### Detailed Statistics\n\n')
                for key, value in sorted(self.stats.items()):
                    f.write(f'- **{key}:** {value}\n')
                f.write('\n')
            
            f.write('---\n\n')
            
            # Organize by severity
            for severity in ['HIGH', 'MEDIUM', 'LOW']:
                severity_findings = [f for f in self.findings if f['severity'] == severity]
                if not severity_findings:
                    continue
                    
                f.write(f'## {severity} Severity Findings ({len(severity_findings)})\n\n')
                
                for finding in severity_findings:
                    f.write(f'### {finding["category"]}: {finding["description"]}\n\n')
                    f.write(f'- **Artifact Timestamp:** {finding["artifact_timestamp"]} (source: {finding["timestamp_source"]})\n')
                    f.write(f'- **Analysis Timestamp:** {finding["analysis_timestamp"]}\n')
                    f.write(f'- **Source File:** `{finding["source_file"]}`\n')
                    
                    if finding['details']:
                        f.write(f'- **Details:**\n')
                        for key, value in finding['details'].items():
                            if isinstance(value, dict):
                                f.write(f'  - **{key}:**\n')
                                for k, v in value.items():
                                    f.write(f'    - {k}: `{v}`\n')
                            else:
                                f.write(f'  - **{key}:** `{value}`\n')
                    
                    f.write('\n---\n\n')
                    
        print(f'✓ Markdown report: {md_report}')
        
        print(f'\n{"="*70}')
        print('Reports generated successfully!')
        print(f'{"="*70}\n')
        
        return json_report, csv_report, md_report

def main():
    parser = argparse.ArgumentParser(
        description='Home Directory Forensic Analyzer - Apple FORENSICS Toolkit',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Analyze current user's home directory
  %(prog)s
  
  # Analyze specific user's home directory
  %(prog)s -d /Users/suspect
  
  # Analyze with verbose output
  %(prog)s -v
  
  # Use whitelist to exclude legitimate forensic tools
  %(prog)s -w appleforensics_whitelist.txt
  
  # Full analysis with whitelist and verbose output
  %(prog)s -d /Users/suspect -w appleforensics_whitelist.txt -v
  
  # Save reports to specific directory
  %(prog)s -o /cases/investigation_001/
  
  # Analyze specific home directory with custom output and whitelist
  %(prog)s -d /Users/suspect -o /evidence/ -w appleforensics_whitelist.txt -v
        '''
    )
    
    parser.add_argument('-d', '--directory',
                        help='Home directory to analyze (default: current user)',
                        default=None)
    
    parser.add_argument('-o', '--output',
                        help='Output directory for reports (default: current directory)',
                        default='.')
    
    parser.add_argument('-v', '--verbose',
                        help='Enable verbose output',
                        action='store_true')
    
    parser.add_argument('-w', '--whitelist', nargs='+',
                        help='Whitelist file(s) with legitimate scripts to exclude (e.g., macos_whitelist.txt apple_forensics_whitelist.txt)',
                        default=None)
    
    args = parser.parse_args()
    
    try:
        analyzer = HomeDirectoryAnalyzer(
            home_dir=args.directory,
            output_dir=args.output,
            verbose=args.verbose,
            whitelist_file=args.whitelist
        )
        
        analyzer.run_analysis()
        analyzer.generate_reports()
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n[!] Analysis interrupted by user")
        return 1
    except Exception as e:
        print(f"\n[!] Error: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

if __name__ == '__main__':
    sys.exit(main())
